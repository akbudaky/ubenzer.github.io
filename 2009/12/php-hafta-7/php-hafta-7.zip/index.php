<?php 
	/* DİKKAT: Bu koddaki oturum açma sistemi, gerçek bir PHP
	projesinde kullanılamayacak kadar dış etkilere açık olduğundan
	kodu dikkatli kullanmanızı öneririm. */
	header("Content-Type: text/html; charset=utf-8"); 
	session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="tr-TR">
<head profile="http://gmpg.org/xfn/1">
	<!-- EgeBK PHP Kursu Örnek Kaynak Kodları -->
	<title>Basit Bir Oturum Açma Programı</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta http-equiv="author" content="Umut Benzer" />
</head>
<body>
<form action="index.php" method="post">	
	<label for="name">Kullanıcı adı</label> 
	<input type="text" id="name" name="name" size="10" />
	<label for="pass">Şifre</label>
	<input type="text" id="pass" name="pass" size="10" />
	<button type="submit">Yallah</button>			
</form>
<?php
/* İnit */

// ezSQL
include_once "ez_sql_core.php";
include_once "ez_sql_mysql.php";

// Veritabanı yapılandırması
$vt_kullanici="root";
$vt_parola="";
$vt_isim="kullanici";
$vt_sunucu="localhost";

// ezSQL sınıfından bir nesne...
$db = new ezSQL_mysql($vt_kullanici,$vt_parola,$vt_isim,$vt_sunucu);

// Dil ayarlaması
$db->query("SET NAMES utf8");

/* Oturum kapatma bilgisi gönderilmiş */
if(isset($_GET["cikis"]) && $_GET["cikis"] == 1) {
	$_SESSION["kullanici_id"] = NULL;
	$_SESSION["kullanici_adi"] = NULL;
}

/* Oturum açma bilgisi gönderilmiş */
if(isset($_POST["name"]) && isset($_POST["pass"])) {
	// Güvenlik önlemleri
	$name = $db->escape($_POST["name"]);
	$pass = $db->escape($_POST["pass"]);
	
	$sql = "SELECT * FROM `kullanici` WHERE name='".$name."' AND pass='".$pass."'";
	echo "Yaratılan SQL cümleciği: " . $sql . "<br />\n";
	$sonuc = $db->get_row($sql);

	if(!is_null($sonuc)) {
		$_SESSION["kullanici_id"] = $sonuc->id;
		$_SESSION["kullanici_adi"] = $sonuc->name;
	} else {
		$_SESSION["kullanici_id"] = NULL;
		$_SESSION["kullanici_adi"] = NULL;
		echo "Kullanıcı adı veya şifre yanlış!" . "<br />";
	}
}

/* Oturum açılmış mı kontrolü */
if(isset($_SESSION['kullanici_adi']) && !is_null($_SESSION['kullanici_adi'])) {
	echo "Oturum açan kullanıcı: " . $_SESSION['kullanici_adi'] . " Oturumu kapatmak için <a href='?cikis=1'>tıkla</a>.";
} else { 
	echo "Naber ziyaretçi?";
} 

/* SESSION süperdeğişkeninde neler olup bitiyor? */
echo "<br />";
echo var_dump($_SESSION);
?></body>