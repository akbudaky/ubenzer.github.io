<?php 
	header("Content-Type: text/html; charset=utf-8"); 
	header('X-Easter-Egg: Abidik Gubidik');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="tr-TR">
<head profile="http://gmpg.org/xfn/1">
	<!-- EgeBK PHP Kursu Örnek Kaynak Kodları -->
	<title>Veri Tabanı Deneyi</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta http-equiv="author" content="Umut Benzer" />
</head>
<body>
<form action="index.php" method="post">	
	<label for="name">Name</label> 
	<input type="text" id="name" name="name" size="30" />
	<label for="lastname">Lastname</label>
	<input type="text" id="lastname" name="lastname" size="30" />
	<button type="submit">Yallah</button>			
</form>
<?php
/* İnit */

// ezSQL
include_once "ez_sql_core.php";
include_once "ez_sql_mysql.php";
 
// Veritabanı yapılandırması
$vt_kullanici="root";
$vt_parola="";
$vt_isim="ticaret";
$vt_sunucu="localhost";
	 
// ezSQL sınıfından bir nesne...
$db = new ezSQL_mysql($vt_kullanici,$vt_parola,$vt_isim,$vt_sunucu);

// Dil ayarlaması
$db->query("SET NAMES utf8");

/* Son Eklenen Kullanıcının Sistemden Çekilmesini Gösteren Bir Örnek */
// $kullanici = $db->get_row("SELECT ad,soyad FROM kullanici ORDER BY id DESC LIMIT 1");
// echo "Adı: ". $kullanici->ad . " Soyadı: " . $kullanici->soyad . "<br />\n";

if(isset($_POST["name"]) && isset($_POST["lastname"])) {

	// Güvenlik önlemleri
	$name = $db->escape($_POST["name"]);
	$lastname = $db->escape($_POST["lastname"]);
	
	// Aşağıdaki satırlar potansiyel güvenlik açıkları yaratır.
	// $name = $_POST["name"];
	// $lastname = $_POST["lastname"];
	
	// Asıl satır
	$db->query("INSERT INTO `kullanici` (`ad`, `soyad`) VALUES ('".$name."', '".$lastname."');");
	
	echo "Yeni kayıt eklendi.";

}

/* SORUMLULUK REDDİ: AŞAĞIDAKİ SATIR CİDDİ GÜVENLİK AÇIKLARI İÇERİR. */
if(isset($_GET["id"])) {
	?><table><?php
	$sql = "SELECT * FROM `kullanici` WHERE id='".$_GET["id"]."'";
	echo "Yaratılan SQL cümleciği: " . $sql . "<br />\n";
	$sonuclar = $db->get_results($sql);
	//echo var_dump($sonuclar);
	if(!is_null($sonuclar)) {
		foreach($sonuclar as $sonuc) {
			echo "<tr>";
			echo "<td>".$sonuc->id."</td>"."<td>".$sonuc->ad."</td>"."<td>".$sonuc->soyad."</td>";
			echo "</tr>";
		}
	}
}
echo "</table>";
/* DENEYİN: index.php?id=1' OR 1='1 */
?>
</body>



