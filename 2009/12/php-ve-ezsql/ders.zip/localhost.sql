SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ticaret`
--
CREATE DATABASE `ticaret` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ticaret`;

-- --------------------------------------------------------

--
-- Table structure for table `kullanici`
--

CREATE TABLE IF NOT EXISTS `kullanici` (
  `ad` text NOT NULL,
  `soyad` text NOT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `kullanici`
--

INSERT INTO `kullanici` (`ad`, `soyad`, `id`) VALUES
('Umut', 'Benzer', 1),
('Hayrullah', 'Çokbilmiş', 2),
('Sercan', 'Kırbaş', 3),
('Haydar', 'Dümen', 4),
('Müge', 'Çalışkan', 11),
('Şaban', 'Ağzıbozuk', 12);

-- --------------------------------------------------------

--
-- Table structure for table `urun`
--

CREATE TABLE IF NOT EXISTS `urun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `urun_adi` text NOT NULL,
  `kullanici_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `urun`
--

INSERT INTO `urun` (`id`, `urun_adi`, `kullanici_id`) VALUES
(1, 'Soba', 1),
(2, 'Batarya', 1),
(3, 'Batarya', 2),
(4, 'Projektör', 2);
