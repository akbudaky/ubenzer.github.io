<?php 
ini_set ("session.use_only_cookies", "0");
session_start(); 
if(isset($_SESSION['views'])) {
	$_SESSION['views'] = $_SESSION['views']+ 1; 
} else {
	$_SESSION['views'] = 1; 
}
echo "views = ". $_SESSION['views']; 
?>