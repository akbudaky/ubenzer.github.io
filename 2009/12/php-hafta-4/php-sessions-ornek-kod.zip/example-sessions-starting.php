<?php 

$_SESSION["deneme"] = 'session_start kullanmadan önce bir değer atamak istiyorum. Ama bu nereye kaydolacak?';

/* Session ID ile id ataması session_starttan önce yapılmalıdır.
Eğer böyle bir atama yapılmazsa (ki ne gerek var?) PHP rastgele 
bir değer atacaktır. */
echo "<br />Session ID: ". session_id();  /* Bu satır henüz session başlamadığı için bir veri döndürmez. */

echo "<br />Session Name:". session_name("SEMSIPASAPASAJI");
/* Bu satır ile varsayılan PHPSESSID değerini değiştirmek mümkündür. Bu
değişiklik session_starttan önce yapılmalıdır. */

echo "<br />";
echo "<br /> Session Başladı";

session_start();
/* Kullanıcı için bir kimlik numarası belirlenir. (eğer session_id ile belirlenmişse, bu değer kullanılır.)
Bu kimlik numarası kullanıcıya gönderilmek üzere cookielere eklenir. Sessionların sunucu üzerinde tutalacağı
klasörde session bilgilerini tutacak bir dosya oluşturularak $_SESSIONS süper değişkeni ilklenir. */

/* Bu noktadan sonra aşağıdaki iki fonksiyon ile sadece değer öğrenilir. Değişiklik yapılamaz. */
echo "<br />Session ID:".  session_id();
echo "<br />Session Name:".  session_name();

echo "<br />";
echo "<br />";

if(isset($_SESSION['views'])) {
	$_SESSION['views'] = $_SESSION['views']+ 1; 
} else {
	$_SESSION['views'] = 1; 
}
echo "views = ". $_SESSION['views'];

echo '$_SESSION["deneme"]:' . $_SESSION["deneme"];

echo "Vardump: " . var_dump($_SESSION);

echo "Vardump: " . var_dump($_SERVER);

/* session_unset(); // Deneyin.
echo "<br />views = ". $_SESSION['views']; */
?>