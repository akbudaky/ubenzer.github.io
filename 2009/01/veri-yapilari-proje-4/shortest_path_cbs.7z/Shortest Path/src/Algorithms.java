import java.util.Vector;

public class Algorithms {

	/**
	 * @param: A��rl�kl� �izge
	 * @param: Ba�lang�� d���m numaras�
	 * @param: Biti� d���m numaras� (-1: t�m d���mleri bul)
	 * @return: En k�sa yol s�ras�n� i�eren dizi
	 * @see: http://www.cs.fit.edu/~ryan/java/programs/graph/Dijkstra-java.html
	 * @author: UB
	 */
	/* Kaynak kodunda de�i�iklikler ve eklemeler yap�lm��t�r. */
	public static int[] dijkstra(WeightedGraph G, int s, int f) {
		final int[] dist = new int[G.size()];
		final int[] pred = new int[G.size()];
		final boolean[] visited = new boolean[G.size()];

		for (int i = 0; i < dist.length; i++) {
			dist[i] = Integer.MAX_VALUE;
		}
		dist[s] = 0;

		for (int i = 0; i < dist.length; i++) {
			final int next = minVertex(dist, visited);
			
			/* �izge ba�l� de�ilse yol bulunamaz. */
			if (next == -1) {
				for (int a = 0; a < pred.length; a++) {
					pred[a] = -1;
				}
				return pred;
			}
			visited[next] = true;

			/* E�er istedi�imiz �ehre ula�m��sak devam etmemize gerek yok. */
			if (next == f)
				return pred;

			final int[] n = G.neighbors(next);
			for (int j = 0; j < n.length; j++) {
				final int v = n[j];
				final int d = dist[next] + G.getWeight(next, v);
				if (dist[v] > d) {
					dist[v] = d;
					pred[v] = next;
				}
			}
		}
		return pred;
	}

	/**
	 * @param: A��rl�kl� �izge
	 * @param: Ba�lang�� d���m numaras�
	 * @return: MST bulunduktan sonra d���mler aras� ba�lant�lar� i�eren dizi
	 * @see: http://www.cs.fit.edu/~ryan/java/programs/graph/Prim-java.html
	 * @author: �zlem
	 */
	public static int[] prim(WeightedGraph G, int s) {
		final int[] dist = new int[G.size()];
		final int[] pred = new int[G.size()];
		final boolean[] visited = new boolean[G.size()];

		for (int i = 0; i < dist.length; i++) {
			dist[i] = Integer.MAX_VALUE;
		}
		dist[s] = 0;

		for (int i = 0; i < dist.length; i++) {
			final int next = minVertex(dist, visited);
			/* Yol bulunamazsa */
			if (next == -1) {
				for (int a = 0; a < pred.length; a++) {
					pred[a] = -1;
				}
				return pred;
			}
			visited[next] = true;

			final int[] n = G.neighbors(next);
			for (int j = 0; j < n.length; j++) {
				final int v = n[j];
				final int d = G.getWeight(next, v);
				if (dist[v] > d) {
					dist[v] = d;
					pred[v] = next;
				}
			}
		}
		return pred;
	}

	/**
	 * @param: Uzakl�k dizisi
	 * @param: Gezilme durumu dizisi
	 * @return: Gezilmeyen en yak�n d���m
	 * @see http://www.cs.fit.edu/~ryan/java/programs/graph/Dijkstra-java.html
	 */
	private static int minVertex(int[] dist, boolean[] v) {
		int x = Integer.MAX_VALUE;
		int y = -1;
		for (int i = 0; i < dist.length; i++) {
			if (!v[i] && dist[i] < x) {
				y = i;
				x = dist[i];
			}
		}
		return y;
	}
	
	/**
	 * @param: A��rl�kl� �izge
	 * @param: En k�sa yol bilgilerini i�eren dizi
	 * @param: Ba�lang�� d���m�
	 * @param: Biti� d���m�
	 * @return: Ba�lang�� ile biti� aras�ndaki d���m adlar� vekt�r�
	 * @author: �zlem
	 */
	public static Vector<String> path(WeightedGraph G, int[] pred, int s, int e) {
		final Vector<String> path = new Vector<String>();
		int x = e;
		while (x != s) {
			path.add(0, G.getLabel(x));
			x = pred[x];
		}
		path.add(0, G.getLabel(s));
		return path;
	}

	/**
	 * @param: A��rl�kl� �izge
	 * @return: �izgenin y�nl� olup olmad���
	 * @author: H�ss
	 */
	public static boolean isDirected(WeightedGraph G) {
		for (int i = 0; i < G.size(); i++) {
			for (int x = 0; x < G.size(); x++) {
				if (G.getWeight(i, x) != G.getWeight(x, i)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * @param: A��rl�kl� �izge
	 * @param: Ba�lang�� d���m numaras�
	 * @return: BFS ile gezilince olu�acak d���m s�ras�
	 * @author: Didem
	 */
	public static int[] bfs(WeightedGraph w, int startNode) {
		BListe kuyruk = new BListe();
		boolean gezildi[] = new boolean[w.size()];
		int sonuc[] = new int[w.size()];

		for (int i = 1; i < w.size(); i++) {
			sonuc[i] = -1; /* E�er �izge ba�l� de�ilse, yollar -1 kal�r. */
			gezildi[i] = false;
		}

		kuyruk.ekle(startNode);
		gezildi[startNode] = true;
		int indis = 0;
		while (!kuyruk.bosMu()) {
			sonuc[indis] = kuyruk.cikar();
			int b[] = w.neighbors(sonuc[indis]);
			for (int a = 0; a < b.length; a++) {
				if (!gezildi[b[a]]) {
					kuyruk.ekle(b[a]);
				}
				gezildi[b[a]] = true;

			}
			indis++;
		}

		return sonuc;
	}
}
