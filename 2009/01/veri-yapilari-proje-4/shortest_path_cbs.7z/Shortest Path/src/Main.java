import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;

public class Main {
	public static WeightedGraph wg;

	/**
	 * Dosyadan veri okur.
	 * 
	 * @author: UB
	 * @link: http://www.roseindia.net/java/beginners/java-read-file-line-by-line.shtml
	 */
	public static void load() {
		/*
		 * iller.txt okunmas�
		 * 
		 * iller.txt illerin ad�n� (ve belki de say�s�n�) tutan dosyad�r.
		 * Dosyan�n a�a��daki iki formattan birinde olmas� gerekir:
		 * 
		 * FORMAT 1: 5 Antalya �zmir Manisa Ankara �stanbul Paris
		 * 
		 * (be� �ehir olmas� gerekmemektedir, 5 say�sal ifadesi g�rmezden
		 * gelinecektir.)
		 * 
		 * FORMAT 2: Antalya �zmir Manisa Ankara �stanbul Hakkari
		 */
		Vector<String> sehirAdlari = new Vector<String>();
		try {
			FileInputStream fstream = new FileInputStream("iller.txt");

			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			/*
			 * �lk sat�rda �ehrin ad� yerine �ehir say�s� verildiyse sisteme
			 * ekleme.
			 */
			/*
			 * B�ylece hem �ehir say�s� verilen hem verilmeyen dosyalar i�in
			 * uyumluluk sa�lan�r.
			 */
			if ((strLine = br.readLine()) != null) {
				if (!isParsableToInt(strLine)) {
					sehirAdlari.add(strLine);
				}
			}
			while ((strLine = br.readLine()) != null) {
				sehirAdlari.add(strLine);
			}
			in.close();
		} catch (Exception e) {
			System.out.println("iller.txt okunamad�.");
		}

		/*
		 * maliyet.txt okunmas�
		 * 
		 * maliyet.txt iller aras�ndaki maliyetleri tutan dosyad�r. E�er iller
		 * aras�nda ba�lant� yoksa -1 kullan�lmal�d�r. Dosyada ilsay�s�^2 tane
		 * say�sal (bu projede integer) de�er olmal�d�r. Daha az oldu�u durumda
		 * program kalan de�erleri -1 olarak de�erlendirecektir. Ay �ekilde
		 * dosya okunamad���nda da hi�bir il aras�nda ba�lant� olmad���
		 * d���n�lecektir. E�er ilsay�s�^2'den fazla de�er varsa sondaki
		 * de�erler ihmal edilecektir. De�erlerin sat�rlara do�ru yerle�mesinin
		 * ya da arada fazla bo�luk olmas�n�n bir anlam� yoktur. Aralarda
		 * ge�ersiz de�erler varsa (�rnek 1 2 3 SFGSG 45) bu de�erler -1 olarak
		 * de�erlendirilecektir.
		 */
		wg = new WeightedGraph(sehirAdlari.size());
		for (int i = 0; i < sehirAdlari.size(); i++) {
			wg.setLabel(i, sehirAdlari.elementAt(i));
		}

		String maliyetData = "";
		try {
			FileInputStream fstream = new FileInputStream("maliyet.txt");
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;

			/*
			 * T�m dosya sat�r sat�r okunur. B�ylece sat�r sonu karakterlerinden
			 * (CR LF) kurtulunmu� olur.
			 */
			while ((strLine = br.readLine()) != null) {
				maliyetData = maliyetData + strLine + ' ';
				/*
				 * E�er sona bo�luk eklenmezse alt sat�ra alt sat�r ile �st
				 * sat�r birle�ik kabul edilir.
				 */
			}
			in.close();
		} catch (Exception e) {
			System.out.println("maliyet.txt okunamad�.");
		}

		StringTokenizer st = new StringTokenizer(maliyetData);

		for (int x = 0; x < sehirAdlari.size(); x++) {
			for (int y = 0; y < sehirAdlari.size(); y++) {
				String temp;
				if (st.hasMoreTokens()) {
					temp = st.nextToken();
					if (isParsableToInt(temp) && Integer.parseInt(temp) > 0) {
						wg.addEdge(x, y, Integer.parseInt(temp));
					}
				}
			}
		}
	}

	/**
	 * @author: Didem
	 */
	public static void main(String[] args) {

		load();

		Gorsel g = new Gorsel();
		g.setVisible(true);

	}

	/**
	 * Ekrana yazd�r�lmaya uygun bir dizaynda maliyet dizisinin i�indeki
	 * bilgileri g�nderir.
	 * 
	 * @author Didem
	 * @return String
	 */
	public static String maliyetDiziScreen() {
		String cikti = "";

		for (int i = 0; i < wg.size(); i++) {
			cikti = cikti + wg.getLabel(i) + "\t\t";
			for (int x = 0; x < wg.size(); x++) {
				cikti = cikti + wg.getWeight(i, x) + "\t";
			}
			cikti = cikti + "\n";

		}

		return cikti;
	}

	/**
	 * D���m�n i�indeki bilgileri ekrana yaz�lmaya uygun formatta
	 * g�nderir.
	 * @param: D���m no
	 * @return: String
	 * @author: Didem
	 */
	public static String getNodeDetails(int nid) {
		if (nid < 0 || nid >= wg.size()) {
			return "Ge�ersiz d���m numaras�.";
		}

		String cikti = "";

		cikti = cikti + "K��e numaras�: " + nid + "\n";
		cikti = cikti + "�ehir ad�: " + wg.getLabel(nid) + "\n";
		cikti = cikti + "Giden ba�lant�lar: (" + wg.neighbors(nid).length
				+ ")\n";
		for (int a = 0; a < wg.neighbors(nid).length; a++) {
			cikti = cikti + "(" + wg.neighbors(nid)[a] + ") "
					+ wg.getLabel(wg.neighbors(nid)[a]) + ": "
					+ wg.getWeight(nid, wg.neighbors(nid)[a]) + "\n";
		}

		cikti = cikti + "Gelen ba�lant�lar: (" + wg.incoming(nid).length
				+ ")\n";
		for (int a = 0; a < wg.incoming(nid).length; a++) {
			cikti = cikti + "(" + wg.incoming(nid)[a] + ") "
					+ wg.getLabel(wg.incoming(nid)[a]) + ": "
					+ wg.getWeight(wg.incoming(nid)[a], nid) + "\n";
		}

		return cikti;

	}

	/**
	 * @param: Ba�lang�� d���m no
	 * @return: String
	 * @author: �zlem
	 */
	public static String bfs(int start) {
		if (start < 0 || start >= wg.size()) {
			return "Ge�ersiz d���m numaras�.";
		}
		String cikti = "";
		int sonuc[] = Algorithms.bfs(wg, start);
		for (int n = 0; n < sonuc.length; n++) {
			if (sonuc[n] == -1) {
				cikti = cikti + "�izgenin devam�na ba�lant� bulunamad�.";
				break;
			} else {
				cikti = cikti + "[" + wg.getLabel(sonuc[n]) + "]\n";
			}
		}
		return cikti;
	}

	/**
	 * @param: Ba�lang�� d���m no
	 * @return: String
	 * @author: UB
	 */
	public static String mst(int start) {
		if (start < 0 || start >= wg.size()) {
			return "Ge�ersiz d���m numaras�.";
		}
		String cikti = "";
		if (Algorithms.isDirected(wg)) {
			return "Prim algoritmas� sadece y�ns�z algoritmalarda\n�al���r. "
					+ "Edmonds algoritmas� ne kadar\nyap�lmaya �al���ld�ysa da,\n"
					+ "pek ba�ar�l� oldu�umuz\ns�ylenemez.";
		}

		int sonuc[] = Algorithms.prim(wg, start);
		if (sonuc[0] == -1) {
			return "Yol yok";
		}
		for (int i = 0; i < wg.size(); i++) {
			cikti = cikti + wg.getLabel(i) + "\t\t";
			for (int x = 0; x < wg.size(); x++) {
				cikti = cikti
						+ ((sonuc[i] == x || sonuc[x] == i) && (i != x) ? wg
								.getWeight(i, x) : "0") + "\t";
			}
			cikti = cikti + "\n";
		}

		return cikti;
	}

	/**
	 * @param: Ba�lang�� d���m no
	 * @param: Biti� d���m no (-1 hepsi)
	 * @return: String
	 * @author: �zlem
	 */
	public static String dijkstra(int start, int finish) {
		if (start < 0 || start >= wg.size()) {
			return "Ge�ersiz birinci d���m numaras�.";
		}
		if (finish < -1 || finish >= wg.size()) {
			return "Ge�ersiz ikinci d���m numaras�.";
		}

		String cikti = "";
		Vector<String> Sehirler = new Vector<String>();
		int yol[] = Algorithms.dijkstra(wg, start, finish);
		if (yol[0] == -1) {
			return "Yol yok";
		}
		if (finish == -1) {
			for (int n = 0; n < wg.size(); n++) {
				if (n == start) {
					continue;
				}
				Sehirler = Algorithms.path(wg, yol, start, n);

				for (String x : Sehirler) {
					cikti = cikti + "[" + x + "] ";
				}
				cikti = cikti + "\n";
			}
		} else {
			Sehirler = Algorithms.path(wg, yol, start, finish);
			for (String x : Sehirler) {
				cikti = cikti + "[" + x + "] ";
			}
			cikti = cikti + "\n";
		}

		return cikti;
	}

	/**
	 * @param: String bir de�er
	 * @return: Stringin bir tam say� olup olmad���
	 */
	public static boolean isParsableToInt(String in) {
		try {
			Integer.parseInt(in);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

}
