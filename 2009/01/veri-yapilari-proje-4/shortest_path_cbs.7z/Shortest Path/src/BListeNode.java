
public class BListeNode {
	public int node;
	public BListeNode sonraki;
	
	public BListeNode (int node) {
		this.node = node;
		sonraki = null;
	}
}
