import java.util.Stack;

/** 
 * �denek yetersizli�inden (karma��k) tamamlanamayan
 * (karma��k) algotimad�r. (karma��k)
 * 
 * Bunun yerine Prim algoritmas� ile MST bulunsa da, Prim digraflarda
 * hatal� �al��maktad�r.
 * 
 * Edmons algoritmas� a�a��daki kaynaktan uyarlanmaya �al���lm��t�r:
 * @link http://www.ce.rit.edu/~sjyeec/dmst.html
 * @author UB
 * @deprecated
 * */
public class Edmonds {
	
	/**
	 * @param A��rl�kl� �izge
	 * @param K�k vertex
	 * @author UB
	 * @deprecated
	 * */
	public static void mst(WeightedGraph w, int root) {
		/* Ad�m 0: �zerinde oynama yapmak i�in �izgenin bir kopyas�
		 * al�n�r. Bu kopya sadece referans kopyas� de�il, i�eri�in
		 * bire bir kopas�d�r.
		 */
		WeightedGraph mst = (WeightedGraph)w.clone();
		
		/* Ad�m 1: K�k d���me girenler silinir. */
		int gelenler[] = mst.incoming(root);
		for(int i:gelenler) {
			mst.removeEdge(i, root);			
		}
		
		/* Ad�m 2: K�k hari� t�m d���mler i�in, d���me giren en
		 * k���k edge hari� di�erleri silinir.
		 */
		
		for (int i=0;i<w.size();i++) {
			if (i==root) {
				continue;
			}
			int incom[] = mst.incoming(i);
			int minVal = Integer.MAX_VALUE;
			int minVertx = -1;
			for(int x=0;x<incom.length;x++) {
				if(incom[x]<minVal) {
					minVal = incom[x];
					minVertx = x; 
				}
				w.removeEdge(x, i);
			}
			w.addEdge(minVertx, i, minVal);
		}
		
		/* Ad�m 3: Hi� kapal� devre var m�, kontrol et. */
		for (int i=0;i<w.size();i++) {
			int sonuc[] = cdetect(w, i);
			boolean devre_mi = false;
			for(int x=0;x<sonuc.length;x++) {
				if(sonuc[x] == -1) {
					devre_mi = true;
					break;
				}				
			}
			
			int orijinal_graph[] = new int[sonuc.length];
			int sayac = 0;
			
			/* Devre oldu�unu bulduk. �imdi gerekli i�lemi yapaca��z.
			 * Yani devredekiler tek bir vertex gibi d���n�l�p
			 * form�le g�re a��rl�klar tekrar hesaplanacak.
			 * 
			 * vs vs..
			 */	
				
				
				
		}
			
			
			
			
			
		
		
		
	}
	
	/** 
	 * Devre olup olmad���n� denetler. Bunun i�in @int node'den ba�layarak
	 * �izge DFS gezilir. E�er gezilen vertexlerden birine geri d�n�yorsak
	 * devre var demektir.
	 * @param A��rl�kl� �izge
	 * @param Ba�lang�� vertexi
	 * @return Devre i�inde olan vertex numaralar�
	 * @author UB
	 * @deprecated
	 * */
	public static int[] cdetect(WeightedGraph w, int node) {
		boolean visited[] = new boolean[w.size()];
		int dondurulecek[] = new int[w.size()];
		for(int i=0;i<visited.length;i++) {
			visited[i] = false;
			dondurulecek[i] = -1;
		}
		int sayac = 0;
		Stack<Integer> nodes = new Stack<Integer>();
		
		dondurulecek[sayac++] = node;
		int rootkomsu[] = w.neighbors(node);
		for (int x=0; x<rootkomsu.length;x++) {
			nodes.push(x);			
		}
		visited[node] = true;
		
		while (!nodes.empty()) {
			int current_node = nodes.pop();
			if(visited[current_node]) {
				return dondurulecek;
			}
			visited[current_node] = true;
			dondurulecek[sayac++] = current_node;
			int currentkomsu[] = w.neighbors(current_node);
			for (int x=0; x<currentkomsu.length;x++) {
				nodes.push(x);
			}			
		}
		
		return dondurulecek;
	}	
	
}
