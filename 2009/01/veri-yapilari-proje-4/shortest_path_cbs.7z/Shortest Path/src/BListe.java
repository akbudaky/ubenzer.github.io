/** BListe
 * @author: UB
 * 
 * Kuyruk olu�turmak i�in kullan�lan s�n�ft�r.
 * Banka kuyru�u �devinden haz�r al�n�p �zerinde
 * oynamalar yap�lm��t�r.
 */

public class BListe {
	private BListeNode bas; // Kuyru�un ilk eleman�n�n referans�
	private BListeNode son; // Kuyru�un son eleman�n�n referans�

	/* �lk yarat�ld���nda bo� olan bir kuyruk */
	public BListe() {
		bas = null;
		son = null;
	}

	public void ekle(int node) {
		BListeNode yeni = new BListeNode(node);
		if (son != null) {
			son.sonraki = yeni;
			son = yeni;
		} else {
			bas = yeni;
			son = yeni;
		}
	}

	public int cikar() {
		BListeNode dondurulecek = bas;
		if (bas != null) {
			bas = bas.sonraki;
		}
		if (bas == null) {
			son = null;
		}
		if(dondurulecek == null) {
			return -1;
		}
		return dondurulecek.node;
	}

	/* Kuyru�un bitip bitmedi�ini d�nd�r�r. */
	public boolean bosMu() {
		return (bas == null ? true : false);
	}

}
