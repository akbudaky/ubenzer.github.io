import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.TextArea;
import java.awt.Rectangle;
import java.awt.Label;
import java.awt.TextField;
import javax.swing.JButton;
import java.awt.Point;

public class Gorsel extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private TextArea textMatris = null;
	private Label etiketMatris = null;
	private Label etiketDugumBilgiler = null;
	private TextField textDugumNo = null;
	private JButton butonGoster = null;
	private TextArea textDugumBilgi = null;
	private TextField textDij1 = null;
	private Label labeldij1 = null;
	private TextField textDij2 = null;
	private Label etiketDij2 = null;
	private JButton butonDij = null;
	private JButton butonBreFirst = null;
	private Label etiletBre2 = null;
	private TextField textBre = null;
	private JButton butonMST = null;
	private Label etkiketMST = null;
	private TextArea textResult = null;
	private JButton butonYenile = null;
	private Label etiketFile = null;
	private TextField textPrim = null;
	/**
	 * This is the default constructor
	 */
	public Gorsel() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(640, 510);
		this.setResizable(false);
		this.setContentPane(getJContentPane());
		this.setTitle("Proje 4 [�BS]");
		textMatris.setText(Main.maliyetDiziScreen());
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			etiketFile = new Label();
			etiketFile.setBounds(new Rectangle(377, 461, 154, 15));
			etiketFile.setText("Dosyalar� tekrardan okuyun");
			etkiketMST = new Label();
			etkiketMST.setBounds(new Rectangle(237, 294, 294, 16));
			etkiketMST.setText("�ehrini k�k d���m alarak Prim algortimas� ile MST'yi");
			etiletBre2 = new Label();
			etiletBre2.setBounds(new Rectangle(151, 265, 381, 18));
			etiletBre2.setText("nolu/isimli �ehirden ba�layarak �nce geni�li�ine (breath first) dola�");
			etiketDij2 = new Label();
			etiketDij2.setBounds(new Rectangle(375, 242, 154, 15));
			etiketDij2.setText("aras�ndaki en k�sa yolu bul!");
			labeldij1 = new Label();
			labeldij1.setBounds(new Rectangle(151, 244, 111, 15));
			labeldij1.setName("label2");
			labeldij1.setText("nolu/isimli �ehir ile");
			etiketDugumBilgiler = new Label();
			etiketDugumBilgiler.setBounds(new Rectangle(384, 11, 146, 15));
			etiketDugumBilgiler.setText("no/isimli �ehrin bilgilerini");
			etiketMatris = new Label();
			etiketMatris.setBounds(new Rectangle(10, 11, 290, 14));
			etiketMatris.setText("A��rl�k matrisi: (0 ba�lant�s�z anlam�na gelir.)");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getTextMatris(), null);
			jContentPane.add(etiketMatris, null);
			jContentPane.add(etiketDugumBilgiler, null);
			jContentPane.add(getTextDugumNo(), null);
			jContentPane.add(getButonGoster(), null);
			jContentPane.add(getTextDugumBilgi(), null);
			jContentPane.add(getTextDij1(), null);
			jContentPane.add(labeldij1, null);
			jContentPane.add(getTextDij2(), null);
			jContentPane.add(etiketDij2, null);
			jContentPane.add(getButonDij(), null);
			jContentPane.add(getButonBreFirst(), null);
			jContentPane.add(etiletBre2, null);
			jContentPane.add(getTextBre(), null);
			jContentPane.add(getButonMST(), null);
			jContentPane.add(etkiketMST, null);
			jContentPane.add(getTextResult(), null);
			jContentPane.add(getButonYenile(), null);
			jContentPane.add(etiketFile, null);
			jContentPane.add(getTextPrim(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes textMatris	
	 * 	
	 * @return java.awt.TextArea	
	 */
	private TextArea getTextMatris() {
		if (textMatris == null) {
			textMatris = new TextArea();
			textMatris.setBounds(new Rectangle(10, 29, 291, 200));
			textMatris.setEditable(false);
		}
		return textMatris;
	}

	/**
	 * This method initializes textDugumNo	
	 * 	
	 * @return java.awt.TextField	
	 */
	private TextField getTextDugumNo() {
		if (textDugumNo == null) {
			textDugumNo = new TextField();
			textDugumNo.setBounds(new Rectangle(320, 9, 60, 18));
			textDugumNo.setText("0");
		}
		return textDugumNo;
	}

	/**
	 * This method initializes butonGoster	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getButonGoster() {
		if (butonGoster == null) {
			butonGoster = new JButton();
			butonGoster.setBounds(new Rectangle(535, 7, 85, 20));
			butonGoster.setText("g�ster");
			butonGoster.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if(Main.isParsableToInt(textDugumNo.getText())) {
						textDugumBilgi.setText(Main.getNodeDetails(Integer.parseInt(textDugumNo.getText())));
					} else {
						if(Main.wg.labelToVertex(textDugumNo.getText()) != -1) {
							textDugumBilgi.setText(Main.getNodeDetails(Main.wg.labelToVertex(textDugumNo.getText())));
						} else {
							textDugumBilgi.setText("B�yle bir �ehir yok.");
						}						
					}
				}
			});
		}
		return butonGoster;
	}

	/**
	 * This method initializes textDugumBilgi	
	 * 	
	 * @return java.awt.TextArea	
	 */
	private TextArea getTextDugumBilgi() {
		if (textDugumBilgi == null) {
			textDugumBilgi = new TextArea();
			textDugumBilgi.setBounds(new Rectangle(320, 30, 301, 200));
			textDugumBilgi.setEditable(false);
		}
		return textDugumBilgi;
	}

	/**
	 * This method initializes textDij1	
	 * 	
	 * @return java.awt.TextField	
	 */
	private TextField getTextDij1() {
		if (textDij1 == null) {
			textDij1 = new TextField();
			textDij1.setBounds(new Rectangle(45, 238, 97, 22));
			textDij1.setText("0");
		}
		return textDij1;
	}

	/**
	 * This method initializes textDij2	
	 * 	
	 * @return java.awt.TextField	
	 */
	private TextField getTextDij2() {
		if (textDij2 == null) {
			textDij2 = new TextField();
			textDij2.setBounds(new Rectangle(269, 239, 98, 20));
			textDij2.setText("t�m �ehirler");
		}
		return textDij2;
	}

	/**
	 * This method initializes butonDij	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getButonDij() {
		if (butonDij == null) {
			butonDij = new JButton();
			butonDij.setBounds(new Rectangle(536, 237, 85, 21));
			butonDij.setText("Dijkstra!");
			butonDij.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int d1=-1,d2=-1;
					if(!Main.isParsableToInt(textDij1.getText())) {
						if(Main.wg.labelToVertex(textDij1.getText()) != -1) {
							d1 = Main.wg.labelToVertex(textDij1.getText());
						} else {
							textResult.setText("Birinci �ehir yok.");
						}
					} else {
						d1 = Integer.parseInt(textDij1.getText());
					}

					if(!Main.isParsableToInt(textDij2.getText())) {
						if(Main.wg.labelToVertex(textDij2.getText()) != -1) {
							d2 = Main.wg.labelToVertex(textDij2.getText());
						} else if (textDij2.getText().equalsIgnoreCase("t�m �ehirler")) {
							textResult.setText(Main.dijkstra(d1,-1));
						} else {
							textResult.setText("�kinci �ehir yok.");
						}
					} else {
						d2 = Integer.parseInt(textDij2.getText());
					}
					
					textResult.setText(Main.dijkstra(d1,d2));

				}
			});
		}
		return butonDij;
	}

	/**
	 * This method initializes butonBreFirst	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getButonBreFirst() {
		if (butonBreFirst == null) {
			butonBreFirst = new JButton();
			butonBreFirst.setText("Dola�");
			butonBreFirst.setSize(new Dimension(85, 21));
			butonBreFirst.setLocation(new Point(537, 264));
			butonBreFirst.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if(Main.isParsableToInt(textBre.getText())) {
						textResult.setText(Main.bfs(Integer.parseInt(textBre.getText())));
					} else {
						if(Main.wg.labelToVertex(textBre.getText()) != -1) {
							textResult.setText(Main.bfs(Main.wg.labelToVertex(textBre.getText())));
						} else {
							textResult.setText("B�yle bir �ehir yok.");
						}						
					}
				}
			});
		}
		return butonBreFirst;
	}

	/**
	 * This method initializes textBre	
	 * 	
	 * @return java.awt.TextField	
	 */
	private TextField getTextBre() {
		if (textBre == null) {
			textBre = new TextField();
			textBre.setBounds(new Rectangle(45, 264, 98, 20));
			textBre.setText("0");
		}
		return textBre;
	}

	/**
	 * This method initializes butonMST	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getButonMST() {
		if (butonMST == null) {
			butonMST = new JButton();
			butonMST.setText("Bul");
			butonMST.setSize(new Dimension(85, 21));
			butonMST.setLocation(new Point(537, 292));
			butonMST.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if(Main.isParsableToInt(textPrim.getText())) {
						textResult.setText("Kolay kar��la�t�r�lmas� i�in sonu�lar sa� �st kutudad�r.");
						textDugumBilgi.setText(Main.mst(Integer.parseInt(textPrim.getText())));
					} else {
						textResult.setText("Kolay kar��la�t�r�lmas� i�in sonu�lar sa� �st kutudad�r.");
						textDugumBilgi.setText(Main.mst(Main.wg.labelToVertex(textPrim.getText())));
					}				
				}
			});
		}
		return butonMST;
	}

	/**
	 * This method initializes textResult	
	 * 	
	 * @return java.awt.TextArea	
	 */
	private TextArea getTextResult() {
		if (textResult == null) {
			textResult = new TextArea();
			textResult.setBounds(new Rectangle(9, 321, 612, 126));
			textResult.setEditable(false);
			textResult.setText("Sonu�lar burada g�r�nt�lenecek.");
		}
		return textResult;
	}

	/**
	 * This method initializes butonYenile	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getButonYenile() {
		if (butonYenile == null) {
			butonYenile = new JButton();
			butonYenile.setText("Yenile");
			butonYenile.setSize(new Dimension(85, 21));
			butonYenile.setLocation(new Point(533, 454));
			butonYenile.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Main.load();
					textMatris.setText(Main.maliyetDiziScreen());
				}
			});
		}
		return butonYenile;
	}

	/**
	 * This method initializes textPrim	
	 * 	
	 * @return java.awt.TextField	
	 */
	private TextField getTextPrim() {
		if (textPrim == null) {
			textPrim = new TextField();
			textPrim.setBounds(new Rectangle(147, 290, 86, 21));
			textPrim.setText("0");
		}
		return textPrim;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
