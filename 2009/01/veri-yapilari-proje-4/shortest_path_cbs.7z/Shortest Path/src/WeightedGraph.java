/**
 * @see: http://www.cs.fit.edu/~ryan/java/programs/graph/WeightedGraph-java.html
 */
public class WeightedGraph implements Cloneable {
	/* Kaynak kodunda de�i�iklikler ve eklemeler yap�lm��t�r. */
	
	private int[][] edges;
	private String[] labels;
	
	/**
	 * Referans de�il, �izgenin tamam�n� bire bir kopyalamaya �al��an
	 * bir metotdur.
	 * @deprecated
	 * @author: UB
	 */
	public Object clone() {
        Cloneable theClone = new WeightedGraph(this.edges.clone(), this.labels.clone());
        return theClone;
    }

	public WeightedGraph(int n) {
		edges = new int[n][n];
		labels = new String[n];
	}
	
	public WeightedGraph(int[][] egdes, String[] labels) {
		this.edges = egdes;
		this.labels = labels;
	}

	public int size() {
		return labels.length;
	}

	public void setLabel(int vertex, String label) {
		labels[vertex] = label;
	}

	public String getLabel(int vertex) {
		return labels[vertex];
	}

	public void addEdge(int source, int target, int w) {
		edges[source][target] = w;
	}

	public void removeEdge(int source, int target) {
		edges[source][target] = 0;
	}

	public int getWeight(int source, int target) {
		return edges[source][target];
	}

	public int[] neighbors(int vertex) {
		int count = 0;
		for (int i = 0; i < edges[vertex].length; i++) {
			if (edges[vertex][i] > 0)
				count++;
		}
		final int[] answer = new int[count];
		count = 0;
		for (int i = 0; i < edges[vertex].length; i++) {
			if (edges[vertex][i] > 0)
				answer[count++] = i;
		}
		return answer;
	}
	
	/** Bir k��eye gelen ba�lant�lar� bulur. 
	 * @author H�ss
	 * @param vertex number
	 * @return incoming links
	 */
	public int[] incoming(int vertex) {
		int count = 0;
		for (int i=0;i<labels.length;i++) {
			if(edges[i][vertex] > 0) {
				count++;
			}
		}
		final int[] answer = new int[count];
		count = 0;
		for (int i=0;i<labels.length;i++) {
			if(edges[i][vertex] > 0) {
				answer[count++] = i;
			}
		}		
		return answer;
	}
	
	/**Etiketin k��e numras�n� bulur. Bulamazsa -1 g�nderir.
	 * @author H�ss
	 * @param vertex label
	 * @return vertex number
	 */
	public int labelToVertex(String name) {
		for(int i=0;i<labels.length;i++) {
			if(labels[i].equalsIgnoreCase(name)) {
				return i;
			}
		}
		return -1;
	}
}
