package proje.bootstrapper;
import proje.restaurant.Restaurant;
import proje.ui.Entry;
import proje.user.Administrator;
import proje.user.User;
import proje.util.SortableList;


public class Main {
    /* En Geniş İçerikli Kolleksiyonlar */
    public static final SortableList<User> users = new SortableList<User>();
    public static final SortableList<Restaurant> restaurants = new SortableList<Restaurant>();

    public static void main(String[] args) {
        /* İnit */
        System.out.println("   Çökmez Bilişim Restoran Sistemleri Gururla Sunar"   );
        System.out.println("------------------------------------------------------");
        System.out.println("05-06-7670 Umut BENZER   http://www.ubenzer.com/");
        System.out.println("05-0607699 Gül DELİORMAN http://www.guldeliorman.com/");
        System.out.println("05-07-8496 Özlem GÜRSES  null nıl nul zört zırt bırt");
        System.out.println("------------------------------------------------------");
        
        /* Projenin rahat kontrolü için rastgele bilgiler eklenir. */
        new Administrator("Fred","Çakmaktaş");
        PlaceHolder.addRandomCustomer(250);
        PlaceHolder.addRandomRestaurant(50);

        for(Restaurant r: restaurants) {
            PlaceHolder.addRandomYemek(r, (int)(Math.random() * 25) + 1);
            PlaceHolder.addRandomMenu(r, (int)(Math.random() * 40) + 1);
        }

        PlaceHolder.generateRandomOrder(1000);

        /* Arayüzü Göster */
        Entry e=new Entry();
        e.setVisible(true);

	}

}
