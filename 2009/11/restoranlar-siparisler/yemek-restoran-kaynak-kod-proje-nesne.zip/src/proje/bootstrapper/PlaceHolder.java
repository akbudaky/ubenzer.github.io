package proje.bootstrapper;
import java.util.Date;
import java.util.Vector;
import proje.restaurant.Menu;
import proje.restaurant.Order;
import proje.restaurant.Restaurant;
import proje.restaurant.Yemek;
import proje.user.Customer;
import proje.user.Operator;
import proje.user.User;
import proje.util.CONSTANT;

public class PlaceHolder {
	@SuppressWarnings({ "deprecation", "unchecked" })
	public static void generateRandomOrder(int orderCount){
		System.out.println("Rastgele sipariş yaratılıyor. Bu işlem biraz zaman alabilir...");
        Vector yemekVeMenuler= new Vector();//Rastgele seçilen Restoranın içinden rastgele seçilen yemek ve menülerin tutulacağı vektör
        Vector<String> yorumlar=new Vector<String>();
        
        yorumlar.add("Hayatımda yediğim en güzel yemekti.");
        yorumlar.add("Mmm nefiss...");
        yorumlar.add("Pardon tarifini alma şansım var mı acaba?");
        yorumlar.add("Evde denedim olmadı, neyi eksik yaptım acaba...");
        yorumlar.add("Ben size acı sos da ekleyin dedim acı sos macı sos yoktu ne biçim servis bu!");
        yorumlar.add("Sizin yüzünüzden obez olacağım ne leziz yemekti öyle!");
        yorumlar.add("Kaç kere tembih ettiğim halde her seferinde salça da koyuyorsunuz artık sizden yiyecek almayacağım");
        yorumlar.add("Beşamel sos dışındakileri beğendim, tavsiye ederim.");
        yorumlar.add("Kendime sormak zorunda kaldım acaba Kanada'da mı yaşıyorum diye... Çok yavaş servisti.");
        yorumlar.add("Van münüt, daha da yemem.");
        yorumlar.add("Aşçını da al git üleyn!");
        yorumlar.add("Aşçılık yan gelip yatma yeri değildir.");
        yorumlar.add("Tek kelimeyle nefisti !");
        
        User u;
        Customer c;
        Order o;
        int orderStatusVariable,vote,voteNumber;
        Date orderDate;
        Date deliverDate;
        while(orderCount>0){
            do{//rastgele müşteri seçilir
                u=Main.users.elementAt( (int)(Math.random()*(Main.users.size())) );
            }while(!(u instanceof Customer));
            c=(Customer)u;
            Restaurant r=Main.restaurants.elementAt((int)(Math.random()*(Main.restaurants.size())));//rastgele restoran seçilir
            yemekVeMenuler.add(r.getMenuler().elementAt((int)(Math.random()*(r.getMenuler().size()))));
            yemekVeMenuler.add(r.getYemekler().elementAt((int)(Math.random()*(r.getYemekler().size()))));
            o = new Order(c,r,yemekVeMenuler);
            orderStatusVariable = (int)(Math.random() * 10);
            orderDate = new Date();
            orderDate.setMonth((int)(Math.random()*11)+1);
            orderDate.setDate((int)(Math.random()*30)+1);
            orderDate.setHours((int)(Math.random()*59)+1);
            orderDate.setMinutes((int)(Math.random()*59)+1);
            orderDate.setSeconds((int)(Math.random()*59)+1);
            o.setOrderTime(orderDate);


            switch(orderStatusVariable){
                case 1:               
                    //Sipariş yolda
                    o.setOrderInProgress();
                    break;
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7://Sipariş iletildi

                    o.setOrderDelivered();
                    deliverDate =new Date();
                    deliverDate.setYear(2009);
                    do{
                        deliverDate.setMonth(((int)(Math.random()*11)+1));
                        deliverDate.setDate((int)(Math.random()*30)+1);
                        deliverDate.setHours((int)(Math.random()*59)+1);
                        deliverDate.setMinutes((int)(Math.random()*59)+1);
                        deliverDate.setSeconds((int)(Math.random()*59)+1);
                   }while(deliverDate.getMonth() < orderDate.getMonth() || deliverDate.getDate()<orderDate.getDate() ||
                      deliverDate.getHours()<orderDate.getHours() || deliverDate.getMinutes()<orderDate.getMinutes()
                      || deliverDate.getSeconds()<orderDate.getSeconds());
                    o.setCompleteTime(deliverDate);

                    voteNumber=((int)(Math.random()*10));
                    if (voteNumber > 4) {
                    	vote=(int)(Math.random()*5);
                    	o.voteForHiz(vote);
                    }
                    
                    voteNumber=((int)(Math.random()*10));
                    if (voteNumber > 4) {
                    	vote=(int)(Math.random()*5);
                    	o.voteForLezzet(vote);
                    }
                    
                    voteNumber=((int)(Math.random()*10));
                    if (voteNumber > 4) {
                    	vote=(int)(Math.random()*4);
                    	o.voteForFiyat(vote);
                    }

                    if(((int)(Math.random()*2))==0){
                        o.setComment(yorumlar.elementAt((int)(Math.random()*yorumlar.size())));
                    }
                    break;
            }
            orderCount--;
        }
        System.out.println("Yaratıldı.");
    }
    public static void addRandomMenu(Restaurant r, int number) {
        Vector<String> v = new Vector<String>();
        v.add("Big King XXL");
        v.add("Big King");
        v.add("Büyük Menü");
        v.add("Akıllı Seçim");
        v.add("Ekonomik Seçim");
        v.add("Diyet Seçim");
        v.add("Şefin Önerisi");
        v.add("Günün Mönüsü");
        v.add("Amerikan Seçim");
        v.add("Türk Özel");
        v.add("Hafif Akşam Yemeği");
        v.add("Günün Menüsü");
        v.add("Şeften Seçmeler");
        v.add("İngiliz Usülü");
        v.add("Enerjik Menü");
        v.add("Tatlı Severler İçin Özel Menü");
        v.add("Yeni Menü");

        if (number > v.size()) { number = v.size(); }

        while(number > 0) {
            /* Menü içeriğini hazırla */
            Vector<Yemek> menuYemek = new Vector<Yemek>();

            for(int i = 0; i <= (int)(Math.random() * 4) + 1; i++) {
                menuYemek.add(r.getYemekler().elementAt((int)(Math.random() * r.getYemekler().size())));
            }

            int indis = (int)(Math.random() * number);
            String y = v.elementAt(indis);
            double f = (double)((int)(Math.random() * 23) + 0.99);
            r.addMenu(new Menu(y,f,menuYemek));
            v.removeElementAt(indis);
            number--;
        }

    }
    public static void addRandomYemek(Restaurant r, int number) {
        Vector<String> v = new Vector<String>();
        v.add("İskender döner");
        v.add("Domates çorbası");
        v.add("İmam Bayıldı");
        v.add("Mevsim Salatası");
        v.add("Tavuk ızgara");
        v.add("Çöp şiş");
        v.add("Kumpir");
        v.add("Kola");
        v.add("Suşi");
        v.add("Pizza");
        v.add("Ekşili Ördek Çorbası");
        v.add("Ahtapot Kavurma");
        v.add("Zeytin Sosuna Bulanmış Feta");
        v.add("Yayık ayranı");
        v.add("Buzlu çay");
        v.add("Çiğ Börek");
        v.add("Efsanevi Salçalı Kumru");
        v.add("Kutu ayran");
        v.add("Supangle");
        v.add("Keşkül");
        v.add("Helva");
        v.add("Enginar Yaprağına Yatırılmış Pekin Ördeği");
        v.add("Portakallı Ördek");
        v.add("Cacık");
        v.add("Şefin Sürprizi");
        v.add("Yoğurt");
        v.add("Günün Çorbası");
        v.add("Patates Kızartması");
        v.add("Hamburger");

        if (number > v.size()) { number = v.size(); }

        while(number > 0) {
            int indis = (int)(Math.random() * number);
            String y = v.elementAt(indis);
            double f = (double)((int)(Math.random() * 23) + 0.99);
            r.addYemek(new Yemek(y,f));
            v.removeElementAt(indis);
            number--;
        }
    }
    public static String generateRandomLastName() {
        String soyad[] = {"benzer", "kayalı", "gürses", "yaşar", "avşar","ürek","ergen","tayfur","tuğba",
                        "alkan", "anık","sert","andıç","yılmaz","şahin","kurt","çelik",
                        "boya","hüyük","güler","sever","ceylan"};

        /*
         * "" sayısının fazla olması, daha az ek seçilmesini sağlamaya
         * yöneliktir.
        */
        String ekleOnSoyad[] = {"öz","has","","","","","","","","","","",""};
	String ekleArkaSoyad[] = {"oğlu", "gil", "oğulları","","","","","","","","","",""};

        return ekleOnSoyad[(int) (Math.random() * ekleOnSoyad.length)]
                                .concat(soyad[(int) (Math.random() * soyad.length)]
                                    .concat(ekleArkaSoyad[(int) (Math.random() * ekleArkaSoyad.length)]));
    }
    public static String generateRandomName(boolean careGender, boolean gender) {
        /* Bu kod parçası daha önce Bilmuh 2. Sınıfta insanları sınıflara dağıtma ödevinde kullanılmıştır. */
        String bayAd[] = {"umut", "hüseyin","hüsnü","şevki","muharrem","haydar","ajdar","ferdi","fatih","mehmet","hüsnü","okan","metin","okşan"};

        String bayanAd[] = {"didem", "narin","özlem","fatma","ayşe","hülya","gülben","ahu","tuğba","banu","ayşe","canan",
        		"yeliz","yeşim","gülşen","gizem","saniye","nazlı"};

        /*
         * "" sayısının fazla olması, daha az ek seçilmesini sağlamaya
         * yöneliktir.
        */
        String ekleOnAd[] = {"bir", "","","","","","","",""};
        String ekleArkaAd[] = { "can", "gül", "nur", "su", "","","","","","","",""};

        int rndgend = (int) (Math.random() * 2);
        if (!careGender) {
            return ekleOnAd[(int) (Math.random() * ekleOnAd.length)].concat(
                        (rndgend == 1 ?
                            bayanAd[(int) (Math.random() * bayanAd.length)]
                                .concat(ekleArkaAd[(int) (Math.random() * ekleArkaAd.length)]) :
                            bayAd[(int) (Math.random() * bayAd.length)]
                                .concat(ekleArkaAd[(int) (Math.random() * ekleArkaAd.length)])));
        } else {
            return ekleOnAd[(int) (Math.random() * ekleOnAd.length)].concat(
                        (gender == CONSTANT.FEMALE ?
                            bayanAd[(int) (Math.random() * bayanAd.length)]
                                .concat(ekleArkaAd[(int) (Math.random() * ekleArkaAd.length)]) :
                            bayAd[(int) (Math.random() * bayAd.length)]
                                .concat(ekleArkaAd[(int) (Math.random() * ekleArkaAd.length)])));
        }
    }
    public static String generateRandomAdress() {
        String sehirler[] = {"ANKARA","ANTALYA","İZMİR","İSTANBUL","MANİSA"};
        String yollar[]   = {"Kemeraltı Caddesi","İnciraltı Caddesi","Atatürk Caddesi","Mehmet Akif Caddesi","Ankara Asfaltı",
            "Antalya Dünyanın En Güzel Şehridir Caddesi","Zeki Müren Sokak","Altıncı Cadde","Kıbrıs Şehitleri Caddesi",
            "Düden Caddesi","Konur Sokak","Kafanfil Sokak","Meşrutiyet Caddesi","Konyaaltı Caddesi","<<>>"};

        String yapilar[] = {"Yıkılmaz Apartmanı","Cingöz Apartmanı","Benzer Apt.","Bobiler Apt.","Bill Gates Apt.",
            "Öğrenci Yurtları","ESHOT Şube Müdürlüğü","Akman Sitesi","Fevzigil Sitesi","","","","","","","","","","","","","","","","","","","","","","",""};

        String mahalleler[] = {"Ulus","Işık","Üçgen","Düden","Kepezaltı","Kepezüstü","Haşim İşcan","Lara","Sanayi","Liman"};


        String mahalle = mahalleler[(int) (Math.random() * mahalleler.length)].concat(" Mahallesi");
        String yol = yollar[(int) (Math.random() * yollar.length)];
        if (yol.equals("<<>>")) {
            if ((int) (Math.random() * 2) < 1) {
                yol = (int) (Math.random() * 10000) + ". Sokak";
            } else {
                yol = (int) (Math.random() * 150) + ". Cadde";
            }
        }
        String apt = yapilar[(int) (Math.random() * yapilar.length)];
        if (!(apt.equals(""))) { apt.concat(" "); }

        return mahalle + " " + yol + " " + apt + "No:" + ((int) (Math.random() * 70) + 1) + " Daire: "
                + (int) ((Math.random() * 15) + 1) + " " + sehirler[(int) (Math.random() * sehirler.length)];
    }
    public static void addRandomCustomer(int number) {
        for (int i = 0; i < number; i++) {
            int gender = (int) (Math.random() * 2);

            Customer Musteri = new Customer(PlaceHolder.generateRandomName(true, (gender == 1 ? CONSTANT.FEMALE : CONSTANT.MALE)),
                    PlaceHolder.generateRandomLastName(), PlaceHolder.generateRandomAdress(),
                    (gender == 1 ? CONSTANT.FEMALE : CONSTANT.MALE), "standart insan tipi");

            int tipDegisimi= (int)(Math.random()*5);
            switch(tipDegisimi){
                case 4:
                	int newType = (int)(Math.random()*3);
                	switch (newType) {
                		case 0:
                			newType = CONSTANT.SILVERCUSTOMER;
                			break;
                		case 1:
                			newType = CONSTANT.GOLDCUSTOMER;
                			break;
                		case 2:
                			newType = CONSTANT.URANIUMCUSTOMER;
                			break;                 			
                	}
                	Musteri.changeType(newType);                    
            }

            System.out.println(Musteri);
        }

    }

    public static void addRandomRestaurant(int number) {
        String ad[] = {"kemeraltı", "ışıklar","dokuma","kepez","sahil","","hasanlar","kırık çatal"};

        String sonad[] = {"pidecisi", "kepabçısı", "light ürünleri a.ş.", "gıda", "kokoreççisi",
                        "köftecisi", "balık pişiricisi","suşicisi","çin lokantaları zinciri","simitçisi","la foodé","simit evi"};

        String ekleOnAd[] = {"öz ", "önder ","öz hakiki ","antalya ","izmir ","istanbul ","ankara","lezzette sınır tanımaz","","","","",""};

        for (int i=0; i < number; i++) {
            String yeniIsim = ekleOnAd[(int) (Math.random() * ekleOnAd.length)].concat(
                                ad[(int) (Math.random() * ad.length)]
                                    .concat(" ".concat(sonad[(int) (Math.random() * sonad.length)])));

           Restaurant r = new Restaurant(yeniIsim,PlaceHolder.generateRandomAdress(),
                  new Operator(generateRandomName(false,false),PlaceHolder.generateRandomLastName()));

           System.out.println(r);
        }
    }
}