package proje.util;
import proje.user.Customer;

@SuppressWarnings("unchecked")
public class CustomerOfARestaurant implements Comparable {
	public int number = 1;
	public Customer c;
	
	public CustomerOfARestaurant (Customer c) {
		this.c = c;
	}
	@Override
	public int compareTo(Object o) {
		CustomerOfARestaurant c = (CustomerOfARestaurant)o;
		return number - c.number;
	}
		
}
