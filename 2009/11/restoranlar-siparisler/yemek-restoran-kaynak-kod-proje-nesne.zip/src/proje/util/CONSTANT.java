package proje.util;

public class CONSTANT {
  public static final boolean MALE   = false;
  public static final boolean FEMALE = true;

  public static final int NEWORDER = 0;
  public static final int ORDERINPROGRESS = 1;
  public static final int DELIVEREDORDER = 2;

  /* GOLD VE URANYUM MÜŞTERİ OLMAK İÇİN GEREKLİ SİPARİŞ LİMİTLERİ */
  public static final int GOLDCUSTOMERLIMIT = 5;
  public static final int URANIUMCUSTOMERLIMIT = 7;

  /* GOLD VE URANYUM MÜŞTERİLERE UYGULANAN İNDİRİM YÜZDELERİ */
  public static final int GOLDCUSTOMERDISCOUNT = 5;
  public static final int URANIUMCUSTOMERDISCOUNT = 30;

  public static final int URANIUMCUSTOMER = 92;
  public static final int GOLDCUSTOMER = 79;
  public static final int SILVERCUSTOMER = 47;

  public static final int AUTO = -1;
}
