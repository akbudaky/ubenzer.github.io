package proje.util;
import java.util.Vector;

public final class SortableList<T> extends Vector<T> implements Reversible{

	private static final long serialVersionUID = 8057198066604379599L;

	public SortableList() { super(); }

    public SortableList<T> sortSortableOnes() { return sortSortableOnes(false); }

    /***
     * Listedeki sıralanabilir ögeleri (Comparable) ile sıralar. Bu arayüzü implement etmeyen
     * sıralanamaz nesneleri en sona ekler. Listenin <b>kendisisi de sıralanmış olduğu gibi</b>
     * aynı zamanda kendi referansını da döndürür.
     *
     * @param descending: Azalan sırada mı sıralansın?
     * @return Sıralı Liste
     */
    public SortableList<T> sortSortableOnes(boolean descending) {
        SortableList<T> sonuc = new SortableList<T>();
        for (T in: this) {
            if (in instanceof Comparable) {
                sonuc.add(in);
            }
        }
        QuickSort.sort(sonuc);
        if (descending) { sonuc.reverse(); }

        for (T in: this) {
            if (!(in instanceof Comparable)) {
                sonuc.add(in);
            }
        }

        this.clear();
        this.addAll(sonuc);
        return this;
    }

    public void reverse() {
        SortableList<T> temp = new SortableList<T>();
        for (int i = this.size()-1; i >= 0;i--) {
            temp.add(this.elementAt(i));
        }
        this.clear();
        this.addAll(temp);
    }
}
