package proje.util;

interface Reversible {
    /* Nesenin sıralamasını tersine çevirir. */
    public void reverse();
}
