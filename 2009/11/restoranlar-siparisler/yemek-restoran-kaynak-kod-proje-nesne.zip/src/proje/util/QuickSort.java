package proje.util;
import java.util.Vector;

public class QuickSort {
    @SuppressWarnings("unchecked")
	private static void qsort(Vector a, int lo0, int hi0) {
        int lo = lo0;
        int hi = hi0;

        if ( hi0 > lo0) {

                Comparable mid = ((Comparable)a.elementAt(( lo0 + hi0 ) / 2 ));

                while ( lo <= hi ) {

                        while (( lo < hi0 ) && (((Comparable)a.elementAt(lo)).compareTo(mid) < 0 ))
                                ++lo;

                        /* find an element that is smaller than or equal to
                        * the partition element starting from the right Index.
                        */
                        while (( hi > lo0 ) && (((Comparable)a.elementAt(hi)).compareTo(mid) > 0 ))
                                --hi;

                        // if the indexes have not crossed, swap
                        if ( lo <= hi ) {
                                swap(a, lo, hi);

                                ++lo;
                                --hi;
                        }
                }

                /* If the right index has not reached the left side of array
                * must now sort the left partition.
                */
                if ( lo0 < hi )
                        qsort( a, lo0, hi );

                /* If the left index has not reached the right side of array
                * must now sort the right partition.
                */
                if ( lo < hi0 )
                        qsort( a, lo, hi0 );
        }
}
    @SuppressWarnings("unchecked")
	private static void swap(Vector a, int i, int j) {
            Object temp = a.elementAt(i);
            a.setElementAt(a.elementAt(j), i);
            a.setElementAt(temp, j);
    }
    @SuppressWarnings("unchecked")
	public static void sort(Vector a) {
        /* Dikkat! Bu sınıf, gönderilen sınıf üzerinde sıralamayı yapar. Kopya oluşturmaz. */
        qsort(a, 0, a.size() - 1);
    }
}