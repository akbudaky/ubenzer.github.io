package proje.restaurant;
import java.util.Vector;
import proje.bootstrapper.Main;
import proje.user.Operator;
import proje.util.CustomerOfARestaurant;
import proje.util.SortableList;

@SuppressWarnings("unchecked")
public final class Restaurant  implements Comparable {
    private String restName;
    private String adress;

    private Vector<proje.restaurant.Menu> menuler = new Vector<Menu>();
    private Vector<Yemek> yemekler = new Vector<Yemek>();
    private SortableList<Order> orders = new SortableList<Order>(); // Gelmiş geçmiş tüm siparişler

    private Operator operator; /* Restoranın sorumlusu */

    public Restaurant (String restName, String adress, Operator operator) {
        this.adress = adress;
        this.restName = restName;
        this.operator = operator;
        operator.setSormluOldRestoran(this);
        Main.restaurants.add(this);
    }
    public SortableList<Order> getOrders() {
    	return this.orders;
    }
    public void setName(String n) {this.restName=n;}
    public String getOperatorName() { return this.operator.getFirstName() + " " + this.operator.getLastName(); }
    public String getOperatorFirstName() { return this.operator.getFirstName(); }
    public String getOperatorLastName() { return this.operator.getLastName(); }
    public SortableList<CustomerOfARestaurant> getAllCustomersOfRestaurant() {
    	SortableList<CustomerOfARestaurant> c = new SortableList<CustomerOfARestaurant>();
    	boolean done;
    	for (Order o: this.getOrders()) {
    		done = false;
    		for (CustomerOfARestaurant cc: c) {
    			if (o.getCustomer() == cc.c) {
    				cc.number++;
    				done = true;
    				break;
    			}    			
    		}
    		if(!done) {
    			c.addElement(new CustomerOfARestaurant(o.getCustomer()));
    		}
		}
    	c.sortSortableOnes(true);
    	return c;
    }
    public Operator getOperatorObject() { return this.operator; }
    public void setOperatorName(String first, String last) {
        this.operator.setFirstName(first);
        this.operator.setLastName(last);
    }
    public String getAdress() { return this.adress; }
    public void setAdress(String adress) { this.adress = adress;}
    public Vector<Yemek> getYemekler() {
        return this.yemekler;
    }
    public Vector<Menu> getMenuler() {
         return this.menuler;
    }
    public void addYemek(Yemek yeniYemek){//sisteme yemek girer
        this.yemekler.add(yeniYemek);
    }
    /***
     * Restorandan verilen yemeği siler. <b>Bu yemek aynı zamanda restoranın menülerinde varsa
     * oralardan da silinir.</b>
     *
     * Silinen yemek ve menüler kullanıcıların yaptıkları siparişlerde görünmeye devam eder.
     * Bu siparişlere verilen oylar ve yorumlar sistemde görünmeye devam edecektir.
     *
     * @param Silinecek Yemek
     */
    public void deleteYemek(Yemek sil) {
        for(Menu m : this.menuler) {
            m.removeYemek(sil);
        }
        this.yemekler.remove(sil);
    }
    /***
     * Restorandan verilen menüyü siler.
     *
     * Silinen  menüler kullanıcıların yaptıkları siparişlerde görünmeye devam eder.
     * Bu siparişlere verilen oylar ve yorumlar sistemde görünmeye devam edecektir.
     *
     * @param Silinecek Menü
     */
    public void deleteMenu(Menu sil) {
        this.menuler.remove(sil);
    }
    public void deleteRestaurant() {
        while (this.orders.size() != 0) {
            this.orders.firstElement().killOrder();
        }
        Main.users.remove(this.operator);
        Main.restaurants.remove(this);
        System.gc();
    }
    public void addMenu(Menu m){//sisteme menü girer
        this.menuler.add(m);
    }
    public void newOrder(Order o) {
        this.orders.add(o);
    }
    public void cancelOrder(Order o){
        if(o.cancelOrder()==true){
            orders.remove(o);
        }
    }
    public double getOrtPuan() {
        int i = 0;
        double top = 0;
        for(Order o: this.orders) {
            if (o.getGenelPuan() != -1) {
                i++;
                top += o.getGenelPuan();
            }
        }
        return ((double)((int)((top + 0.0) / (i + 0.0) * 100))) / 100.0;
    }
    public int compareTo (Object o) {
        if (!(o instanceof Restaurant)) {
            throw new ClassCastException();
        }
        return (int)((this.getOrtPuan() - ((Restaurant)o).getOrtPuan())*1000);
    }

    @Override
    public String toString() {
        return restName;
    }

    /* Hiçbir kontrol yapmadan verilen siparişi restorandan atar. */
    public void killOrder(Order o) {
        this.orders.remove(o);
    }



}