package proje.restaurant;

import java.text.DateFormat;
import java.util.Date;
import java.util.Vector;
import proje.user.Customer;
import proje.util.CONSTANT;

@SuppressWarnings("unchecked")
public final class Order implements Comparable, Fiyatlandirilabilir {
    private Customer musteri; // hangi müşteri siparis etmiş
    private Restaurant restoran; // Hangi restoranın siparişi
    private Date orderTime = null; //saat kaçta sipariş edilmiş
    private Date completeTime = null; /* Siparişin teslim tarihi */

    private Vector yemekVeMenuler = new Vector(); // Sepetin içeriğini oluşturan Yemek ve Menu sınıfları.

    private double tutar = -1;
    
    private int hizOy = -1;
    private int lezzetOy = -1;
    private int fiyatOy = -1;
    private String comment;

    private int orderStatus = CONSTANT.NEWORDER;

	public Order(Customer c, Restaurant r, Vector orderDetails) {
        this.musteri = c;
        this.restoran = r;
        this.restoran.newOrder(this);
        this.musteri.newOrder(this);        
        this.orderTime = new Date();
        for(Object o:orderDetails) {
            if(o instanceof Yemek) {
                if(r.getYemekler().contains((Yemek)o)) {
                    this.yemekVeMenuler.add(o);
                }
            }
            if(o instanceof Menu) {
                if(r.getMenuler().contains((Menu)o)) {
                    this.yemekVeMenuler.add(o);
                }
            }
        }
        this.tutar = this.getPrice();
    }
	public Vector getOrderDetails() {
		return yemekVeMenuler;
	}
    public String getComment() {
        return this.comment;
    }
    public Customer getCustomer() {
    	return this.musteri;
    }
    public Restaurant getRestaurant() {
    	return this.restoran;
    }
    /***
     * Siparişin yeni (onaylanmamış) olup olmadığını öğrenmeyi sağlar.
     *
     * @return Sipariş yeni mi?
     */
    public boolean isOrderNew() { return (this.getOrderStatus() == CONSTANT.NEWORDER ? true : false); }
    /***
     * Siparişin yolda olup olmadığını öğrenmeyi sağlar.
     *
     * @return Sipariş yolda mı?
     */
    public boolean isOrderInProgress() { return (this.getOrderStatus() == CONSTANT.ORDERINPROGRESS ? true : false); }
    /***
     * Siparişin yerine ulaşıp ulaşmadığını öğrenmeyi sağlar.
     *
     * @return Sipariş yerine ulaştı mı?
     */
    public boolean isOrderDelivered() { return (this.getOrderStatus() == CONSTANT.DELIVEREDORDER ? true : false); }
    /**
     * Siparişe yorum eklemeyi sağlar. Bunun için siparişin yerine ulaşmış olması gerekir.
     * Yorum nesneye kaydedilirse true, şartlar sağlanmıyorsa false döner.
     * 
     * @param Yorum
     * @return Sisteme işlenip işlenmediği
     */
    public boolean setComment(String c) {
        //if (this.isOrderDelivered()) {
            this.comment = c;
            return true;
       // }
       // return false;
    }
    public void setOrderTime(Date d) {
        this.orderTime = d;
    }
    public boolean setCompleteTime(Date d) {
        if (this.isOrderDelivered()) {
            this.completeTime = d;
            return true;
        }
        return false;
    }
    /**
     * Müşteri siparişinden vazgeçebilir. Eğer sipariş yola çıkmadıysa iptal imkanı vardır. Bu durumda
     * bu metot siparişi iptal eder ve true gönderir.
     *
     * Sipariş eğer yola çıktıysa artık iptal edilemez ve false gönderilir.
     *
     * @return Sipariş İptal Edildi mi
     */
    public boolean cancelOrder () {
        if (isCancelable()) {
            this.killOrder();
            return true;
        } else {
            return false;
        }        
    }
    private boolean isCancelable() {
        return (this.orderStatus != CONSTANT.NEWORDER ? false : true);
    }
    public int getOrderStatus() {
        return this.orderStatus;
    }
    /***
     * Siparişi yola çıktı olarak işaretler. Eğer sipariş zaten yoldaysa ya da ulaşmışsa bu işlem
     * gerçekleştirilemez ve false gönderilir.
     *
     * Bu metod sadece yeni bir siparişi yolda olarak işaretlemeye yarar.
     *
     * @return siparişDurumuDeğiştiMi
     */
    public boolean setOrderInProgress() {
        if (this.orderStatus == CONSTANT.NEWORDER) {
            this.orderStatus = CONSTANT.ORDERINPROGRESS;
            return true;
        }
        return false;
    }
    /***
     * Siparişi yerine ulaştı olarak işaretler. Eğer sipariş zaten yerine ulaşmışsa bu işlem
     * gerçekleştirilemez ve false gönderilir.
     *
     * Bu metod yeni bir siparişi ya da yolda olan bir siparişi yerine ulaştı olarak işaretler.
     *
     * @return siparişDurumuDeğiştiMi
     */
    public boolean setOrderDelivered() {
         if (this.orderStatus != CONSTANT.DELIVEREDORDER) {
             if (this.musteri.getIsTypeCheckingAutomated() == true ) {
                /* Müşterinin tipini upgrade edecek miyiz? */
            	this.musteri.changeType(CONSTANT.SILVERCUSTOMER, true);
                if(this.musteri.getTotalOrderCount() >= CONSTANT.GOLDCUSTOMERLIMIT){
                    this.musteri.changeType(CONSTANT.GOLDCUSTOMER, true);
                }
                if (this.musteri.getTotalOrderCount() >= CONSTANT.URANIUMCUSTOMERLIMIT){
                    this.musteri.changeType(CONSTANT.URANIUMCUSTOMER, true);
                }
            }
            this.completeTime = new Date();
            this.orderStatus = CONSTANT.DELIVEREDORDER;
            return true;
         } else { return false; }
    }
    public Date getOrderTime() {
        return this.orderTime;
    }
    /**
     * Siparişin yerine ulaşma tarihini döndürür. Eğer sipariş yerine ulaşmamışsa henüz
     * geriye null döner.
     * @return null || Date
     */
    public Date getCompleteTime() {
        return this.completeTime;
    }
    public int compareTo (Object o) {
        if (!(o instanceof Order)) {
            throw new ClassCastException();
        }
        return this.orderTime.compareTo(((Order)o).getOrderTime());
    }
    /**
     * Siparişin hızına oy verilir. Oy verebilmek için siparişin yerine
     * ulaşmış olması gerekmektedir. Aksi halde metod false döndürür.
     *
     * @param 0 ile 2 arası oy. (- değerler geçersiz oy sayılır, 2'den büyük oylar 2 sayılır.)
     * @return oy verilirse true, oy kabul edilmezse false
     */
    public boolean voteForHiz (int vote) {
        if (this.isOrderDelivered()) {
            if (vote < -1) { vote = -1; }
            if (vote > 2) { vote = 2; }
            this.hizOy = (vote > -1 ? ++vote : vote);
            return true;
        }
        return false;
    }
    /**
     * Siparişin lezzetine oy verilir. Oy verebilmek için siparişin yerine
     * ulaşmış olması gerekmektedir. Aksi halde metod false döndürür.
     *
     * @param 0 ile 2 arası oy. (- değerler geçersiz oy sayılır, 2'den büyük oylar 2 sayılır.)
     * @return oy verilirse true, oy kabul edilmezse false
     */
    public boolean voteForLezzet (int vote) {
        if (this.isOrderDelivered()) {
            if (vote < -1) { vote = -1; }
            if (vote > 2) { vote = 2; }
            this.lezzetOy = (vote > -1 ? ++vote : vote);
            return true;
        }
        return false;
    }
    /**
     * Siparişin fiyatına oy verilir. Oy verebilmek için siparişin yerine
     * ulaşmış olması gerekmektedir. Aksi halde metod false döndürür.
     *
     * @param 0 ile 2 arası oy. (- değerler geçersiz oy sayılır, 2'den büyük oylar 2 sayılır.)
     * @return oy verilirse true, oy kabul edilmezse false
     */
    public boolean voteForFiyat (int vote) {
        if (this.isOrderDelivered()) {
            if (vote < -1) { vote = -1; }
            if (vote > 2) { vote = 2; }
            this.fiyatOy = (vote > -1 ? ++vote : vote);
            return true;
        }
        return false;
    }

    public int getHizPuan () { return this.hizOy; }
    public int getLezzetPuan () { return this.lezzetOy; }
    public int getFiyatPuan () { return this.fiyatOy; }

    public double getGenelPuan () {
        if (!this.isUserVotedForThisOrder()) return -1;
        int toplam = 0;
        int bolum = 0;
        if (this.getHizPuan() != -1) { toplam += this.getHizPuan(); bolum++; }
        if (this.getLezzetPuan() != -1) { toplam += this.getLezzetPuan(); bolum++; }
        if (this.getFiyatPuan() != -1) { toplam += this.getFiyatPuan(); bolum++; }
        return (toplam + 0.0) / (bolum + 0.0);
    }
    /***
     * Kullanıcı bu sipariş için oy kullandı mı?
     *
     * @return
     */
    public boolean isUserVotedForThisOrder() {
        if (this.fiyatOy != -1 || this.lezzetOy != -1 || this.fiyatOy != -1) { return true; }
        return false;
    }
    @Override
    public String toString() {
        return "Sipariş " + this.getPrice() + " TL (" + DateFormat.getInstance().format(this.getOrderTime()) + ")";
    }
    /* Bağlantı silinir */
    public void killOrder() {
        this.restoran.killOrder(this);
        this.musteri.killOrder(this);
    }
    public double getPrice() {
        if (this.tutar != -1) return this.tutar;
        double price = 0;
        for(Object o: this.yemekVeMenuler) {
            if(o instanceof Fiyatlandirilabilir) {
                price += ((Fiyatlandirilabilir)o).getPrice();
            }
        }
        this.tutar = Order.applyDiscounts(this.musteri, price);
        long l = (int)Math.round(this.tutar * 100); // truncates
        this.tutar = l / 100.0;
        return this.tutar;
    }
    private static double applyDiscounts(Customer musteri,double tutar) {
        if (musteri.getType() == CONSTANT.GOLDCUSTOMER) {
            tutar = tutar - (tutar * CONSTANT.GOLDCUSTOMERDISCOUNT / 100);
        } else if (musteri.getType() == CONSTANT.URANIUMCUSTOMER) {
            tutar = tutar - (tutar * CONSTANT.URANIUMCUSTOMERDISCOUNT / 100);
        }
        return tutar;
    }
    /***
     * Nesne yaratmadan belirli bir müşterinin belirli bir ürünü alması durumunda ne kadar
     * ödeyeceğini hesaplayan bir metottur.
     *
     * Müşteriye özel indirim (varsa) hesaba katılır.
     *
     * @param Müşteri
     * @param Yemek ve Menülerden oluşan vektör
     * @return Fiyat
     */
    public static double askPrice(Customer c, Vector whatToAsk) {
        double price = 0;
        for(Object o: whatToAsk) {
            if(o instanceof Fiyatlandirilabilir) {
                price += ((Fiyatlandirilabilir)o).getPrice();
            }
        }
        return ((double)((int)(Order.applyDiscounts(c, price) * 100))) / 100.0;
    }
}
