package proje.restaurant;

public final class Yemek implements Fiyatlandirilabilir {
    private double fiyat;
    private String ad;

    public Yemek(String ad, double fiyat) {
        this.ad = ad;
        this.fiyat = fiyat;
    }
    public void setPrice(double f) { this.fiyat = f; }
    public double getPrice() { return this.fiyat; }
    public void setAd(String a) { this.ad = a; }
    public String getAd() { return this.ad; }

    @Override
    public String toString() {
        return this.ad;
    }
}
