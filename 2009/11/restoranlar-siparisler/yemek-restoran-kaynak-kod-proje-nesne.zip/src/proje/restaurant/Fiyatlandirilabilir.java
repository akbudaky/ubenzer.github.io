package proje.restaurant;

public interface Fiyatlandirilabilir {
    public double getPrice();
}
