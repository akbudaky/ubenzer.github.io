package proje.restaurant;
import java.util.Vector;

public class Menu implements Fiyatlandirilabilir {
    private Vector<Yemek> yemekleri; /* Menüdeki yemekler */
    private double fiyati; /* Her yemeğin kendine ait fiyatı mavcuttur ancak menülerde özel indirim
     yapılması gibi bir durum söz konusu olabileceğinden eklenmiştir. */
    private String name;

    public Menu(String name, double fiyati, Vector<Yemek> yemekListesi) {
        this.name = name;
        this.fiyati = fiyati;
        this.yemekleri = yemekListesi;
    }
    public Vector<Yemek> getMenuYemekleri() {
    	return this.yemekleri;
    }
    public void setPrice(double fiyat) { this.fiyati=fiyat; }
    public double getPrice() { return this.fiyati; }
    public void yemekEkle(Yemek yeniYemek){//menüye yeni yemek eklenmesini sağlar
        yemekleri.add(yeniYemek);
    }
    public void addYemek(Yemek y) {
        this.yemekleri.add(y);
    }
    public void removeYemek(Yemek y) {
        this.yemekleri.remove(y);
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getName() { return name; }

    @Override
    public String toString() {
        return this.name;
    }

}
