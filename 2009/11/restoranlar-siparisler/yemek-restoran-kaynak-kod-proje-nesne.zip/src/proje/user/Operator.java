package proje.user;
import proje.restaurant.Restaurant;

public final class Operator extends User {
    private Restaurant sorumluOldRest; /* Operatörün sorumlu olduğu restoran */

    public Operator(String firstName, String lastName) {
        super(firstName,lastName);
        
    }

    public void setSormluOldRestoran(Restaurant r) { this.sorumluOldRest = r;    }
    public Restaurant getSormluOldRestoran()       { return this.sorumluOldRest; }
}
