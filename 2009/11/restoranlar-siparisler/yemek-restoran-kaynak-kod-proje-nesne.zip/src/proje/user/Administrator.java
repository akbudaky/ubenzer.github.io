package proje.user;


public final class Administrator extends User {

    public Administrator(String firstName, String lastName) {
        super(firstName,lastName);
    }
    public void changeCustomerType(Customer c, int type){//c müşterisinin tipini type ile değiştirir.
        c.changeType(type);
    }
}
