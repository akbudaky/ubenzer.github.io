package proje.user;
import java.util.Date;
import java.util.Vector;
import proje.bootstrapper.Main;
import proje.restaurant.Order;
import proje.util.CONSTANT;
import proje.util.SortableList;

@SuppressWarnings("unchecked")
public class Customer extends User implements Comparable {
    private String adress;
    private boolean gender;
    private String lookLike; /* Müşterinin tipi */

    private SortableList<Order> orders = new SortableList<Order>(); /* Şimdiye kadarki tüm siparişleri, */

    private int type = CONSTANT.SILVERCUSTOMER;
    private boolean isTypeCheckingAutomated = true; 

    // Constructors
    public Customer(String firstName, String lastName, String adress, boolean gender, String lookLike) {
        this(firstName, lastName, adress,gender,lookLike,CONSTANT.AUTO);
    }
    /**
     * Yeni bir müşteri yaratılır. Müşteri tipi olarak CONST.AUTO dışında bir değer girilirse,
     * sistem bunu müşteri tipi değişiminin manuel yapılacağı olarak algılar ve sipariş sayısı kontrolü yapmaz.
     *
     * Eğer tip değişiminin sistem tarafından otomatik yapılması isteniyorsa CONST.AUTO değeri kullanılmalıdır!
     *
     * @param firstName
     * @param lastName
     * @param adress
     * @param gender
     * @param lookLike
     * @param musteriTipi
     */
    public Customer(String firstName, String lastName, String adress, boolean gender, String lookLike, int musteriTipi) {
        super(firstName, lastName);
        this.adress = adress;
        this.gender = gender;
        this.lookLike = lookLike;
        this.type = (musteriTipi > 0 ? musteriTipi : CONSTANT.SILVERCUSTOMER);
        if (musteriTipi > 0) { this.isTypeCheckingAutomated = false; }
    }
    
    // Getter ve Setter mehtodlar
    public String getAdress(){
        return this.adress;
    }
    public boolean getGender(){
        return this.gender;
    }
    public String getLooklike(){
        return this.lookLike;
    }
    public void setAdress(String adress){
        this.adress=adress;
    }
    public void setGender(boolean gender){
        this.gender=gender;
    }
    public void setLooklike(String lookLike){
        this.lookLike=lookLike;
    }
    public int getTotalOrderCount() { return this.orders.size(); }
    public int getType() { return type; }
    /**
     * Kullanıcının verdiği son siparişin tarihini döndürür. Kullanıcı hiç sipariş vermediyse null
     * döner.
     * @return Date
     */
    public Date getLastOrderTime () {
        this.orders.sortSortableOnes(true);
        return (this.orders.size() > 0 ? this.orders.elementAt(0).getOrderTime() : null);
    }
     /***
      * Kullanıcının bıraktığı son yorumları gösterir. Eğer kullanıcı istenen sayıdan daha az sayıda yorum bırakmışsa
      * vektörün eleman sayısı istenenden az olabilir.
      * @param Kaç tane yorum isteniyor
      * @return Vektör içinde String yorumlar
      */
    public Vector<String> getLastCommentsUserWrote(int howMany) {
        if (howMany < 0) { howMany = 1; }
        Vector<String> ret = new Vector<String>();
 System.out.println("ABOOO:");
        int i = 0;
        this.orders.sortSortableOnes(true);
        System.out.println(this.orders.size());
        while (i < howMany) {
            try {
                 System.out.println(this.orders.elementAt(i).getComment());
                /* Sistemde istenen sayıda yoksa çökmesin */
                if (this.orders.elementAt(i).getComment() != null) {
                    System.out.println("OHAA: " + this.orders.elementAt(i).getComment());
                    ret.add(this.orders.elementAt(i).getComment());
                }                
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.print(e.getMessage());
                break;
            }
            i++;
        }
        return ret;
    }
    public int getTotalVoteCount() {
        int i = 0;
        for(Order o: this.orders) {
            if (o.isUserVotedForThisOrder()) i++;
        }
        return i;
    }
    /**
     * Nesneye bağlı tüm siparişleri bir SortableList içerisinde tarihe göre
     * azalan sırada gönderir.
     * @return Vektör içerisinde Order
     */
    public SortableList<Order> getAllOrdersByCurrentUserSortedByDateDESC() {
        return this.orders.sortSortableOnes(true);
    }

    public void changeType(int newType) { /* Admin değiştiriyorsa */
        if (newType == CONSTANT.AUTO) {
            /* Müşterinin tipini upgrade edecek miyiz? */
            if(this.getTotalOrderCount() < CONSTANT.GOLDCUSTOMERLIMIT) {
                newType = CONSTANT.SILVERCUSTOMER;
            } else if (this.getTotalOrderCount() < CONSTANT.URANIUMCUSTOMERLIMIT){
                newType = CONSTANT.GOLDCUSTOMER;
            } else {
                newType = CONSTANT.URANIUMCUSTOMER;
            }
        }
        changeType(newType, false);
    }
    public boolean changeType(int newType, boolean auto) { /* Sistem değiştiriyorsa */
       this.isTypeCheckingAutomated = auto;
       if (!(newType==CONSTANT.SILVERCUSTOMER || newType == CONSTANT.GOLDCUSTOMER || newType == CONSTANT.URANIUMCUSTOMER)) {
           return false;
       }
       this.type = newType;
       return true;
    }
    public boolean getIsTypeCheckingAutomated () {
        return this.isTypeCheckingAutomated;
    }
    public void newOrder(Order o) {
        this.orders.add(o);
    }
    public void cancelOrder(Order o){
        if(o.cancelOrder()==true){
            o.killOrder();
            orders.remove(o);
        }
    }

    public int compareTo (Object o) {
        if (!(o instanceof Customer)) {
            throw new ClassCastException();
        }        
        return this.getTotalOrderCount() - ((Customer)o).getTotalOrderCount();
    }
    /* Kullanıcıyı öbür dünyaya gönderir. Kullanıcının yarattığı tüm bilgiler de sistemden cıncıklanır. */
    public void deleteUser() {
        while (this.orders.size() != 0) {
            this.orders.firstElement().killOrder();
        }
        Main.users.remove(this);
        System.gc();
    }
    /* Hiçbir kontrol yapmadan siparişi kullanıcıdan siler. */
    public void killOrder(Order o) {
        this.orders.remove(o);
    }
}