package proje.ui;

import java.awt.Frame;
import java.awt.Label;
import java.awt.Rectangle;
import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Warning extends Frame {

	private static final long serialVersionUID = 1L;

	private Label label = null;

	private Label label1 = null;

	private Label label2 = null;

	private Label label3 = null;

	private Button okbutton = null;

	private Button baybaybutton = null;

	/**
	 * This is the default constructor
	 */
	public Warning() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		label3 = new Label();
		label3.setBounds(new Rectangle(31, 210, 428, 30));
		label3.setText("Yok, vazgeçtim, anladım ki hata bulamayacağım diyorsan Bay Bay'a bas :))");
		label2 = new Label();
		label2.setBounds(new Rectangle(29, 164, 325, 32));
		label2.setText("Rol seçimine dönmek için '>>'a bas.");
		label1 = new Label();
		label1.setBounds(new Rectangle(30, 114, 324, 35));
		label1.setText("Gerçekten böyle bir hatayı yakalayamayacak mıydık yani?");
		label = new Label();
		label.setBounds(new Rectangle(29, 60, 324, 36));
		label.setText("Ne yani? :))");
		this.setLayout(null);
		this.setSize(527, 287);
		this.setTitle("Uyarı!   Warning!    die Warnung!");

		this.add(label, null);
		this.add(label1, null);
		this.add(label2, null);
		this.add(label3, null);
		this.add(getOkbutton(), null);
		this.add(getBaybaybutton(), null);

		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
				// windowClosing()
			}
		});
	}

	/**
	 * This method initializes okbutton
	 * 
	 * @return java.awt.Button
	 */
	private Button getOkbutton() {
		if (okbutton == null) {
			okbutton = new Button();
			okbutton.setBounds(new Rectangle(389, 60, 105, 47));
			okbutton.setLabel(">>");

			okbutton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					shut_up();
					Entry en = new Entry();
					en.setVisible(true);
				}
			});
		}
		return okbutton;
	}

	/**
	 * This method initializes baybaybutton
	 * 
	 * @return java.awt.Button
	 */
	private Button getBaybaybutton() {
		if (baybaybutton == null) {
			baybaybutton = new Button();
			baybaybutton.setBounds(new Rectangle(388, 122, 106, 48));
			baybaybutton.setLabel("Bay Bay!");

			baybaybutton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					shut_up();

				}
			});
		}
		return baybaybutton;
	}

	public void shut_up() {
		this.setVisible(false);
	}

} // @jve:decl-index=0:visual-constraint="7,4"
