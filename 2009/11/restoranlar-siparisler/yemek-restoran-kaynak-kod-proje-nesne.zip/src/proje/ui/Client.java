package proje.ui;

/* henüz gelmeyenlerle yeni siparişler aynı değil sanırım görüntülenmeli mi */
import java.awt.Frame;
import javax.swing.JTabbedPane;
import java.awt.Rectangle;
import javax.swing.JPanel;

import java.awt.CheckboxGroup;
import java.awt.Label;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.TextArea;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JLabel;

import proje.bootstrapper.Main;
import proje.restaurant.Fiyatlandirilabilir;
import proje.restaurant.Order;
import proje.restaurant.Restaurant;
import proje.restaurant.Yemek;
import proje.user.Customer;
import proje.util.CONSTANT;

import java.text.DateFormat;
import java.util.Vector;
import java.awt.Font;
import java.awt.Choice;
import java.awt.GridBagLayout;
import java.awt.List;
import java.awt.GridBagConstraints;

public class Client extends Frame {

	private static final long serialVersionUID = 1L;

	private JTabbedPane jTabbedPane = null;

	private JPanel orderPanel = null;

	CheckboxGroup cbg = new CheckboxGroup();

	CheckboxGroup cbg2 = new CheckboxGroup();

	CheckboxGroup cbg3 = new CheckboxGroup();

	private JPanel restaurantPanel = null;

	private Label label1 = null;

	private Label label2 = null;

	private Label label3 = null;

	private JComboBox restaurantBox = null;

	DefaultListModel listModel = new DefaultListModel();

	DefaultListModel listModel2 = new DefaultListModel();

	DefaultListModel listofMenu = new DefaultListModel();

	DefaultListModel listOfFood = new DefaultListModel();

	DefaultListModel choose = new DefaultListModel();

	DefaultListModel icerik = new DefaultListModel();

	private Label label9 = null;

	private Label lblNormalFiyat = null;

	private Label label14 = null;

	private Label label18 = null;

	private Button button = null;

	private JList menuList = null;

	private JScrollPane menuPane = null;

	private JList foodList = null;

	private JScrollPane foodPane = null;

	private Button change = null;

	private Label label = null;

	private TextArea textArea = null;

	private Button changed = null;

	private JList otherOrderList = null;

	private JScrollPane otherOrderPane = null;

	private Customer c = new Customer("", "", "", true, "");  //  @jve:decl-index=0:

	private JLabel oy = null;

	private JLabel oyy = null;

	private Restaurant r;

	private Label lblSeciliFiyat = null;

	private JList chooseList = null;

	private JScrollPane choosePane = null;

	// @jve:decl-index=0:

	private proje.restaurant.Order o;

	private Button cikar = null;

	private proje.restaurant.Menu tiklanmisMenu;
	private proje.restaurant.Yemek tiklanmisYemek;
	private Object tiklanmisSepettekiYemek;

	Object selectionValuem;

	private JList iceriklist = null;

	private JScrollPane icerikPane = null;

	private JComboBox siparisFiltre = null;

	private Button btnIptal = null;

	private Label lblFiyat = null;

	private Label lblRestoran = null;

	private TextArea txtDetails = null;

	private Choice oyLezzet = null;

	private Choice oyFiyat = null;

	private Choice oyHiz = null;

	private Label sipDurum = null;

	private Label label6 = null;

	private Label label10 = null;

	private Label orderDate = null;

	private Label completeDate = null;

	private Label label5 = null;

	private Label label12 = null;

	private Button btnMenuEkle = null;

	private Button btnYemekEkle = null;

	private Label label7 = null;

	private Label label121 = null;

	private Label lblIndirimliFiyat = null;

	private Label label1211 = null;

	private Button btnSiparisVer = null;

	private JPanel tumRestoranlar = null;

	private List allrestList = null;

	/**
	 * This is the default constructor
	 */
	public Client(Customer c) {
		super();
		this.c = c;
		initialize();

	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setLayout(null);
		this.setSize(800, 600);
		this.setResizable(false);
		this.setTitle("Müşteri: " + c.getFirstName() + " " + c.getLastName());

		this.add(getJTabbedPane(), null);
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			}
		});
		fillOrderBox();
	}
	private void fillOrderBox() {
		listModel2.clear();
		String secili = (String)siparisFiltre.getSelectedItem();
		int flag = -1;
		
		if (secili.equals("Onay Bekleyenler")) flag = CONSTANT.NEWORDER;
		if (secili.equals("Yolda Olanlar")) flag = CONSTANT.ORDERINPROGRESS;
		if (secili.equals("Yerine Ulaşmış Siparişler")) flag = CONSTANT.DELIVEREDORDER;
		
		for (proje.restaurant.Order or : c.getAllOrdersByCurrentUserSortedByDateDESC()) {
			if (flag == -1 || or.getOrderStatus() == flag) {
				listModel2.addElement(or);
			}
		}
		lblRestoran.setText("");
		orderDate.setText("");
		completeDate.setText("");
		lblFiyat.setText("");
		txtDetails.setText("");
		textArea.setText("");
		textArea.setEnabled(false);
		oyLezzet.select("(yok)");
		oyLezzet.setEnabled(false);
		oyHiz.select("(yok)");
		oyHiz.setEnabled(false);
		oyFiyat.select("(yok)");
		oyFiyat.setEnabled(false);
		btnIptal.setEnabled(false);
		button.setEnabled(false);
		sipDurum.setText("");
	}

	public void shut_up() {
		this.setVisible(false);
	}

	/**
	 * This method initializes jTabbedPane
	 * 
	 * @return javax.swing.JTabbedPane
	 */
	private JTabbedPane getJTabbedPane() {
		if (jTabbedPane == null) {
			jTabbedPane = new JTabbedPane();
			jTabbedPane.setBounds(new Rectangle(15, 33, 768, 551));
			jTabbedPane.addTab("Yeni Sipariş Ver", null, getOrderPanel(), null);
			jTabbedPane.addTab("Siparişleriniz", null, getRestaurantPanel(), null);
			jTabbedPane.addTab("Tüm Restoranlar", null, getTumRestoranlar(), null);
		}
		return jTabbedPane;
	}

	/**
	 * This method initializes orderPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getOrderPanel() {
		if (orderPanel == null) {
			label1211 = new Label();
			label1211.setBounds(new Rectangle(346, 477, 185, 37));
			label1211.setAlignment(Label.LEFT);
			label1211.setText("4. Siparişinizi verin!");
			label1211.setFont(new Font("Dialog", Font.BOLD, 18));
			lblIndirimliFiyat = new Label();
			lblIndirimliFiyat.setBounds(new Rectangle(516, 445, 232, 26));
			lblIndirimliFiyat.setText("");
			label121 = new Label();
			label121.setBounds(new Rectangle(347, 231, 290, 31));
			label121.setAlignment(Label.LEFT);
			label121.setText("3. Sepetinizi Doldurun");
			label121.setFont(new Font("Dialog", Font.BOLD, 18));
			label7 = new Label();
			label7.setBounds(new Rectangle(346, 113, 113, 24));
			label7.setText("Menüdeki Yiyecekler:");
			label12 = new Label();
			label12.setBounds(new Rectangle(15, 77, 213, 30));
			label12.setAlignment(Label.LEFT);
			label12.setText("2. İstediklerinizi Seçin");
			label12.setFont(new Font("Dialog", Font.BOLD, 18));
			label5 = new Label();
			label5.setBounds(new Rectangle(187, 18, 213, 19));
			label5.setName("");
			label5.setText("(Lokantalar puanlarına göre sıralıdır.)");
			lblSeciliFiyat = new Label();
			lblSeciliFiyat.setVisible(true);
			lblSeciliFiyat.setBounds(new Rectangle(414, 21, 335, 49));
			lblSeciliFiyat.setFont(new Font("Dialog", Font.BOLD, 36));
			lblSeciliFiyat.setName("lblSeciliFiyat");
			lblSeciliFiyat.setText("");
			oyy = new JLabel();
			oyy.setBounds(new Rectangle(357, 44, 42, 25));
			oy = new JLabel();
			oy.setBounds(new Rectangle(328, 43, 24, 26));
			oy.setText("Oy:");
			lblNormalFiyat = new Label();
			lblNormalFiyat.setBounds(new Rectangle(350, 445, 160, 24));

			label3 = new Label();
			label3.setBounds(new Rectangle(14, 309, 158, 22));
			label3.setAlignment(Label.LEFT);

			label3.setText("Restorandaki Yemekler:");
			label3.setVisible(true);
			label2 = new Label();
			label2.setBounds(new Rectangle(14, 112, 138, 23));
			label2.setAlignment(Label.LEFT);

			label2.setText("Restorandaki Menüler:");
			label2.setVisible(true);
			label1 = new Label();
			label1.setBounds(new Rectangle(16, 12, 170, 26));
			label1.setAlignment(Label.LEFT);
			label1.setFont(new Font("Dialog", Font.BOLD, 18));
			label1.setText("1. Lokantayı Seçin");
			orderPanel = new JPanel();
			orderPanel.setLayout(null);
			orderPanel.add(label1, null);
			orderPanel.add(label2, null);
			orderPanel.add(label3, null);
			orderPanel.add(getRestaurantBox(), null);
			orderPanel.add(lblNormalFiyat, null);
			orderPanel.add(getMenuPane(), null);
			orderPanel.add(getFoodPane(), null);
			orderPanel.add(getChange(), null);
			orderPanel.add(oy, null);
			orderPanel.add(oyy, null);
			orderPanel.add(lblSeciliFiyat, null);
			orderPanel.add(getChoosePane(), null);
			orderPanel.add(getCikar(), null);
			orderPanel.add(getIcerikPane(), null);
			orderPanel.add(label5, null);
			orderPanel.add(label12, null);
			orderPanel.add(getBtnMenuEkle(), null);
			orderPanel.add(getBtnYemekEkle(), null);
			orderPanel.add(label7, null);
			orderPanel.add(label121, null);
			orderPanel.add(lblIndirimliFiyat, null);
			orderPanel.add(label1211, null);
			orderPanel.add(getBtnSiparisVer(), null);
		}
		return orderPanel;
	}

	/**
	 * This method initializes restaurantPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getRestaurantPanel() {
		if (restaurantPanel == null) {
			completeDate = new Label();
			completeDate.setBounds(new Rectangle(566, 393, 165, 20));
			completeDate.setText("");
			orderDate = new Label();
			orderDate.setBounds(new Rectangle(565, 349, 167, 18));
			orderDate.setText("");
			label10 = new Label();
			label10.setBounds(new Rectangle(557, 370, 175, 22));
			label10.setText("Sip.teslim zamanı:");
			label6 = new Label();
			label6.setBounds(new Rectangle(558, 329, 173, 19));
			label6.setText("Sip.verilme zamanı:");
			sipDurum = new Label();
			sipDurum.setBounds(new Rectangle(255, 416, 474, 27));
			sipDurum.setFont(new Font("Dialog", Font.ITALIC, 24));
			sipDurum.setText("");
			lblRestoran = new Label();
			lblRestoran.setBounds(new Rectangle(253, 25, 383, 29));
			lblRestoran.setFont(new Font("Dialog", Font.BOLD, 24));
			lblRestoran.setText("");
			lblFiyat = new Label();
			lblFiyat.setBounds(new Rectangle(642, 25, 108, 28));
			lblFiyat.setFont(new Font("Dialog", Font.BOLD, 24));
			lblFiyat.setText("Tutar");
			label = new Label();
			label.setBounds(new Rectangle(255, 155, 157, 22));
			label.setText("Sipariş hakkında yorumum:");
			label18 = new Label();
			label18.setBounds(new Rectangle(254, 360, 64, 21));
			label18.setText("Fiyat:");
			label14 = new Label();
			label14.setBounds(new Rectangle(253, 388, 63, 20));
			label14.setText("Hız:");
			label9 = new Label();
			label9.setBounds(new Rectangle(254, 330, 64, 23));
			label9.setText("Lezzet:");
			restaurantPanel = new JPanel();
			restaurantPanel.setLayout(null);
			restaurantPanel.add(label9, null);
			restaurantPanel.add(label14, null);
			restaurantPanel.add(label18, null);
			restaurantPanel.add(getButton(), null);
			restaurantPanel.add(label, null);
			restaurantPanel.add(getTextArea(), null);
			restaurantPanel.add(getChanged(), null);
			restaurantPanel.add(getOtherOrderPane(), null);
			restaurantPanel.add(getSiparisFiltre(), null);
			restaurantPanel.add(getBtnIptal(), null);
			restaurantPanel.add(lblFiyat, null);
			restaurantPanel.add(lblRestoran, null);
			restaurantPanel.add(getTxtDetails(), null);
			restaurantPanel.add(getOyLezzet(), null);
			restaurantPanel.add(getOyFiyat(), null);
			restaurantPanel.add(getOyHiz(), null);
			restaurantPanel.add(sipDurum, null);
			restaurantPanel.add(label6, null);
			restaurantPanel.add(label10, null);
			restaurantPanel.add(orderDate, null);
			restaurantPanel.add(completeDate, null);
		}
		return restaurantPanel;
	}

	

	/**
	 * This method initializes restaurantBox
	 * 
	 * @return javax.swing.JComboBox
	 */
	private JComboBox getRestaurantBox() {
		if (restaurantBox == null) {
			restaurantBox = new JComboBox();
			restaurantBox.setBounds(new Rectangle(16, 43, 306, 26));

			for (Restaurant r : Main.restaurants.sortSortableOnes(true)) {
				restaurantBox.addItem(r);
			}
			resetNewOrderWindow();
			restaurantBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					resetNewOrderWindow();
				}

			});
		}
		return restaurantBox;
	}

	/**
	 * This method initializes button
	 * 
	 * @return java.awt.Button
	 */
	private Button getButton() {
		if (button == null) {
			button = new Button();
			button.setBounds(new Rectangle(252, 486, 205, 28));
			button.setLabel("Oyumu & Yorumlarımı Kaydet");

			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					o.setComment(textArea.getText());
					
					if (oyHiz.getSelectedItem().equals("(yok)")) {
						o.voteForHiz(-1);
					} else if (oyHiz.getSelectedItem().equals("İyi")) {
						o.voteForHiz(2);
					} else if  (oyHiz.getSelectedItem().equals("Orta")) {
						o.voteForHiz(1);						
					} else {
						o.voteForHiz(0);
					}					
					if (oyFiyat.getSelectedItem().equals("(yok)")) {
						o.voteForFiyat(-1);
					} else if (oyFiyat.getSelectedItem().equals("İyi")) {
						o.voteForFiyat(2);
					} else if  (oyFiyat.getSelectedItem().equals("Orta")) {
						o.voteForFiyat(1);						
					} else {
						o.voteForFiyat(0);
					}					
					if (oyLezzet.getSelectedItem().equals("(yok)")) {
						o.voteForLezzet(-1);
					} else if (oyLezzet.getSelectedItem().equals("İyi")) {
						o.voteForLezzet(2);
					} else if  (oyLezzet.getSelectedItem().equals("Orta")) {
						o.voteForLezzet(1);						
					} else {
						o.voteForLezzet(0);
					}					
					fillOrderBox();
				}
			});
		}
		return button;
	}

	/**
	 * This method initializes menuList
	 * 
	 * @return javax.swing.JList
	 */
	private JList getMenuList() {
		if (menuList == null) {
			menuList = new JList(listofMenu);

			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {

					boolean adjust2 = listSelectionEvent.getValueIsAdjusting();

					if (!adjust2) { // Eğer seçim varsa
						JList list = (JList) listSelectionEvent.getSource();
						Object selectionValue = list.getSelectedValue();
						tiklanmisMenu = (proje.restaurant.Menu) selectionValue;
						if (tiklanmisMenu == null) return;

						lblSeciliFiyat.setText(tiklanmisMenu.getPrice() + " TL");
						
						/* Menüdeki yiyecekler */
						icerik.clear();
						for(Yemek y: tiklanmisMenu.getMenuYemekleri()) {
							icerik.addElement(y);
						}						

					}
				}
			};
			menuList.addListSelectionListener(listSelectionListener);
		}
		return menuList;
	}

	/**
	 * This method initializes menuPane
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getMenuPane() {
		if (menuPane == null) {
			menuPane = new JScrollPane(menuList);
			menuPane.setBounds(new Rectangle(14, 139, 309, 166));
			menuPane.setViewportView(getMenuList());
			menuPane.setVisible(true);
		}
		return menuPane;
	}

	/**
	 * This method initializes foodList
	 * 
	 * @return javax.swing.JList
	 */
	private JList getFoodList() {
		if (foodList == null) {
			foodList = new JList(listOfFood);
			foodList.setBounds(new Rectangle(591, 93, 148, 159));

			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {

					boolean adjust2 = listSelectionEvent.getValueIsAdjusting();

					if (!adjust2) { // Eğer seçim varsa
						JList list = (JList) listSelectionEvent.getSource();
						Object selectionValue = list.getSelectedValue();
						tiklanmisYemek = (proje.restaurant.Yemek) selectionValue;
						if (tiklanmisYemek == null) return;
						
						lblSeciliFiyat.setText(tiklanmisYemek.getPrice() + " TL");

					}

				}
			};
			foodList.addListSelectionListener(listSelectionListener);

		}
		return foodList;
	}

	/**
	 * This method initializes foodPane
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getFoodPane() {
		if (foodPane == null) {
			foodPane = new JScrollPane(foodList);
			foodPane.setBounds(new Rectangle(14, 337, 309, 177));
			foodPane.setViewportView(getFoodList());
			foodPane.setVisible(true);
		}
		return foodPane;
	}

	/**
	 * This method initializes change
	 * 
	 * @return java.awt.Button
	 */
	private Button getChange() {
		if (change == null) {
			change = new Button();
			change.setBounds(new Rectangle(627, 81, 123, 48));
			change.setLabel("Rol Değiştir");
			change.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					shut_up();
					Common com = new Common("Client", c);
					com.setVisible(true);
				}
			});

		}
		return change;
	}

	/**
	 * This method initializes textArea
	 * 
	 * @return java.awt.TextArea
	 */
	private TextArea getTextArea() {
		if (textArea == null) {
			textArea = new TextArea();
			textArea.setBounds(new Rectangle(254, 183, 498, 134));
		}
		return textArea;
	}

	/**
	 * This method initializes changed
	 * 
	 * @return java.awt.Button
	 */
	private Button getChanged() {
		if (changed == null) {
			changed = new Button();
			changed.setBounds(new Rectangle(462, 456, 291, 57));
			changed.setLabel("Rol Değiştir");

			changed.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					shut_up();
					Common com = new Common("Client", c);
					com.setVisible(true);

				}
			});
		}
		return changed;
	}

	/**
	 * This method initializes otherOrderList
	 * 
	 * @return javax.swing.JList
	 */
	private JList getOtherOrderList() {
		if (otherOrderList == null) {
			otherOrderList = new JList(listModel2);

			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {

					boolean adjust2 = listSelectionEvent.getValueIsAdjusting();

					if (!adjust2) { // Eğer seçim varsa
						JList list = (JList) listSelectionEvent.getSource();
						Object selectionValue = list.getSelectedValue();
						if(selectionValue == null) return;
						o = (proje.restaurant.Order) selectionValue;
						lblRestoran.setText(o.getRestaurant().toString());
						if (o.isOrderNew()) {
							/* Yeni */							
							lblFiyat.setText(o.getPrice() + " TL");
							txtDetails.setText("");					
							for(Object obj: o.getOrderDetails()) {
								if (obj instanceof proje.restaurant.Menu) {
									txtDetails.setText(txtDetails.getText().concat("**** Menü: " + ((proje.restaurant.Menu)obj).getName() + " (" + ((proje.restaurant.Menu)obj).getPrice() + " TL)"));
								}
								if (obj instanceof Yemek) {
									txtDetails.setText(txtDetails.getText().concat("**** Yemek: " + ((proje.restaurant.Yemek)obj).getAd() + " (" + ((proje.restaurant.Yemek)obj).getPrice() + " TL)"));
								}
							}
							sipDurum.setText("Siparişiniz onay bekliyor.");
							textArea.setText("(sipariş size ulaşmadan yorum bırakamazsınız.");
							textArea.setEnabled(false);
							oyLezzet.select("(yok)");
							oyLezzet.setEnabled(false);
							oyHiz.select("(yok)");
							oyHiz.setEnabled(false);
							oyFiyat.select("(yok)");
							oyFiyat.setEnabled(false);
							btnIptal.setEnabled(true);
							button.setEnabled(false);
							orderDate.setText(DateFormat.getInstance().format(o.getOrderTime()));
							completeDate.setText((o.getCompleteTime() == null ? "(henüz size ulaşmadı" : DateFormat.getInstance().format(o.getCompleteTime())));
						} else if (o.isOrderInProgress()) {
							/* Yolda */
							sipDurum.setText("Siparişiniz yolda.");
							lblFiyat.setText(o.getPrice() + " TL");
							txtDetails.setText("");					
							for(Object obj: o.getOrderDetails()) {
								if (obj instanceof proje.restaurant.Menu) {
									txtDetails.setText(txtDetails.getText().concat("**** Menü: " + ((proje.restaurant.Menu)obj).getName() + " (" + ((proje.restaurant.Menu)obj).getPrice() + " TL)"));
								}
								if (obj instanceof Yemek) {
									txtDetails.setText(txtDetails.getText().concat("**** Yemek: " + ((proje.restaurant.Yemek)obj).getAd() + " (" + ((proje.restaurant.Yemek)obj).getPrice() + " TL)"));
								}
							}
							textArea.setText("(sipariş size ulaşmadan yorum bırakamazsınız.)");	
							textArea.setEnabled(false);
							oyLezzet.select("(yok)");
							oyLezzet.setEnabled(false);
							oyHiz.select("(yok)");
							oyHiz.setEnabled(false);
							oyFiyat.select("(yok)");
							oyFiyat.setEnabled(false);
							btnIptal.setEnabled(false);
							button.setEnabled(false);
							
							orderDate.setText(DateFormat.getInstance().format(o.getOrderTime()));
							completeDate.setText((o.getCompleteTime() == null ? "(henüz size ulaşmadı" : DateFormat.getInstance().format(o.getCompleteTime())));

						} else {
							/* Ulaştı */
							lblFiyat.setText(o.getPrice() + " TL");
							txtDetails.setText("");					
							for(Object obj: o.getOrderDetails()) {
								if (obj instanceof proje.restaurant.Menu) {
									txtDetails.setText(txtDetails.getText().concat("**** Menü: " + ((proje.restaurant.Menu)obj).getName() + " (" + ((proje.restaurant.Menu)obj).getPrice() + " TL)"));
								}
								if (obj instanceof Yemek) {
									txtDetails.setText(txtDetails.getText().concat("**** Yemek: " + ((proje.restaurant.Yemek)obj).getAd() + " (" + ((proje.restaurant.Yemek)obj).getPrice() + " TL)"));
								}
							}
							sipDurum.setText("Siparişiniz teslim edildi.");							
							textArea.setText(o.getComment() == null ? "" : o.getComment());
							textArea.setEnabled(true);
							
							int puan = o.getLezzetPuan();
							if(puan == -1) {
								oyLezzet.select("(yok)");
							} else if (puan == 3) {
								oyLezzet.select("İyi");
							} else if (puan == 2) {
								oyLezzet.select("Orta");
							} else {
								oyLezzet.select("Kötü");
							}							
							puan = o.getHizPuan();
							if(puan == -1) {
								oyHiz.select("(yok)");
							} else if (puan == 3) {
								oyHiz.select("İyi");
							} else if (puan == 2) {
								oyHiz.select("Orta");
							} else {
								oyHiz.select("Kötü");
							}							
							puan = o.getFiyatPuan();
							if(puan == -1) {
								oyFiyat.select("(yok)");
							} else if (puan == 3) {
								oyFiyat.select("İyi");
							} else if (puan == 2) {
								oyFiyat.select("Orta");
							} else {
								oyFiyat.select("Kötü");
							}
							oyLezzet.setEnabled(true);				
							oyHiz.setEnabled(true);
							oyFiyat.setEnabled(true);
							
							btnIptal.setEnabled(false);
							button.setEnabled(true);
							
							orderDate.setText(DateFormat.getInstance().format(o.getOrderTime()));
							completeDate.setText((o.getCompleteTime() == null ? "(henüz size ulaşmadı" : DateFormat.getInstance().format(o.getCompleteTime())));

						}

					}
				}
			};
			otherOrderList.addListSelectionListener(listSelectionListener);
		}
		return otherOrderList;
	}

	/**
	 * This method initializes otherOrderPane
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getOtherOrderPane() {
		if (otherOrderPane == null) {
			otherOrderPane = new JScrollPane(otherOrderList);
			otherOrderPane.setBounds(new Rectangle(17, 61, 222, 456));
			otherOrderPane.setViewportView(getOtherOrderList());
		}
		return otherOrderPane;
	}

	/**
	 * This method initializes chooseList
	 * 
	 * @return javax.swing.JList
	 */
	private JList getChooseList() {
		if (chooseList == null) {
			chooseList = new JList(choose);
			chooseList.setVisible(true);

			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {

					boolean adjust2 = listSelectionEvent.getValueIsAdjusting();

					if (!adjust2) { // Eğer seçim varsa
						JList list = (JList) listSelectionEvent.getSource();
						selectionValuem = list.getSelectedValue();
						if (selectionValuem == null) return;
						tiklanmisSepettekiYemek = selectionValuem;
						
						lblSeciliFiyat.setText(((Fiyatlandirilabilir)tiklanmisSepettekiYemek).getPrice() + " TL");

					}
				}
			};
			chooseList.addListSelectionListener(listSelectionListener);
		}
		return chooseList;
	}

	/**
	 * This method initializes choosePane
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getChoosePane() {
		if (choosePane == null) {
			choosePane = new JScrollPane(chooseList);
			choosePane.setBounds(new Rectangle(350, 266, 399, 177));
			choosePane.setViewportView(getChooseList());
			choosePane.setVisible(true);
		}
		return choosePane;
	}
	/**
	 * This method initializes cikar
	 * 
	 * @return java.awt.Button
	 */
	private Button getCikar() {
		if (cikar == null) {
			cikar = new Button();
			cikar.setBounds(new Rectangle(642, 233, 107, 27));
			cikar.setLabel("Sepetten Çıkar");

			cikar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if(tiklanmisSepettekiYemek == null) return;
					choose.removeElement(tiklanmisSepettekiYemek);
					fiyatHesapla();
				}
			});
		}
		return cikar;
	}

	/**
	 * This method initializes iceriklist
	 * 
	 * @return javax.swing.JList
	 */
	private JList getIceriklist() {
		if (iceriklist == null) {
			iceriklist = new JList(icerik);
			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {
					boolean adjust2 = listSelectionEvent.getValueIsAdjusting();
					if (!adjust2) { // Eğer seçim varsa
						JList list = (JList) listSelectionEvent.getSource();
						Object selectionValue = list.getSelectedValue();
						if (selectionValue == null) return;
						Yemek menuY = (Yemek)selectionValue;						
						lblSeciliFiyat.setText(menuY.getPrice() + " TL");
					}
				}
			};
			iceriklist.addListSelectionListener(listSelectionListener);
		}
		return iceriklist;
	}

	/**
	 * This method initializes icerikPane
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getIcerikPane() {
		if (icerikPane == null) {
			icerikPane = new JScrollPane(iceriklist);
			icerikPane.setBounds(new Rectangle(347, 141, 405, 87));
			icerikPane.setViewportView(getIceriklist());
		}
		return icerikPane;
	}

	/**
	 * This method initializes siparisFiltre	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getSiparisFiltre() {
		if (siparisFiltre == null) {
			siparisFiltre = new JComboBox();
			siparisFiltre.setBounds(new Rectangle(17, 25, 223, 29));
		}
		siparisFiltre.addItem("Tüm Siparişler");
		siparisFiltre.addItem("Onay Bekleyenler");
		siparisFiltre.addItem("Yolda Olanlar");
		siparisFiltre.addItem("Yerine Ulaşmış Siparişler");

		siparisFiltre.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent e) {
				fillOrderBox();
			}

		});
		
		return siparisFiltre;
	}

	/**
	 * This method initializes btnIptal	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getBtnIptal() {
		if (btnIptal == null) {
			btnIptal = new Button();
			btnIptal.setBounds(new Rectangle(251, 456, 205, 28));
			btnIptal.setLabel("Sipariş İptal");
			btnIptal.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if (o != null) {
						o.cancelOrder();
						fillOrderBox();
					}
				}
			});
		}
		return btnIptal;
	}

	/**
	 * This method initializes txtDetails	
	 * 	
	 * @return java.awt.TextArea	
	 */
	private TextArea getTxtDetails() {
		if (txtDetails == null) {
			txtDetails = new TextArea();
			txtDetails.setBounds(new Rectangle(254, 60, 499, 87));
			txtDetails.setEditable(false);
		}
		return txtDetails;
	}

	/**
	 * This method initializes oyLezzet	
	 * 	
	 * @return java.awt.Choice	
	 */
	private Choice getOyLezzet() {
		if (oyLezzet == null) {
			oyLezzet = new Choice();
			oyLezzet.setBounds(new Rectangle(320, 331, 227, 26));
		}
		oyLezzet.add("(yok)");
		oyLezzet.add("İyi");
		oyLezzet.add("Orta");
		oyLezzet.add("Kötü");
		return oyLezzet;
	}

	/**
	 * This method initializes oyFiyat	
	 * 	
	 * @return java.awt.Choice	
	 */
	private Choice getOyFiyat() {
		if (oyFiyat == null) {
			oyFiyat = new Choice();
			oyFiyat.setBounds(new Rectangle(322, 359, 225, 21));
		}
		oyFiyat.add("(yok)");
		oyFiyat.add("İyi");
		oyFiyat.add("Orta");
		oyFiyat.add("Kötü");
		return oyFiyat;
	}

	/**
	 * This method initializes oyHiz	
	 * 	
	 * @return java.awt.Choice	
	 */
	private Choice getOyHiz() {
		if (oyHiz == null) {
			oyHiz = new Choice();
			oyHiz.setBounds(new Rectangle(319, 387, 229, 21));
		}
		oyHiz.add("(yok)");
		oyHiz.add("İyi");
		oyHiz.add("Orta");
		oyHiz.add("Kötü");
		return oyHiz;
	}

	/**
	 * This method initializes btnMenuEkle	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getBtnMenuEkle() {
		if (btnMenuEkle == null) {
			btnMenuEkle = new Button();
			btnMenuEkle.setBounds(new Rectangle(175, 109, 145, 29));
			btnMenuEkle.setLabel("Menüyü Sepete Ekle");
			btnMenuEkle.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if(tiklanmisMenu == null) return;
					choose.addElement(tiklanmisMenu);
					fiyatHesapla();
				}
			});
		}
		return btnMenuEkle;
	}

	/**
	 * This method initializes btnYemekEkle	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getBtnYemekEkle() {
		if (btnYemekEkle == null) {
			btnYemekEkle = new Button();
			btnYemekEkle.setBounds(new Rectangle(179, 306, 143, 30));
			btnYemekEkle.setLabel("Yemeği Sepete Ekle");
			btnYemekEkle.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if(tiklanmisYemek == null) return;
					choose.addElement(tiklanmisYemek);
					fiyatHesapla();
				}
			});
		}
		return btnYemekEkle;
	}

	/**
	 * This method initializes btnSiparisVer	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getBtnSiparisVer() {
		if (btnSiparisVer == null) {
			btnSiparisVer = new Button();
			btnSiparisVer.setBounds(new Rectangle(558, 477, 187, 40));
			btnSiparisVer.setLabel("SİPARİŞ VER!");
			btnSiparisVer.addActionListener(new java.awt.event.ActionListener() {
				@SuppressWarnings("unchecked")
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Vector v = new Vector();
					for(int i=0;i<choose.size();i++) {
						v.addElement(choose.elementAt(i));
					}
					if(v.size() == 0) return;
					Order o = new Order(c, r, v);
					System.out.println(o);
					resetNewOrderWindow();
					fillOrderBox();
				}
			});
		}
		return btnSiparisVer;
	}
	private void resetNewOrderWindow() {
		r = (Restaurant)restaurantBox.getSelectedItem();
		if (r == null) return;
		oyy.setText(r.getOrtPuan() + " ");

		listofMenu.clear();
		for (proje.restaurant.Menu m : r.getMenuler()) {
			listofMenu.addElement(m);
		}
		
		listOfFood.clear();
		for (proje.restaurant.Yemek y : r.getYemekler()) {
			listOfFood.addElement(y);
		}
		choose.clear();
		icerik.clear();
		lblSeciliFiyat.setText("");
		
		lblNormalFiyat.setText("Normal fiyat: 0 TL");
		lblIndirimliFiyat.setText("Sizin ödeyeceğiniz: 0 TL");
	}
	@SuppressWarnings("unchecked")
	private void fiyatHesapla() {
		double fiyat = 0;
		for(int i=0;i<choose.size();i++) {
			fiyat += ((Fiyatlandirilabilir)choose.getElementAt(i)).getPrice();
		}
		fiyat = (double)((int)(fiyat * 100))/100;
		lblNormalFiyat.setText("Normal fiyat: " + fiyat + " TL");
		
		Vector v = new Vector();
		for(int i=0;i<choose.size();i++) {
			v.addElement(choose.elementAt(i));
		}		
		lblIndirimliFiyat.setText("Sizin ödeyeceğiniz: " + Order.askPrice(c, v) + " TL");
		int t = c.getType();
		String s = "";
		switch (t) {
			case CONSTANT.SILVERCUSTOMER:
				s = "Slv";
				break;
			case CONSTANT.GOLDCUSTOMER:
				s = "Gld";
				break;
			case CONSTANT.URANIUMCUSTOMER:
				s = "Urny.";
				break;
		}
		lblIndirimliFiyat.setText(lblIndirimliFiyat.getText().concat(" (" + s + ")"));
	}

	/**
	 * This method initializes tumRestoranlar	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getTumRestoranlar() {
		if (tumRestoranlar == null) {
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.fill = GridBagConstraints.BOTH;
			gridBagConstraints.gridy = 0;
			gridBagConstraints.weightx = 1.0;
			gridBagConstraints.weighty = 1.0;
			gridBagConstraints.gridx = 0;
			tumRestoranlar = new JPanel();
			tumRestoranlar.setLayout(new GridBagLayout());
			tumRestoranlar.add(getAllrestList(), gridBagConstraints);
		}
		return tumRestoranlar;
	}

	/**
	 * This method initializes allrestList	
	 * 	
	 * @return java.awt.List	
	 */
	private List getAllrestList() {
		if (allrestList == null) {
			allrestList = new List();
			allrestList.setFont(new Font("Dialog", Font.PLAIN, 14));
		}
		
		for(Restaurant r: Main.restaurants.sortSortableOnes(true)) {
			allrestList.add(r + " (" + r.getOrtPuan() + "/3.00) Adres: " + r.getAdress());
		}
		
		return allrestList;
	}
}
