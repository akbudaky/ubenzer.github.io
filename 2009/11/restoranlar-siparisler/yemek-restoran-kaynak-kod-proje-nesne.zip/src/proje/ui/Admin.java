package proje.ui;

import java.awt.CheckboxGroup;
import java.awt.Frame;
import java.awt.Dimension;
import java.awt.Label;
import java.awt.Rectangle;
import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JLabel;
import java.awt.TextField;
import java.awt.TextArea;
import javax.swing.JComboBox;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JScrollPane;
import javax.swing.JButton;

import proje.bootstrapper.Main;
import proje.restaurant.Restaurant;
import proje.restaurant.Yemek;
import proje.user.Customer;
import proje.user.Operator;
import proje.user.User;
import proje.user.Administrator;
import proje.util.CONSTANT;
import java.text.DateFormat;
import java.awt.Font;

public class Admin extends Frame {

	private static final long serialVersionUID = 1L;

	private JTabbedPane jTabbedPane = null;

	private JPanel restaurantPanel = null;

	private JPanel clientPanel = null;

	private JLabel jLabel = null;

	DefaultListModel listModel = new DefaultListModel();

	DefaultListModel restaurants = new DefaultListModel();

	DefaultListModel listOfMenu = new DefaultListModel();

	DefaultListModel listOfOrder = new DefaultListModel();

	private Label label = null;

	private Label label1 = null;

	private Label label2 = null;

	private Label label3 = null;

	private Label label5 = null;

	private TextField nameField = null;

	private TextField surnameField = null;

	private TextArea adresArea = null;

	private JComboBox fm = null;

	private TextField textField = null;

	private JLabel image = null;

	private Button registerButton = null;

	private Button deleteButton = null;

	private Button changedButton = null;

	private Label label6 = null;

	private JList restaurantList = null;

	private Label label7 = null;

	private TextField resnameField = null;

	private Label label8 = null;

	private TextArea resadressArea = null;

	private Label label9 = null;

	private JScrollPane jScrollPane1 = null;

	private JButton jButton = null;

	private String what;

	private Button button = null;

	private Button button1 = null;

	private Button deletebutton2 = null;

	private Label label12 = null;

	private JList foodList = null;

	private JScrollPane jScrollPane2 = null;

	DefaultListModel listOfFood = new DefaultListModel();

	private Label label14 = null;

	private JList menuList = null;

	private JScrollPane jScrollPane3 = null;

	private Label label16 = null;

	private TextArea commentArea = null;

	private Label label17 = null;

	private Label label18 = null;

	private Label label19 = null;

	private Label label20 = null;

	private Label label21 = null;

	private JList clientList = null;

	private JScrollPane clientPane = null;

	private JScrollPane orderPane = null;

	private Label label22 = null;

	private Label label23 = null;

	private Label label24 = null;

	private Button rolButton = null;

	private Label label26 = null;

	private Label label27 = null;

	private Label label11 = null;

	CheckboxGroup cbg = new CheckboxGroup();

	private Label label25 = null;

	private boolean changeMusteri;

	private boolean changeRestoran;

	private JComboBox typeBox = null;

	private Label label4 = null;

	private Customer c;

	private TextField opName = null;

	private TextField opLast = null;

	private Restaurant r;

	private JList orderList1 = null;

	/**
	 * This is the default constructor
	 */
	public Admin() {
		super();
		initialize();
		/* Restoran da, müşteri de ekleme konumunda başlar */
		yeniKayitaGecmeIslemleri();
		newResProcess();
		fill();
		fillr();

	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */ 
	private void initialize() {
		this.setLayout(null);
		this.setSize(800, 600);
		this.setResizable(false);		
		this.setTitle("Yönetici");
		for (User a : Main.users) {
			if (a instanceof Administrator) {
				this.setTitle("Yönetici: " + a);
				break;
			}
		}

		this.add(getJTabbedPane(), null);

		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
				// windowClosing()
			}
		});

	}

	public void shut_up() {
		this.setVisible(false);
	}

	/**
	 * This method initializes jTabbedPane
	 * 
	 * @return javax.swing.JTabbedPane
	 */
	private JTabbedPane getJTabbedPane() {
		if (jTabbedPane == null) {
			jTabbedPane = new JTabbedPane();
			jTabbedPane.setBounds(new Rectangle(14, 40, 772, 546));
			jTabbedPane.addTab("Lokanta İşlemleri", null, getRestaurantPanel(),
					null);
			jTabbedPane.addTab("Müsteri İşlemleri", null, getClientPanel(),
					null);

		}
		return jTabbedPane;
	}

	/**
	 * This method initializes restaurantPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getRestaurantPanel() {
		if (restaurantPanel == null) {
			label11 = new Label();
			label11.setBounds(new Rectangle(652, 226, 49, 22));
			label11.setFont(new Font("Dialog", Font.BOLD, 12));
			label11.setText("");
			label24 = new Label();
			label24.setBounds(new Rectangle(542, 226, 107, 22));
			label24.setText("Seçili yemek fiyatı:");
			label23 = new Label();
			label23.setBounds(new Rectangle(654, 373, 48, 23));
			label23.setFont(new Font("Dialog", Font.BOLD, 12));
			label23.setText("");
			label22 = new Label();
			label22.setBounds(new Rectangle(544, 372, 105, 22));
			label22.setText("Seçili menü fiyatı:");
			label14 = new Label();
			label14.setBounds(new Rectangle(235, 371, 68, 21));
			label14.setText("Menüler:");
			label12 = new Label();
			label12.setBounds(new Rectangle(236, 222, 72, 19));
			label12.setText("Yemekler:");

			label9 = new Label();
			label9.setBounds(new Rectangle(543, 13, 206, 21));
			label9.setText("Operatörün adı ve soyadı:");
			label8 = new Label();
			label8.setBounds(new Rectangle(211, 45, 93, 22));
			label8.setText("Adresi:");
			label7 = new Label();
			label7.setBounds(new Rectangle(210, 15, 93, 25));
			label7.setText("Adı:");
			label6 = new Label();
			label6.setBounds(new Rectangle(11, 13, 182, 21));
			label6.setFont(new Font("Dialog", Font.BOLD, 12));
			label6.setText("Lokantalar");
			restaurantPanel = new JPanel();
			restaurantPanel.setLayout(null);
			restaurantPanel.add(label6, null);
			restaurantPanel.add(label7, null);
			restaurantPanel.add(getResnameField(), null);
			restaurantPanel.add(label8, null);
			restaurantPanel.add(getResadressArea(), null);
			restaurantPanel.add(label9, null);
			restaurantPanel.add(getJScrollPane1(), null);
			restaurantPanel.add(getButton(), null);
			restaurantPanel.add(getButton1(), null);
			restaurantPanel.add(getDeletebutton2(), null);
			restaurantPanel.add(label12, null);
			restaurantPanel.add(getJScrollPane2(), null);
			restaurantPanel.add(label14, null);
			restaurantPanel.add(getJScrollPane3(), null);
			restaurantPanel.add(label22, null);
			restaurantPanel.add(label23, null);
			restaurantPanel.add(label24, null);
			restaurantPanel.add(getRolButton(), null);
			restaurantPanel.add(label11, null);
			restaurantPanel.add(getOpName(), null);
			restaurantPanel.add(getOpLast(), null);
		} 
		return restaurantPanel;
	}

	/**
	 * This method initializes clientPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getClientPanel() {
		if (clientPanel == null) {
			label4 = new Label();
			label4.setBounds(new Rectangle(215, 280, 319, 44));
			label4.setMinimumSize(new Dimension(319, 44));
			label4.setMaximumSize(new Dimension(319, 44));
			label4.setText("");
			label4.setVisible(false);

			label25 = new Label();
			label25.setBounds(new Rectangle(215, 257, 82, 18));
			label25.setText("Müşteri Tipi:");
			label25.setVisible(true);
			label27 = new Label();
			label27.setVisible(true);
			label27.setBounds(new Rectangle(700, 369, 58, 26));
			label27.setText("");
			label26 = new Label();
			label26.setVisible(false);
			label26.setBounds(new Rectangle(579, 368, 107, 25));
			label26.setText("Kullandığı oy sayısı:");
			label21 = new Label();
			label21.setBounds(new Rectangle(207, 393, 96, 20));
			label21.setText("Siparişleri:");
			label21.setVisible(false);
			label20 = new Label();
			label20.setBounds(new Rectangle(315, 362, 210, 21));
			label20.setText(" ");
			label20.setVisible(false);
			label19 = new Label();
			label19.setBounds(new Rectangle(208, 364, 94, 20));
			label19.setText("Son Teslim:");
			label19.setVisible(false);
			label18 = new Label();
			label18.setVisible(false);
			label18.setBounds(new Rectangle(699, 409, 61, 22));
			label18.setText("");
			label18.setVisible(true);
			label17 = new Label();
			label17.setBounds(new Rectangle(576, 408, 119, 22));
			label17.setText("Toplam sipariş sayısı:");
			label17.setVisible(true);
			label17.setVisible(false);
			label16 = new Label();
			label16.setBounds(new Rectangle(575, 198, 109, 23));
			label16.setText("Son bıraktığı yorum:");
			label16.setVisible(false);
			image = new JLabel();
			image.setBounds(new Rectangle(575, 15, 141, 168));
			label5 = new Label();
			label5.setBounds(new Rectangle(216, 334, 87, 18));
			label5.setText("Dış Görünüm:");
			label3 = new Label();
			label3.setBounds(new Rectangle(216, 222, 85, 20));
			label3.setText("Cinsiyet:");
			label2 = new Label();
			label2.setBounds(new Rectangle(219, 90, 84, 22));
			label2.setText("Adresi:");
			label1 = new Label();
			label1.setBounds(new Rectangle(219, 49, 84, 23));
			label1.setText("Soyadı:");
			label = new Label();
			label.setBounds(new Rectangle(220, 13, 81, 25));
			label.setText("Adı:");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(11, 12, 188, 22));
			jLabel.setText("Müşteriler");

			clientPanel = new JPanel();
			clientPanel.setLayout(null);
			clientPanel.add(jLabel, null);
			clientPanel.add(label, null);
			clientPanel.add(label1, null);
			clientPanel.add(label2, null);
			clientPanel.add(label3, null);
			clientPanel.add(label5, null);
			clientPanel.add(getNameField(), null);
			clientPanel.add(getSurnameField(), null);
			clientPanel.add(getAdresArea(), null);
			clientPanel.add(getFm(), null);
			clientPanel.add(getTextField(), null);
			clientPanel.add(image, null);
			clientPanel.add(getRegisterButton(), null);
			clientPanel.add(getDeleteButton(), null);
			clientPanel.add(getChangedButton(), null);

			clientPanel.add(getJButton(), null);
			clientPanel.add(label16, null);
			clientPanel.add(getCommentArea(), null);
			clientPanel.add(label17, null);
			clientPanel.add(label18, null);
			clientPanel.add(label19, null);
			clientPanel.add(label20, null);
			clientPanel.add(label21, null);
			clientPanel.add(getClientPane(), null);
			clientPanel.add(getOrderPane(), null);
			clientPanel.add(label26, null);
			clientPanel.add(label27, null);
			clientPanel.add(label25, null);
			clientPanel.add(getTypeBox(), null);
			clientPanel.add(label4, null);
			
		}
		return clientPanel;
	}

	/**
	 * This method initializes clientList
	 * 
	 * @return javax.swing.JList
	 */
	private JList getClientList() {
		if (clientList == null) {
			clientList = new JList(listModel);

			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {

					boolean adjust = listSelectionEvent.getValueIsAdjusting();

					if (!adjust) { // seçim varsa eger
						JList list = (JList) listSelectionEvent.getSource();
						Object selectionValue = list.getSelectedValue();
						listOfOrder.clear();
						c = (Customer) selectionValue;
						if (c == null) return;

						duzenlemeModunaGecmeIslemleri();

						if (c.getGender() == CONSTANT.FEMALE) {
							image.setIcon(new ImageIcon("bulent.jpg"));
							textField.setText(c.getLooklike());
						} else {
							image.setIcon(new ImageIcon("muslum.jpg"));
							textField.setText(c.getLooklike());
						}
						
						fm.setEditable(true);
						if (c.getGender() == CONSTANT.FEMALE) {
							fm.setSelectedItem("Süslü");
						} else {
							fm.setSelectedItem("Sakallı");
						}
						fm.setEditable(false);

						String a = "";
						switch (c.getType()) {
						case CONSTANT.URANIUMCUSTOMER:
							a = "Uranyum";
							break;
						case CONSTANT.GOLDCUSTOMER:
							a = "Gold";
							break;
						case CONSTANT.SILVERCUSTOMER:
							a = "Silver";
							break;
						}
						label4.setText("Müşteri " + a + " ayrıcalıklarına sahiptir.");
	
						typeBox.setEditable(true);
						if (c.getIsTypeCheckingAutomated()) {
							typeBox.setSelectedItem("(Otomatik)");
						} else {
							typeBox.setSelectedItem(a);
						}
						typeBox.setEditable(false);

						nameField.setText(c.getFirstName());
						surnameField.setText(c.getLastName());

						String count;
						count = (c.getTotalOrderCount()) + "";
						label18.setText(count);

						String vote;
						vote = c.getTotalVoteCount() + " ";
						
						label27.setText(vote);
						
						adresArea.setText(c.getAdress());

						if (c.getLastOrderTime() == null) {
							label20.setText("(yok)");
						} else {
							label20.setText(DateFormat.getInstance().format(
									c.getLastOrderTime()));
							
						}
						if (c.getLastCommentsUserWrote(1).size() != 0) {
							commentArea.setText(c.getLastCommentsUserWrote(1).elementAt(0));
						} else {
							commentArea.setText("(henüz hiç yorum bırakmadı.)");
						}
						
						
						for (proje.restaurant.Order o : c
								.getAllOrdersByCurrentUserSortedByDateDESC()) {
							
							listOfOrder.addElement(o);
						}				

					}
				}
			};
			clientList.addListSelectionListener(listSelectionListener);
		}
		return clientList;
	}

	/**
	 * This method initializes nameField
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getNameField() {
		if (nameField == null) {
			nameField = new TextField();
			nameField.setBounds(new Rectangle(311, 14, 211, 22));
		}
		return nameField;
	}

	/**
	 * This method initializes surnameField
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getSurnameField() {
		if (surnameField == null) {
			surnameField = new TextField();
			surnameField.setBounds(new Rectangle(313, 48, 208, 24));
		}
		return surnameField;
	}

	/**
	 * This method initializes adresArea
	 * 
	 * @return java.awt.TextArea
	 */
	private TextArea getAdresArea() {
		if (adresArea == null) {
			adresArea = new TextArea();
			adresArea.setBounds(new Rectangle(315, 90, 208, 119));
		}
		return adresArea;
	}

	/**
	 * This method initializes fm
	 * 
	 * @return javax.swing.JComboBox
	 */
	private JComboBox getFm() {
		if (fm == null) {
			fm = new JComboBox();
			fm.setBounds(new Rectangle(315, 223, 208, 21));

			fm.addItem("Süslü");
			fm.addItem("Sakallı");
			fm.setEditable(false);

			fm.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					if (fm.getSelectedItem() == "Süslü") {
						image.setIcon(new ImageIcon("bulent.jpg"));
					} else if (fm.getSelectedItem() == "Sakallı") {
						image.setIcon(new ImageIcon("muslum.jpg"));
					}

				}
			});

		}
		return fm;
	}

	/**
	 * This method initializes textField
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getTextField() {
		if (textField == null) {
			textField = new TextField();
			textField.setBounds(new Rectangle(313, 329, 212, 21));
		}
		return textField;
	}

	/**
	 * This method initializes registerButton
	 * 
	 * @return java.awt.Button
	 */
	private Button getRegisterButton() {
		if (registerButton == null) {
			registerButton = new Button();
			registerButton.setBounds(new Rectangle(13, 471, 179, 25));
			registerButton.setLabel("Yeni Kayıt");

			registerButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// buraya basip basmamasina göre diger buton
					// degistirilecek
					yeniKayitaGecmeIslemleri();

				}
			});
		}
		return registerButton;
	}

	/**
	 * This method initializes deleteButton
	 * 
	 * @return java.awt.Button
	 */
	private Button getDeleteButton() {
		if (deleteButton == null) {
			deleteButton = new Button();
			deleteButton.setBounds(new Rectangle(582, 433, 76, 35));
			deleteButton.setLabel("Sil Gitsin!");
			deleteButton.setVisible(true);
			deleteButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					c.deleteUser();
					listModel.removeElement(c);
					yeniKayitaGecmeIslemleri();

				}
			});
		}
		return deleteButton;
	}

	/**
	 * This method initializes changedButton
	 * 
	 * @return java.awt.Button
	 */
	private Button getChangedButton() {
		if (changedButton == null) {
			changedButton = new Button();
			changedButton.setBounds(new Rectangle(675, 433, 79, 33));

			changedButton.setLabel("Güncelle :)");
			changedButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					boolean choose;
					if (fm.getSelectedItem() == "Süslü") {
						choose = CONSTANT.FEMALE;
					} else {
						choose = CONSTANT.MALE;
					}
					/* Düzenle */
					if (changeMusteri == true) {
						c.setFirstName(nameField.getText());
						c.setLastName(surnameField.getText());
						c.setAdress(adresArea.getText());
						c.setGender(choose);
						c.setLooklike(textField.getText());

						int tip;
						if (((String) (typeBox.getSelectedItem()))
								.equalsIgnoreCase("Silver")) {
							tip = CONSTANT.SILVERCUSTOMER;
						} else if (((String) (typeBox.getSelectedItem()))
								.equalsIgnoreCase("Gold")) {
							tip = CONSTANT.GOLDCUSTOMER;
						} else if (((String) (typeBox.getSelectedItem()))
								.equalsIgnoreCase("Uranyum")) {
							tip = CONSTANT.URANIUMCUSTOMER;
						} else {
							tip = CONSTANT.AUTO;
						}

						c.changeType(tip);
						listModel.clear();
						fill();

					} else {
						/* Ekle */
						int tip;
						if (((String) (typeBox.getSelectedItem()))
								.equalsIgnoreCase("Silver")) {
							tip = CONSTANT.SILVERCUSTOMER;
						} else if (((String) (typeBox.getSelectedItem()))
								.equalsIgnoreCase("Gold")) {
							tip = CONSTANT.GOLDCUSTOMER;
						} else if (((String) (typeBox.getSelectedItem()))
								.equalsIgnoreCase("Uranyum")) {
							tip = CONSTANT.URANIUMCUSTOMER;
						} else {
							tip = CONSTANT.AUTO;
						}

						Customer cus = new Customer(nameField.getText(),
								surnameField.getText(), adresArea.getText(),
								choose, textField.getText(), tip);
						System.out.println(cus);
						listModel.clear();
						fill();
					}
					yeniKayitaGecmeIslemleri();
				}
			});
		}
		return changedButton;
	}

	private void fill() {
		for (User u : Main.users.sortSortableOnes(true)) {
			if (u instanceof Customer) {
				listModel.addElement(u);
			}

		}
	}

	/**
	 * This method initializes restaurantList
	 * 
	 * @return javax.swing.JList
	 */
	private JList getRestaurantList() {
		if (restaurantList == null) {
			restaurantList = new JList(restaurants);

			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {

					boolean adjust2 = listSelectionEvent.getValueIsAdjusting();
					
					if (!adjust2) { // Eğer seçim varsa
						changeProcess();
						JList list = (JList) listSelectionEvent.getSource();
						Object selectionValue = list.getSelectedValue();
						r = ((Restaurant) selectionValue);
						if(r==null) return;
						resnameField.setText(r.toString());
						resadressArea.setText(r.getAdress());
						opName.setText(r.getOperatorFirstName());
						opLast.setText(r.getOperatorLastName());
						
						label9.setVisible(true);

						for (proje.restaurant.Yemek y : r.getYemekler()) {
							listOfFood.addElement(y);
						}

						for (proje.restaurant.Menu m : r.getMenuler()) {
							listOfMenu.addElement(m);
						}

					}
				}
			};
			restaurantList.addListSelectionListener(listSelectionListener);

		}
		return restaurantList;
	}

	/**
	 * This method initializes resnameField
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getResnameField() {
		if (resnameField == null) {
			resnameField = new TextField();
			resnameField.setBounds(new Rectangle(314, 15, 213, 23));
		}
		return resnameField;
	}

	/**
	 * This method initializes resadressArea
	 * 
	 * @return java.awt.TextArea
	 */
	private TextArea getResadressArea() {
		if (resadressArea == null) {
			resadressArea = new TextArea();
			resadressArea.setBounds(new Rectangle(314, 48, 212, 136));
		}
		return resadressArea;
	}

	/**
	 * This method initializes jScrollPane1
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane(restaurantList);
			jScrollPane1.setBounds(new Rectangle(11, 43, 185, 427));
			jScrollPane1.setViewportView(getRestaurantList());
		}
		return jScrollPane1;
	}

	/**
	 * This method initializes jButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(577, 473, 181, 43));
			jButton.setText("Rol değiştir");

			jButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					shut_up();
					what = "Admin";
					Common common = new Common(what,r);
					common.setVisible(true);
				}
			});
		}
		return jButton;
	}

	/**
	 * This method initializes button
	 * 
	 * @return java.awt.Button
	 */
	private Button getButton() {
		if (button == null) {
			button = new Button();
			button.setBounds(new Rectangle(665, 407, 94, 31));

			button.setLabel("Ekle/Düzenle");
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (changeRestoran) {
						r.setName(resnameField.getText());
						r.setAdress(resadressArea.getText());
						r.setOperatorName(opName.getText(), opLast.getText());
						restaurants.clear();
						fillr();
					} else {
						Operator o = new Operator(opName.getText(), opLast.getText());
						Restaurant r = new Restaurant(resnameField.getText(),
								resadressArea.getText(), o);
						System.out.println(r);
						restaurants.clear();
						fillr();
					}
					newResProcess();
				}
			});
		}
		return button;
	}

	private void newResProcess() {
		changeRestoran = false;
		button.setLabel("Ekle :)");
		jScrollPane3.setVisible(false);
		jScrollPane2.setVisible(false);
		resnameField.setText("");
		resadressArea.setText("");
		label24.setVisible(false);
		label11.setVisible(false);
		label22.setVisible(false);
		label23.setVisible(false);
		opName.setText("");
		opLast.setText("");
		deletebutton2.setVisible(false);
		label14.setVisible(false);
		label12.setVisible(false);
	}

	private void changeProcess() {
		changeRestoran = true;
		button.setLabel("Düzenle");
		listOfFood.clear();
		listOfMenu.clear();
		jScrollPane3.setVisible(true);
		jScrollPane2.setVisible(true);
		
		label24.setVisible(false);
		label11.setVisible(false);
		label22.setVisible(false);
		label23.setVisible(false);
		
		deletebutton2.setVisible(true);
		label14.setVisible(true);
		label12.setVisible(true);
	}

	/**
	 * This method initializes button1
	 * 
	 * @return java.awt.Button
	 */
	private Button getButton1() {
		if (button1 == null) {
			button1 = new Button();
			button1.setBounds(new Rectangle(12, 471, 183, 29));
			button1.setLabel("Yeni Kayıt");

			button1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					changeRestoran = true;
					newResProcess();
				}
			});
		}
		return button1;
	}

	private void duzenlemeModunaGecmeIslemleri() {
		label19.setVisible(true);
		label20.setVisible(true);
		label21.setVisible(true);
		orderList1.setVisible(true);
		orderPane.setVisible(true);
		commentArea.setVisible(true);
		label16.setVisible(true);
		label26.setVisible(true);
		label27.setVisible(true);
		label17.setVisible(true);
		label18.setVisible(true);
		deleteButton.setVisible(true);
		label4.setVisible(true);
		changeMusteri = true;
		changedButton.setLabel("Güncelle :)");
	}

	private void yeniKayitaGecmeIslemleri() {
		image.setIcon(new ImageIcon("bulent.jpg"));
		deleteButton.setVisible(false);
		changedButton.setLabel("Ekle :)");
		changeMusteri = false;
		label4.setVisible(false);
		nameField.setText("");
		surnameField.setText("");
		adresArea.setText("");
		label16.setVisible(false);
		label17.setVisible(false);
		label18.setVisible(false);
		label19.setVisible(false);
		label20.setVisible(false);
		label21.setVisible(false);
		label26.setVisible(false);
		label27.setVisible(false);
		commentArea.setVisible(false);
		textField.setText("");
		orderList1.setVisible(false);
		orderPane.setVisible(false);
		
		typeBox.setEditable(true);
		typeBox.setSelectedItem("(Otomatik)");
		typeBox.setEditable(false);
		
		fm.setEditable(true);
		fm.setSelectedItem("Süslü");
		fm.setEditable(false);
		
	}

	/**
	 * This method initializes deletebutton2
	 * 
	 * @return java.awt.Button
	 */
	private Button getDeletebutton2() {
		if (deletebutton2 == null) {
			deletebutton2 = new Button();
			deletebutton2.setBounds(new Rectangle(665, 443, 95, 31));
			deletebutton2.setLabel("Sil!");

			deletebutton2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					r.deleteRestaurant();
					restaurants.removeElement(r);					
					newResProcess();
				}
			});
		}
		return deletebutton2;
	}

	/**
	 * This method initializes foodList
	 * 
	 * @return javax.swing.JList
	 */
	private JList getFoodList() {
		if (foodList == null) {
			foodList = new JList(listOfFood);
			foodList.setBounds(new Rectangle(0, 0, 210, 127));

			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {

					boolean adjust2 = listSelectionEvent.getValueIsAdjusting();

					if (!adjust2) { // seçim varsa eger
						JList list = (JList) listSelectionEvent.getSource();
						Object selectionValue = list.getSelectedValue();
						label24.setVisible(true);
						label11.setVisible(true);
						Yemek y = (Yemek) selectionValue;
						if (y == null)
							return;
						String pr = y.getPrice() + " ";
						label11.setText(pr);

					}
				}
			};
			foodList.addListSelectionListener(listSelectionListener);
		}
		return foodList;
	}

	/**
	 * This method initializes jScrollPane2
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getJScrollPane2() {
		if (jScrollPane2 == null) {
			jScrollPane2 = new JScrollPane(foodList);
			jScrollPane2.setBounds(new Rectangle(314, 222, 221, 136));
			jScrollPane2.setViewportView(getFoodList());
		}
		return jScrollPane2;
	}

	/**
	 * This method initializes menuList
	 * 
	 * @return javax.swing.JList
	 */
	private JList getMenuList() {
		if (menuList == null) {
			menuList = new JList(listOfMenu);

			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {

					boolean adjust2 = listSelectionEvent.getValueIsAdjusting();

					if (!adjust2) { // seçim varsa eger
						JList list = (JList) listSelectionEvent.getSource();
						Object selectionValue = list.getSelectedValue();
						label22.setVisible(true);
						label23.setVisible(true);
						proje.restaurant.Menu m = ((proje.restaurant.Menu) selectionValue);
						if (m == null)
							return;
						String pr = m.getPrice() + " ";
						label23.setText(pr);

					}
				}
			};
			menuList.addListSelectionListener(listSelectionListener);
		}
		return menuList;
	}

	/**
	 * This method initializes jScrollPane3
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getJScrollPane3() {
		if (jScrollPane3 == null) {
			jScrollPane3 = new JScrollPane(menuList);
			jScrollPane3.setBounds(new Rectangle(313, 370, 221, 148));
			jScrollPane3.setViewportView(getMenuList());
		}
		return jScrollPane3;
	}

	/**
	 * This method initializes commentArea
	 * 
	 * @return java.awt.TextArea
	 */
	private TextArea getCommentArea() {
		if (commentArea == null) {
			commentArea = new TextArea();
			commentArea.setBounds(new Rectangle(574, 233, 177, 124));
			commentArea.setEnabled(true);
			commentArea.setEditable(false);
			commentArea.setVisible(false);
		}
		return commentArea;
	}

	/**
	 * This method initializes clientPane
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getClientPane() {
		if (clientPane == null) {
			clientPane = new JScrollPane(clientList);
			clientPane.setBounds(new Rectangle(11, 45, 183, 422));

			clientPane.setViewportView(getClientList());
		}
		return clientPane;
	}

	/**
	 * This method initializes orderPane
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getOrderPane() {
		if (orderPane == null) {
			orderPane = new JScrollPane(orderList1);
			orderPane.setBounds(new Rectangle(313, 392, 215, 123));
			orderPane.setViewportView(getOrderList1());
		}
		return orderPane;
	}

	/**
	 * This method initializes rolButton
	 * 
	 * @return java.awt.Button
	 */
	private Button getRolButton() {
		if (rolButton == null) {
			rolButton = new Button();
			rolButton.setBounds(new Rectangle(664, 476, 95, 35));
			rolButton.setLabel("Rol Değiştir!");
			rolButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					shut_up();
					Common common = new Common("Admin",r);
					common.setVisible(true);

				}
			});

		}
		return rolButton;
	}

	/**
	 * This method initializes typeBox
	 * 
	 * @return javax.swing.JComboBox
	 */
	private JComboBox getTypeBox() {
		if (typeBox == null) {
			typeBox = new JComboBox();
			typeBox.setBounds(new Rectangle(316, 254, 207, 23));

			typeBox.addItem("(Otomatik)");
			typeBox.addItem("Silver");
			typeBox.addItem("Gold");
			typeBox.addItem("Uranyum");

			typeBox.setEditable(false);

		}
		return typeBox;
	}

	private void fillr() {
		for (Restaurant r : Main.restaurants) {
			restaurants.addElement(r);
		}
	}

	/**
	 * This method initializes opName
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getOpName() {
		if (opName == null) {
			opName = new TextField();
			opName.setBounds(new Rectangle(601, 37, 146, 21));
		}
		return opName;
	}

	/**
	 * This method initializes opLast
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getOpLast() {
		if (opLast == null) {
			opLast = new TextField();
			opLast.setBounds(new Rectangle(602, 62, 146, 23));
		}
		return opLast;
	}


	/**
	 * This method initializes orderList1	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getOrderList1() {
		if (orderList1 == null) {
			orderList1 = new JList(listOfOrder);
			orderList1.setBounds(new Rectangle(215, 367, 209, 126));
		}
		return orderList1;
	}



}  //  @jve:decl-index=0:visual-constraint="40,57"
