package proje.ui;

import java.awt.CheckboxGroup;
import java.awt.Frame;
import java.awt.Rectangle;
import java.awt.Checkbox;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JComboBox;

import proje.bootstrapper.Main;
import proje.restaurant.Restaurant;
import proje.user.Customer;
import proje.user.User;
import java.awt.Font;

public class Entry extends Frame {

	private static final long serialVersionUID = 1L;

	private Checkbox adminBox = null;

	private Checkbox bossBox = null;

	private Checkbox clientBox = null;

	CheckboxGroup cbg = new CheckboxGroup();

	private Label label3 = null;

	private JLabel image = null;

	private JButton jButton = null;

	int value;

	private JLabel bossImage = null;

	private JLabel adminImage = null;

	private JComboBox jComboBox = null;

	private JLabel jLabel = null;

	private Label label4 = null;

	private JComboBox nameBox = null;


	/**
	 * This is the default constructor
	 */
	public Entry() {
		super();
		initialize();
		for (Restaurant r : Main.restaurants) {
			jComboBox.addItem(r);

		}
		jComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Restaurant res = (Restaurant) jComboBox.getSelectedItem();
				System.out.println("seçilen restoran:" + res.getAdress());
			}
		});
		
		for (User u : Main.users.sortSortableOnes(true)) {
			if (u instanceof Customer) {
				nameBox.addItem(u);
			}

		}
		
		nameBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				System.out.println("seçilen kişi:" +(Customer)nameBox.getSelectedItem());
			}
		});

	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {

		label4 = new Label();
		label4.setBounds(new Rectangle(397, 358, 114, 23));
		label4.setVisible(false);
		
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(195, 361, 126, 22));

		jLabel.setVisible(false);
		adminImage = new JLabel();
		adminImage.setBounds(new Rectangle(313, 124, 145, 137));
		adminImage.setIcon(new ImageIcon("ajdar.jpg"));

		bossImage = new JLabel();
		bossImage.setBounds(new Rectangle(41, 347, 146, 140));
		bossImage.setIcon(new ImageIcon("patron.jpg"));
		image = new JLabel();
		image.setBounds(new Rectangle(585, 341, 148, 142));
		image.setIcon(new ImageIcon("musteri.jpg"));
		label3 = new Label();
		label3.setBounds(new Rectangle(12, 37, 272, 68));
		label3.setFont(new Font("Dialog", Font.BOLD, 36));
		label3.setText("Kimsiniz?");
		this.setLayout(null);
		this.setSize(800, 600);
		this.setBackground(Color.white);
		this.setResizable(false);
		this.setTitle("Merhaba!");

		this.add(getAdminBox(), null);
		this.add(getBossBox(), null);
		this.add(getClientBox(), null);
		this.add(label3, null);
		this.add(image, null);
		this.add(getJButton(), null);
		this.setVisible(true);

		this.add(bossImage, null);
		this.add(adminImage, null);
		this.add(getJComboBox(), null);
		this.add(jLabel, null);
		this.add(label4, null);
		this.add(getNameBox(), null);
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
				// windowClosing()
			}
		});

	}

	/**
	 * This method initializes adminBox
	 * 
	 * @return java.awt.Checkbox
	 */
	private Checkbox getAdminBox() {
		if (adminBox == null) {
			adminBox = new Checkbox();
			adminBox.setBounds(new Rectangle(313, 98, 144, 19));
			adminBox.setLabel("Yönetici");
			adminBox.setCheckboxGroup(cbg);
			adminBox.setEnabled(true);

			adminBox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent arg0) {

					value = 1;
					label4.setVisible(false);
					nameBox.setVisible(false);
					jLabel.setVisible(false);
					jComboBox.setVisible(false);

				}
			});
		}
		return adminBox;
	}

	/**
	 * This method initializes bossBox
	 * 
	 * @return java.awt.Checkbox
	 */
	private Checkbox getBossBox() {
		if (bossBox == null) {
			bossBox = new Checkbox();
			bossBox.setBounds(new Rectangle(42, 320, 144, 18));
			bossBox.setLabel("Operatör");
			bossBox.setCheckboxGroup(cbg);
			bossBox.setEnabled(true);

			bossBox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent arg0) {
					jComboBox.setVisible(true);
					jLabel.setVisible(true);
					jLabel.setText("Lokantam:");
					value = 2;
					label4.setVisible(false);
					nameBox.setVisible(false);

				}
			});
		}
		return bossBox;
	}

	/**
	 * This method initializes clientBox
	 * 
	 * @return java.awt.Checkbox
	 */
	private Checkbox getClientBox() {
		if (clientBox == null) {
			clientBox = new Checkbox();
			clientBox.setBounds(new Rectangle(585, 314, 147, 22));
			clientBox.setLabel("Müşteri");
			clientBox.setCheckboxGroup(cbg);
			clientBox.setEnabled(true);

			clientBox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent arg0) {
					
					label4.setVisible(true);
					label4.setText("Adım - Soyadım:");
					nameBox.setVisible(true);
					jLabel.setVisible(false);
					jComboBox.setVisible(false);
					value = 3;

				}
			});
		}
		return clientBox;
	}

	public void shut_up() {
		this.setVisible(false);
	}

	public boolean choosingControl() {
		if ((value == 1) || (value == 2) || (value == 3)) {			
			return true;
		} else {
			shut_up();
			Warning w = new Warning();
			w.setVisible(true);
			return false;
		}
	}

	/**
	 * This method initializes jButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(637, 501, 134, 59));
			jButton.setText("Evet, gerçekten.");

			jButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (choosingControl()) {				
						if (value == 1) {
							shut_up();
							Admin ad = new Admin();
							ad.setVisible(true);
						} else if (value == 2) {
							doOpenBossWindow();
						} else if (value == 3) {
							doOpenCustomerWindow();
						}
					}
				}

					

				
			});
		}
		return jButton;
	}

	private void doOpenBossWindow() {
		if (jComboBox.getSelectedItem() != null) {
			shut_up();
			Boss b = new Boss((Restaurant) (jComboBox.getSelectedItem()));
			b.setVisible(true);
		}
	}
	private void doOpenCustomerWindow() {
		if (nameBox.getSelectedItem() != null) {
			System.out.println("Giden kişi: "+(Customer)(nameBox.getSelectedItem()));
			shut_up();
			Client c = new Client((Customer)(nameBox.getSelectedItem()));
		    c.setVisible(true);
		}
	}

	/**
	 * This method initializes jComboBox
	 * 
	 * @return javax.swing.JComboBox
	 */
	private JComboBox getJComboBox() {
		if (jComboBox == null) {
			jComboBox = new JComboBox();
			jComboBox.setBounds(new Rectangle(195, 387, 194, 30));
			jComboBox.setVisible(false);

		}
		return jComboBox;
	}

	/**
	 * This method initializes nameBox
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getNameBox() {
		if (nameBox == null) {
			nameBox = new JComboBox();
			nameBox.setBounds(new Rectangle(397, 387, 182, 29));
			nameBox.setVisible(false);
		}
		return nameBox;
	}

} // @jve:decl-index=0:visual-constraint="10,9"
