package proje.ui;

import java.awt.Frame;
import java.awt.Button;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import proje.restaurant.Restaurant;
import proje.user.Customer;

public class Common extends Frame {

	private static final long serialVersionUID = 1L;

	private Button previous = null;

	private Button firstbutton = null;

	private Button exit = null;

	private String object;
	
	private Restaurant res;
	private Customer cus;
	

	/**
	 * This is the default constructor
	 */
	public Common(String ob, Restaurant r) {
		super();
		initialize();
		this.object = ob;
		this.res=r;
		
	}
	public Common(String ob, Customer c) {
		super();
		initialize();
		this.object = ob;
		this.cus=c;		
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setLayout(null);
		this.setSize(465, 226);
		this.setResizable(false);
		this.setTitle("Yolunu belirle...");

		this.add(getPrevious(), null);
		this.add(getFirstbutton(), null);
		this.add(getExit(), null);

		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			}
		});
	}

	/**
	 * This method initializes previous
	 * 
	 * @return java.awt.Button
	 */
	private Button getPrevious() {
		if (previous == null) {
			previous = new Button();
			previous.setBounds(new Rectangle(28, 49, 115, 58));
			previous.setLabel("Geri git");

			previous.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					shut_up();
					if (object == "Admin") {
						Admin ad = new Admin();
						ad.setVisible(true);
					} else if (object == "Boss") {
						Boss bo = new Boss(res);
						bo.setVisible(true);
					} else if (object == "Client") {
						Client cli = new Client(cus);
						cli.setVisible(true);
					}

				}
			});
		}
		return previous;
	}

	/**
	 * This method initializes firstbutton
	 * 
	 * @return java.awt.Button
	 */
	private Button getFirstbutton() {
		if (firstbutton == null) {
			firstbutton = new Button();
			firstbutton.setBounds(new Rectangle(152, 151, 145, 52));
			firstbutton.setLabel("Rol değiştir");

			firstbutton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					shut_up();
					Entry en = new Entry();
					en.setVisible(true);
				}
			});
		}
		return firstbutton;
	}

	/**
	 * This method initializes exit
	 * 
	 * @return java.awt.Button
	 */
	private Button getExit() {
		if (exit == null) {
			exit = new Button();
			exit.setBounds(new Rectangle(316, 45, 109, 60));
			exit.setLabel("Çek git :)");

			exit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
		}
		return exit;
	}

	public void shut_up() {
		this.setVisible(false);
	}

} // @jve:decl-index=0:visual-constraint="0,25"
