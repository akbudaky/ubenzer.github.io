package proje.ui;

import java.awt.Frame;
import javax.swing.JTabbedPane;
import java.awt.Rectangle;
import javax.swing.JPanel;
import java.awt.GridBagLayout;

import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JScrollPane;
import java.awt.Label;
import java.awt.TextField;
import java.awt.TextArea;
import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import proje.restaurant.Order;
import proje.restaurant.Restaurant;
import proje.restaurant.Yemek;
import proje.util.CONSTANT;
import proje.util.CustomerOfARestaurant;
import proje.util.SortableList;

import java.awt.List;
import java.text.DateFormat;
import java.util.Vector;

import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Font;

public class Boss extends Frame { 

	private static final long serialVersionUID = 1L;

	DefaultListModel orderModel = new DefaultListModel();

	DefaultListModel foodlistModel = new DefaultListModel();

	DefaultListModel addListModel = new DefaultListModel();

	DefaultListModel listOfMenu = new DefaultListModel();

	private JTabbedPane jTabbedPane = null;

	private JPanel sortPanel = null;

	private JComboBox orderBox = null;

	private JList orderList = null;

	private JScrollPane jScrollPane = null;

	private Label label = null;

	private Label label1 = null;

	private Label label2 = null;

	private Label label3 = null;

	private TextField nameField = null;

	private TextField surnameField = null;

	private TextArea adresArea = null;

	private Label label4 = null;

	private Label label5 = null;

	private TextField textField1 = null;

	private Label label6 = null;

	private TextField textField2 = null;

	private Label label7 = null;

	private TextArea foodmenuArea = null;

	private Label label9 = null;

	private TextField priceField = null;

	private Label label10 = null;

	private TextArea commentArea = null;

	private Button rolButton = null;

	private JPanel icerikPaneli = null;

	private Label label13 = null;

	private Button ok = null;

	private Button button2 = null;

	private Label label18 = null;

	private Label label19 = null;

	private Button newPerson = null;

	private Button addButton = null;

	private JList menuList = null;

	private JScrollPane menuPane = null;

	private JList foodList1 = null;

	private JScrollPane foodListPane = null;

	private JList addList = null;

	private JScrollPane addFoodPane1 = null;

	private JLabel jLabel4 = null;

	private JLabel jLabel5 = null;

	private TextField menuName = null;

	private TextField menuPr = null;

	private Label label20 = null;

	private Label label21 = null;

	private TextField foodName = null;

	private TextField foodPrice = null;

	private Restaurant r;

	private proje.restaurant.Menu mm;

	private Button newMenu = null;

	private Button newFood = null;

	private proje.restaurant.Yemek y;

	private boolean newMenuVariable = false;
	private boolean editMenuVariable = false;
	private boolean editYemekVariable = false; 
	
	private JButton deleteFood = null;

	Yemek aktifSeciliYemek = null;
	Yemek aktifSeciliEklenecekYemek = null;
	Order aktif = null;
	
	// @jve:decl-index=0:

	private JButton deleteMenu = null;

	private JButton outOfMenu = null;

	private Label labelHiz = null;

	private Label label8 = null;

	private Label label11 = null;

	private Label label111 = null;

	private Label dataHiz = null;

	private Label dataLezzet = null;

	private Label dataFiyat = null;

	private JPanel genelBilgilerPanel = null;

	private Label label12 = null;

	private Label label14 = null;

	private Label label141 = null;

	private TextField textRestoranAdi = null;

	private TextField textAdres = null;

	private JButton buttonRestGuncelle = null;

	private JButton rolDegistir = null;

	private JPanel musteriPanel = null;

	private List list = null;

	private Label label142 = null;

	private TextField dataPuan = null;

	private Button btnSiparisiYolaCikar = null;

	private Button btnSiparisTeslimEdildi = null;

	/**
	 * This is the default constructor
	 */
	public Boss(Restaurant r) {
		super();
		this.r = r;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setLayout(null);
		this.setSize(800, 600);
		this.setResizable(false);
		this.setTitle("Restoran Operatörü: " + r.getOperatorName());
		this.add(getJTabbedPane(), null);
		
		textRestoranAdi.setText(r.toString());
		textAdres.setText(r.getAdress());
		dataPuan.setText(r.getOrtPuan() + " / 3.00");
		
		/* Müşterileri sıralı raporlama algoritması */
		SortableList<CustomerOfARestaurant> cus = r.getAllCustomersOfRestaurant();
		for (CustomerOfARestaurant c: cus) {
			list.add(c.c.getFirstName() + " " + c.c.getLastName() + " (Bu rest. " + c.number + " alışveriş)");
		}		
		
		normalProcess();	
		filler();
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
				// windowClosing()
			}
		});

	}

	public void shut_up() {
		this.setVisible(false);
	}

	private void fillMenus() {
		for (proje.restaurant.Menu m : r.getMenuler()) {
			listOfMenu.addElement(m);
		}
	}

	/**
	 * This method initializes jTabbedPane
	 * 
	 * @return javax.swing.JTabbedPane
	 */
	private JTabbedPane getJTabbedPane() {
		if (jTabbedPane == null) {
			jTabbedPane = new JTabbedPane();
			jTabbedPane.setBounds(new Rectangle(5, 30, 791, 561));
			jTabbedPane.addTab("Genel Bilgiler", null, getGenelBilgilerPanel(), null);
			jTabbedPane.addTab("Siparişler", null, getSortPanel(), null);
			jTabbedPane.addTab("Menüler & Yemekler", null,
					getIcerikPaneli(), null);

			jTabbedPane.addTab("Müşteriler", null, getMusteriPanel(), null);
			
		}
		return jTabbedPane;
	}

	/**
	 * This method initializes sortPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getSortPanel() {
		if (sortPanel == null) {
			dataFiyat = new Label();
			dataFiyat.setBounds(new Rectangle(678, 347, 87, 28));
			dataFiyat.setText("");
			dataLezzet = new Label();
			dataLezzet.setBounds(new Rectangle(676, 314, 85, 30));
			dataLezzet.setText("");
			dataHiz = new Label();
			dataHiz.setBounds(new Rectangle(676, 279, 85, 26));
			dataHiz.setText("");
			label111 = new Label();
			label111.setBounds(new Rectangle(560, 345, 102, 27));
			label111.setText("Fiyat:");
			label11 = new Label();
			label11.setBounds(new Rectangle(558, 313, 105, 26));
			label11.setText("Lezzet:");
			label8 = new Label();
			label8.setBounds(new Rectangle(557, 278, 102, 28));
			label8.setText("Hız:");
			labelHiz = new Label();
			labelHiz.setBounds(new Rectangle(557, 241, 206, 27));
			labelHiz.setText("Bu siparişin puanlaması:");
			label10 = new Label();
			label10.setBounds(new Rectangle(553, 19, 207, 24));
			label10.setText("Şöyle demiş:");
			label9 = new Label();
			label9.setBounds(new Rectangle(239, 476, 90, 22));
			label9.setText("ToplamTutar:");
			label7 = new Label();
			label7.setBounds(new Rectangle(238, 300, 94, 25));
			label7.setText("Detayı:");
			label6 = new Label();
			label6.setBounds(new Rectangle(242, 266, 91, 23));
			label6.setText("Teslim Tarihi:");
			label5 = new Label();
			label5.setBounds(new Rectangle(241, 236, 90, 21));
			label5.setText("Verilme Tarihi:");
			label4 = new Label();
			label4.setBounds(new Rectangle(240, 208, 92, 19));
			label4.setText("Siparişin:");
			label3 = new Label();
			label3.setBounds(new Rectangle(239, 108, 94, 20));
			label3.setText("Adresi:");
			label2 = new Label();
			label2.setBounds(new Rectangle(241, 77, 92, 21));
			label2.setText("Soyadı:");
			label1 = new Label();
			label1.setBounds(new Rectangle(242, 48, 93, 21));
			label1.setText("Adı:");
			label = new Label();
			label.setBounds(new Rectangle(240, 18, 109, 22));
			label.setText("Siparişi verenin:");
			sortPanel = new JPanel();
			sortPanel.setLayout(null);
			sortPanel.add(getOrderBox(), null);
			sortPanel.add(getJScrollPane(), null);
			sortPanel.add(label, null);
			sortPanel.add(label1, null);
			sortPanel.add(label2, null);
			sortPanel.add(label3, null);
			sortPanel.add(getNameField(), null);
			sortPanel.add(getSurnameField(), null);
			sortPanel.add(getAdresArea(), null);
			sortPanel.add(label4, null);
			sortPanel.add(label5, null);
			sortPanel.add(getTextField1(), null);
			sortPanel.add(label6, null);
			sortPanel.add(getTextField2(), null);
			sortPanel.add(label7, null);
			sortPanel.add(getFoodmenuArea(), null);
			sortPanel.add(label9, null);
			sortPanel.add(getPriceField(), null);
			sortPanel.add(label10, null);
			sortPanel.add(getCommentArea(), null);
			sortPanel.add(getRolButton(), null);
			sortPanel.add(labelHiz, null);
			sortPanel.add(label8, null);
			sortPanel.add(label11, null);
			sortPanel.add(label111, null);
			sortPanel.add(dataHiz, null);
			sortPanel.add(dataLezzet, null);
			sortPanel.add(dataFiyat, null);
			sortPanel.add(getBtnSiparisiYolaCikar(), null);
			sortPanel.add(getBtnSiparisTeslimEdildi(), null);
		}
		return sortPanel;
	}

	/**
	 * This method initializes orderBox
	 * 
	 * @return javax.swing.JComboBox
	 */
	private JComboBox getOrderBox() {
		if (orderBox == null) {
			orderBox = new JComboBox();
			orderBox.setBounds(new Rectangle(16, 16, 209, 28));

			orderBox.addItem("Tüm Siparişler");
			orderBox.addItem("Onay Bekleyenler");
			orderBox.addItem("Yolda Olanlar");
			orderBox.addItem("Yerine Ulaşmış Siparişler");

			orderBox.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					filler();
				}
			});
		}
		return orderBox;
	}
	
	private void filler() {
		nameField.setText("");
		surnameField.setText("");
		adresArea.setText("");
		textField1.setText("");
		textField2.setText("");
		foodmenuArea.setText("");
		priceField.setText("");
		commentArea.setText("");
		dataHiz.setText("");
		dataLezzet.setText("");
		dataFiyat.setText("");
		btnSiparisiYolaCikar.setEnabled(false);
		btnSiparisTeslimEdildi.setEnabled(false);
		
		orderModel.clear();
		for(Order o: r.getOrders().sortSortableOnes(true)) {
			String secili = (String)orderBox.getSelectedItem();
			int flag = -1;
			if (secili.equals("Onay Bekleyenler")) flag = CONSTANT.NEWORDER;
			if (secili.equals("Yolda Olanlar")) flag = CONSTANT.ORDERINPROGRESS;
			if (secili.equals("Yerine Ulaşmış Siparişler")) flag = CONSTANT.DELIVEREDORDER;
			
			if (flag == -1 || o.getOrderStatus() == flag) {
				orderModel.addElement(o);
			}
		}
	}
	/**
	 * This method initializes orderList
	 * 
	 * @return javax.swing.JList
	 */
	private JList getOrderList() {
		if (orderList == null) {
			orderList = new JList(orderModel);

			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {
					boolean adjust = listSelectionEvent.getValueIsAdjusting();
					if (!adjust) {
						JList list = (JList) listSelectionEvent.getSource();
						Object selectionValue = list.getSelectedValue();
						if (selectionValue == null) return;
						Order o = (Order)selectionValue;
						aktif = o;
						
						nameField.setText(o.getCustomer().getFirstName());
						surnameField.setText(o.getCustomer().getLastName());
						adresArea.setText(o.getCustomer().getAdress());
						
						textField1.setText(DateFormat.getInstance().format(o.getOrderTime()));
						textField2.setText((o.getCompleteTime() == null ? "(henüz yerine ulaşmadı" : DateFormat.getInstance().format(o.getCompleteTime())));
						
						foodmenuArea.setText("");						
						for(Object obj: o.getOrderDetails()) {
							if (obj instanceof proje.restaurant.Menu) {
								foodmenuArea.setText(foodmenuArea.getText().concat("**** Menü: " + ((proje.restaurant.Menu)obj).getName() + " (" + ((proje.restaurant.Menu)obj).getPrice() + " TL)"));
							}
							if (obj instanceof Yemek) {
								foodmenuArea.setText(foodmenuArea.getText().concat("**** Yemek: " + ((proje.restaurant.Yemek)obj).getAd() + " (" + ((proje.restaurant.Yemek)obj).getPrice() + " TL)"));
							}
						}
						priceField.setText(o.getPrice() + "TL (müşt.indrm.dahil)");
						commentArea.setText(o.getComment() == null ? "(yok)" : o.getComment());
						dataHiz.setText(o.getHizPuan() < 0 ? "(oy vermedi)" : o.getHizPuan() + "");
						dataLezzet.setText(o.getLezzetPuan() < 0 ? "(oy vermedi)" : o.getLezzetPuan() + "");
						dataFiyat.setText(o.getFiyatPuan() < 0 ? "(oy vermedi)" : o.getFiyatPuan() + "");
					
						if(o.isOrderNew()) {
							btnSiparisiYolaCikar.setEnabled(true);
							btnSiparisTeslimEdildi.setEnabled(true);
						}
						if (o.isOrderInProgress()) {
							btnSiparisiYolaCikar.setEnabled(false);
							btnSiparisTeslimEdildi.setEnabled(true);
						}
						if (o.isOrderDelivered()) {
							btnSiparisiYolaCikar.setEnabled(false);
							btnSiparisTeslimEdildi.setEnabled(false);
						}
					
					}
				}
			};
			orderList.addListSelectionListener(listSelectionListener);

		}
		return orderList;
	}

	/**
	 * This method initializes jScrollPane
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane(orderList);
			jScrollPane.setBounds(new Rectangle(18, 62, 204, 442));
			jScrollPane.setViewportView(getOrderList());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes nameField
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getNameField() {
		if (nameField == null) {
			nameField = new TextField();
			nameField.setBounds(new Rectangle(344, 48, 186, 21));
			nameField.setEditable(false);
		}
		return nameField;
	}

	/**
	 * This method initializes surnameField
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getSurnameField() {
		if (surnameField == null) {
			surnameField = new TextField();
			surnameField.setBounds(new Rectangle(343, 75, 188, 24));
			surnameField.setEditable(false);
		}
		return surnameField;
	}

	/**
	 * This method initializes adresArea
	 * 
	 * @return java.awt.TextArea
	 */
	private TextArea getAdresArea() {
		if (adresArea == null) {
			adresArea = new TextArea();
			adresArea.setBounds(new Rectangle(344, 109, 187, 95));
			adresArea.setEditable(false);
		}
		return adresArea;
	}

	/**
	 * This method initializes textField1
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getTextField1() {
		if (textField1 == null) {
			textField1 = new TextField();
			textField1.setBounds(new Rectangle(344, 235, 182, 24));
			textField1.setEditable(false);
		}
		return textField1;
	}

	/**
	 * This method initializes textField2
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getTextField2() {
		if (textField2 == null) {
			textField2 = new TextField();
			textField2.setBounds(new Rectangle(344, 266, 182, 24));
			textField2.setEditable(false);
		}
		return textField2;
	}

	/**
	 * This method initializes foodmenuArea
	 * 
	 * @return java.awt.TextArea
	 */
	private TextArea getFoodmenuArea() {
		if (foodmenuArea == null) {
			foodmenuArea = new TextArea();
			foodmenuArea.setBounds(new Rectangle(344, 300, 181, 170));
			foodmenuArea.setColumns(50);
			foodmenuArea.setEditable(false);
		}
		return foodmenuArea;
	}

	/**
	 * This method initializes priceField
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getPriceField() {
		if (priceField == null) {
			priceField = new TextField();
			priceField.setBounds(new Rectangle(343, 474, 180, 25));
			priceField.setEditable(false);
		}
		return priceField;
	}

	/**
	 * This method initializes commentArea
	 * 
	 * @return java.awt.TextArea
	 */
	private TextArea getCommentArea() {
		if (commentArea == null) {
			commentArea = new TextArea();
			commentArea.setBounds(new Rectangle(554, 48, 208, 183));
			commentArea.setEditable(false);
			commentArea.setColumns(50);
		}
		return commentArea;
	}

	/**
	 * This method initializes rolButton
	 * 
	 * @return java.awt.Button
	 */
	private Button getRolButton() {
		if (rolButton == null) {
			rolButton = new Button();
			rolButton.setBounds(new Rectangle(563, 473, 200, 47));
			rolButton.setLabel("Rol Değiştir");
			rolButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					shut_up();
					Common c = new Common("Boss", r);
					c.setVisible(true);
				}
			});
		}
		return rolButton;
	}

	/**
	 * This method initializes icerikPaneli
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getIcerikPaneli() {
		if (icerikPaneli == null) {
			label21 = new Label();
			label21.setBounds(new Rectangle(345, 407, 99, 21));
			label21.setText("Fiyatı:");
			label20 = new Label();
			label20.setBounds(new Rectangle(343, 378, 100, 20));
			label20.setText("Yemek adı:");
			jLabel5 = new JLabel();
			jLabel5.setBounds(new Rectangle(9, 406, 92, 21));
			jLabel5.setText("Fiyatı:");
			jLabel4 = new JLabel();
			jLabel4.setBounds(new Rectangle(9, 380, 93, 21));
			jLabel4.setText("Menü adı:");
			label19 = new Label();
			label19.setBounds(new Rectangle(556, 13, 219, 22));
			label19.setText("Seçilen menünün yemekleri");
			label18 = new Label();
			label18.setBounds(new Rectangle(13, 11, 121, 20));
			label18.setText("Menü Listesi");
			label13 = new Label();
			label13.setBounds(new Rectangle(341, 15, 154, 19));
			label13.setText("Restoran Yemekleri:");
			icerikPaneli = new JPanel();
			icerikPaneli.setLayout(null);
			icerikPaneli.add(label13, null);
			icerikPaneli.add(getOk(), null);
			icerikPaneli.add(getButton2(), null);
			icerikPaneli.add(label18, null);
			icerikPaneli.add(label19, null);
			icerikPaneli.add(getNewPerson(), null);
			icerikPaneli.add(getAddButton(), null);
			icerikPaneli.add(getMenuPane(), null);
			icerikPaneli.add(getFoodListPane(), null);
			icerikPaneli.add(getAddFoodPane1(), null);
			icerikPaneli.add(jLabel4, null);
			icerikPaneli.add(jLabel5, null);
			icerikPaneli.add(getMenuName(), null);
			icerikPaneli.add(getMenuPr(), null);
			icerikPaneli.add(label20, null);
			icerikPaneli.add(label21, null);
			icerikPaneli.add(getFoodName(), null);
			icerikPaneli.add(getFoodPrice(), null);
			icerikPaneli.add(getNewMenu(), null);
			icerikPaneli.add(getNewFood(), null);
			icerikPaneli.add(getDeleteFood(), null);
			icerikPaneli.add(getDeleteMenu(), null);
			icerikPaneli.add(getOutOfMenu(), null);
		}
		return icerikPaneli;
	}

	/**
	 * This method initializes ok
	 * 
	 * @return java.awt.Button
	 */
	private Button getOk() {
		if (ok == null) {
			ok = new Button();
			ok.setBounds(new Rectangle(531, 439, 81, 28));
			ok.setLabel("Ok!");

			ok.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					if (editYemekVariable) {
						y.setAd(foodName.getText());
						String p = foodPrice.getText();
						double pr;
						try {
							pr = Double.parseDouble(p);
						} catch (NumberFormatException e1) {
							pr = 0.01;
						}
						y.setPrice(pr);
					} else {
						String p = foodPrice.getText();
						double pr;
						try {
							pr = Double.parseDouble(p);
						} catch (NumberFormatException e1) {
							pr = 0.01;
						}
						Yemek y = new Yemek(foodName.getText(), pr);
						r.addYemek(y);
					}
					normalProcess();
				}
			});

		}
		return ok;
	}

	/**
	 * This method initializes button2
	 * 
	 * @return java.awt.Button
	 */
	private Button getButton2() {
		if (button2 == null) {
			button2 = new Button();
			button2.setBounds(new Rectangle(194, 440, 81, 26));
			button2.setLabel("Ok!");
			// bu buton güncelle veya ekle arasında gidecek

			button2.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {
					
					if (newMenuVariable == true) {
						/* Yeni menü eklenecek */

						String p = menuPr.getText();
						double pr;
						try {
							pr = Double.parseDouble(p);
						} catch (NumberFormatException e1) {
							pr = 0.01;
						}

						Vector<Yemek> eklenecekYemekListesi = new Vector<Yemek>();
						int i = 0;
						for(i=0;i<addListModel.size();i++) {
							eklenecekYemekListesi.add((Yemek)(addListModel.elementAt(i)));
						}
						
						proje.restaurant.Menu m = new proje.restaurant.Menu(
								menuName.getText(), pr, eklenecekYemekListesi);
						r.addMenu(m);
						
					} else {
						mm.setName(menuName.getText());
						String price = menuPr.getText();
						double pr;
						try {
							pr = Double.parseDouble(price);
						} catch (NumberFormatException e1) {
							pr = 0.01;
						}
						mm.setPrice(pr);
						listOfMenu.clear();
						fillMenus();
					}
					normalProcess();
				}
			});

		}
		return button2;
	}

	/**
	 * This method initializes menuList
	 * 
	 * @return javax.swing.JList
	 */
	private JList getMenuList() {
		if (menuList == null) {
			menuList = new JList(listOfMenu);
			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {

					boolean adjust2 = listSelectionEvent.getValueIsAdjusting();

					if (!adjust2) {						
						JList list = (JList) listSelectionEvent.getSource();
						Object selectionValue = list.getSelectedValue();
						if (selectionValue == null)
							return;
						
						editMenuProcess();
						
						mm = (proje.restaurant.Menu) selectionValue;
						addListModel.clear();
						fillAddList();

						menuName.setText(mm.getName());
						String p = mm.getPrice() + "";
						menuPr.setText(p);

					}
				}

			};
			menuList.addListSelectionListener(listSelectionListener);
		}
		return menuList;
	}

	private void fillAddList() {
		for (proje.restaurant.Yemek y : mm.getMenuYemekleri()) {
			addListModel.addElement(y);
		}
	}

	private void fillFoodList() {
		for (proje.restaurant.Yemek y : r.getYemekler()) {
			foodlistModel.addElement(y);
		}
	}

	/**
	 * This method initializes foodList1
	 * 
	 * @return javax.swing.JList
	 */
	private JList getFoodList1() {
		if (foodList1 == null) {
			foodList1 = new JList(foodlistModel);

			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {

					boolean adjust = listSelectionEvent.getValueIsAdjusting();
					
					if (!adjust) {						
						JList list = (JList) listSelectionEvent.getSource();
						Object selectionValue = list.getSelectedValue();
						if (selectionValue == null) return;						
										
						if(newMenuVariable || editMenuVariable) {
							aktifSeciliYemek = (Yemek) selectionValue;
						} else {
						
						editFoodProcess();						
						y = (Yemek) selectionValue;

						foodName.setText(y.getAd());
						String pr = y.getPrice() + "";
						foodPrice.setText(pr);

						}

					}
				}
			};
			foodList1.addListSelectionListener(listSelectionListener);

		}
		return foodList1;
	}

	/**
	 * This method initializes newPerson
	 * 
	 * @return java.awt.Button
	 */
	private Button getNewPerson() {
		if (newPerson == null) {
			newPerson = new Button();
			newPerson.setBounds(new Rectangle(595, 476, 187, 51));
			newPerson.setLabel("Rol değiştir");

			newPerson.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					shut_up();
					Common c = new Common("Boss", r);
					c.setVisible(true);
				}
			});

		}
		return newPerson;
	}

	/**
	 * This method initializes addButton
	 * 
	 * @return java.awt.Button
	 */
	private Button getAddButton() {
		if (addButton == null) {
			addButton = new Button();
			addButton.setBounds(new Rectangle(541, 82, 80, 32));

			addButton.setLabel("Ekle ->");
			addButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (aktifSeciliYemek != null) {
						addListModel.addElement(aktifSeciliYemek);
						if(editMenuVariable) {
							mm.addYemek(aktifSeciliYemek);
						}
					}					
				}
			});

		}
		return addButton;
	}

	/**
	 * This method initializes menuPane
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getMenuPane() {
		if (menuPane == null) {
			menuPane = new JScrollPane(menuList);
			menuPane.setBounds(new Rectangle(10, 44, 195, 324));
			menuPane.setViewportView(getMenuList());
		}
		return menuPane;
	}

	/**
	 * This method initializes foodListPane
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getFoodListPane() {
		if (foodListPane == null) {
			foodListPane = new JScrollPane(foodList1);
			foodListPane.setBounds(new Rectangle(342, 46, 197, 321));
			foodListPane.setViewportView(getFoodList1());
		}
		return foodListPane;
	}

	/**
	 * This method initializes addL�st
	 * 
	 * @return javax.swing.JList
	 */
	private JList getAddList() {
		if (addList == null) {
			addList = new JList(addListModel);

			ListSelectionListener listSelectionListener = new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent listSelectionEvent) {
					boolean adjust = listSelectionEvent.getValueIsAdjusting();
					if (!adjust) {
						
						JList list = (JList) listSelectionEvent.getSource();
						Object selectionValue = list.getSelectedValue();
						if (selectionValue == null) return;

						if(newMenuVariable || editMenuVariable) {
							aktifSeciliEklenecekYemek = (Yemek) selectionValue;
						
						}
						
						// Yemek yem = (Yemek) selectionValue;
					}
				}
			};
			addList.addListSelectionListener(listSelectionListener);

		}
		return addList;
	}

	/**
	 * This method initializes addFoodPane1
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getAddFoodPane1() {
		if (addFoodPane1 == null) {
			addFoodPane1 = new JScrollPane(addList);
			addFoodPane1.setBounds(new Rectangle(626, 48, 155, 123));
			addFoodPane1.setViewportView(getAddList());
		}
		return addFoodPane1;
	}

	/**
	 * This method initializes menuName
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getMenuName() {
		if (menuName == null) {
			menuName = new TextField();
			menuName.setBounds(new Rectangle(112, 381, 164, 21));
		}
		return menuName;
	}

	/**
	 * This method initializes menuPr
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getMenuPr() {
		if (menuPr == null) {
			menuPr = new TextField();
			menuPr.setBounds(new Rectangle(112, 408, 163, 20));
		}
		return menuPr;
	}

	/**
	 * This method initializes foodName
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getFoodName() {
		if (foodName == null) {
			foodName = new TextField();
			foodName.setBounds(new Rectangle(449, 379, 165, 19));
		}
		return foodName;
	}

	/**
	 * This method initializes foodPrice
	 * 
	 * @return java.awt.TextField
	 */
	private TextField getFoodPrice() {
		if (foodPrice == null) {
			foodPrice = new TextField();
			foodPrice.setBounds(new Rectangle(450, 407, 164, 21));
		}
		return foodPrice;
	}

	/**
	 * This method initializes newMenu
	 * 
	 * @return java.awt.Button
	 */
	private Button getNewMenu() {
		if (newMenu == null) {
			newMenu = new Button();
			newMenu.setBounds(new Rectangle(13, 483, 77, 40));
			newMenu.setLabel("Yeni Menü");

			newMenu.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {					
					newMenuProcess();
				}
			});

		}
		return newMenu;
	}

	private void newMenuProcess() {
		/* Görünmez yap */
		newMenuVariable = true;
		editMenuVariable = false;
		editYemekVariable = false;
		
		/* Menü */
		jLabel4.setVisible(true);
		jLabel5.setVisible(true);
		menuName.setVisible(true);
		menuPr.setVisible(true);
		menuName.setText("");
		menuPr.setText("");
		button2.setVisible(true);
		button2.setLabel("Ekle");
		deleteMenu.setVisible(false);
		
		/* Yemek */
		label20.setVisible(false);
		label21.setVisible(false);		
		foodName.setVisible(false);
		foodPrice.setVisible(false);		
		ok.setVisible(false);
		deleteFood.setVisible(false);

		/* Öbürleri */		
		addButton.setVisible(true);
		outOfMenu.setVisible(true);
		addFoodPane1.setVisible(true);
		addListModel.clear();
		label19.setVisible(true);
		label19.setText("Yeni menüye eklenen yemekler listesi:");
		
				
	}

	private void normalProcess() {
		listOfMenu.clear();
		addListModel.clear();
		foodlistModel.clear();
		
		fillMenus();
		fillFoodList();	
				
		newMenuVariable = false;
		editMenuVariable = false;
		editYemekVariable = false;	
		
		/* Menü */
		jLabel4.setVisible(false);
		jLabel5.setVisible(false);
		menuName.setVisible(false);
		menuPr.setVisible(false);
		button2.setVisible(false);
		deleteMenu.setVisible(false);
		
		/* Yemek */
		label20.setVisible(false);
		label21.setVisible(false);		
		foodName.setVisible(false);
		foodPrice.setVisible(false);		
		ok.setVisible(false);
		deleteFood.setVisible(false);

		/* Öbürleri */		
		addButton.setVisible(false);
		outOfMenu.setVisible(false);
		addFoodPane1.setVisible(false);
		label19.setVisible(false);
		
		
	}

	/**
	 * This method initializes newFood
	 * 
	 * @return java.awt.Button
	 */
	private Button getNewFood() {
		if (newFood == null) {
			newFood = new Button();
			newFood.setBounds(new Rectangle(356, 482, 81, 42));
			newFood.setLabel("Yeni Yemek");
			newFood.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					newFoodProcess();
				}
			});

		}
		return newFood;
	}

	private void editMenuProcess() {
		newMenuVariable = false;
		editMenuVariable = true;
		editYemekVariable = false;
		
		/* Menü */
		jLabel4.setVisible(true);
		jLabel5.setVisible(true);
		menuName.setVisible(true);
		menuPr.setVisible(true);
		button2.setVisible(true);
		button2.setLabel("Düzenle");
		deleteMenu.setVisible(true);
		
		/* Yemek */
		label20.setVisible(false);
		label21.setVisible(false);		
		foodName.setVisible(false);
		foodPrice.setVisible(false);		
		ok.setVisible(false);
		deleteFood.setVisible(false);

		/* Öbürleri */		
		addButton.setVisible(true);
		outOfMenu.setVisible(true);
		addFoodPane1.setVisible(true);
		addListModel.clear();
		label19.setVisible(true);
		label19.setText("Düzenlenen menüye eklenen yemekler listesi:");


	}
	private void editFoodProcess() {
		newMenuVariable = false;
		editMenuVariable = false;
		editYemekVariable = true;

		/* Menü */
		jLabel4.setVisible(false);
		jLabel5.setVisible(false);
		menuName.setVisible(false);
		menuPr.setVisible(false);
		button2.setVisible(false);
		deleteMenu.setVisible(false);
		
		/* Yemek */
		label20.setVisible(true);
		label21.setVisible(true);		
		foodName.setVisible(true);
		foodPrice.setVisible(true);
		ok.setVisible(true);
		ok.setLabel("Düzenle");
		deleteFood.setVisible(true);

		/* Öbürleri */		
		addButton.setVisible(false);
		outOfMenu.setVisible(false);
		addFoodPane1.setVisible(false);
		label19.setVisible(false);
	}
	
	private void newFoodProcess() {
		newMenuVariable = false;
		editMenuVariable = false;
		editYemekVariable = false;

		/* Menü */
		jLabel4.setVisible(false);
		jLabel5.setVisible(false);
		menuName.setVisible(false);
		menuPr.setVisible(false);
		button2.setVisible(false);
		deleteMenu.setVisible(false);
		
		/* Yemek */
		label20.setVisible(true);
		label21.setVisible(true);		
		foodName.setVisible(true);
		foodPrice.setVisible(true);
		foodName.setText("");
		foodPrice.setText("");
		ok.setVisible(true);
		ok.setLabel("Ekle");
		deleteFood.setVisible(false);

		/* Öbürleri */		
		addButton.setVisible(false);
		outOfMenu.setVisible(false);
		addFoodPane1.setVisible(false);
		label19.setVisible(false);

	}

	/**
	 * This method initializes deleteFood
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getDeleteFood() {
		if (deleteFood == null) {
			deleteFood = new JButton();
			deleteFood.setBounds(new Rectangle(434, 436, 83, 31));
			deleteFood.setText("Sil!");

			deleteFood.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					r.deleteYemek(y);
					normalProcess();				
				}
			});
		}
		return deleteFood;
	}

	/**
	 * This method initializes deleteMenu
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getDeleteMenu() {
		if (deleteMenu == null) {
			deleteMenu = new JButton();
			deleteMenu.setBounds(new Rectangle(111, 439, 80, 25));
			deleteMenu.setText("Sil!");

			deleteMenu.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if (mm != null) r.deleteMenu(mm);
					normalProcess();
				}
			});
		}
		return deleteMenu;
	}

	/**
	 * This method initializes outOfMenu
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getOutOfMenu() {
		if (outOfMenu == null) {
			outOfMenu = new JButton();
			outOfMenu.setBounds(new Rectangle(541, 117, 82, 34));
			outOfMenu.setText("<- Çıkar");

			outOfMenu.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (aktifSeciliEklenecekYemek != null) {
						addListModel.removeElement(aktifSeciliEklenecekYemek);
						if(editMenuVariable) {
							mm.removeYemek(aktifSeciliEklenecekYemek);
						}
					}
				}
			});

		}
		return outOfMenu;
	}


	/**
	 * This method initializes genelBilgilerPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getGenelBilgilerPanel() {
		if (genelBilgilerPanel == null) {
			label142 = new Label();
			label142.setBounds(new Rectangle(66, 157, 170, 51));
			label142.setText("Ort. puan:");
			label142.setFont(new Font("Dialog", Font.PLAIN, 36));
			label141 = new Label();
			label141.setBounds(new Rectangle(32, 212, 208, 44));
			label141.setText("Tam Adresi:");
			label141.setFont(new Font("Dialog", Font.PLAIN, 36));
			label14 = new Label();
			label14.setBounds(new Rectangle(6, 105, 228, 50));
			label14.setFont(new Font("Dialog", Font.PLAIN, 36));
			label14.setText("Restoran Adı:");
			label12 = new Label();
			label12.setBounds(new Rectangle(14, 17, 516, 28));
			label12.setText("Sevgili yönetici dilerseniz restoranınızın bilgilerini güncelleyebilirsiniz.");
			genelBilgilerPanel = new JPanel();
			genelBilgilerPanel.setLayout(null);
			genelBilgilerPanel.add(label12, null);
			genelBilgilerPanel.add(label14, null);
			genelBilgilerPanel.add(label141, null);
			genelBilgilerPanel.add(getTextRestoranAdi(), null);
			genelBilgilerPanel.add(getTextAdres(), null);
			genelBilgilerPanel.add(getButtonRestGuncelle(), null);
			genelBilgilerPanel.add(getRolDegistir(), null);
			genelBilgilerPanel.add(label142, null);
			genelBilgilerPanel.add(getDataPuan(), null);
		}
		return genelBilgilerPanel;
	}

	/**
	 * This method initializes textRestoranAdi	
	 * 	
	 * @return java.awt.TextField	
	 */
	private TextField getTextRestoranAdi() {
		if (textRestoranAdi == null) {
			textRestoranAdi = new TextField();
			textRestoranAdi.setBounds(new Rectangle(241, 105, 529, 52));
			textRestoranAdi.setFont(new Font("Dialog", Font.PLAIN, 36));
		}
		return textRestoranAdi;
	}

	/**
	 * This method initializes textAdres	
	 * 	
	 * @return java.awt.TextField	
	 */
	private TextField getTextAdres() {
		if (textAdres == null) {
			textAdres = new TextField();
			textAdres.setBounds(new Rectangle(241, 210, 530, 145));
			textAdres.setFont(new Font("Dialog", Font.PLAIN, 36));
		}
		return textAdres;
	}

	/**
	 * This method initializes buttonRestGuncelle	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getButtonRestGuncelle() {
		if (buttonRestGuncelle == null) {
			buttonRestGuncelle = new JButton();
			buttonRestGuncelle.setBounds(new Rectangle(560, 426, 201, 48));
			buttonRestGuncelle.setText("Güncelle");
			buttonRestGuncelle.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					r.setName(textRestoranAdi.getText());
					r.setAdress(textAdres.getText());
				}
			});
		}
		return buttonRestGuncelle;
	}

	/**
	 * This method initializes rolDegistir	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getRolDegistir() {
		if (rolDegistir == null) {
			rolDegistir = new JButton();
			rolDegistir.setBounds(new Rectangle(561, 478, 201, 46));
			rolDegistir.setText("Rol Değiştir");
			rolDegistir.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					shut_up();
					Common c = new Common("Boss", r);
					c.setVisible(true);
				}
			});
		}
		return rolDegistir;
	}

	/**
	 * This method initializes musteriPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getMusteriPanel() {
		if (musteriPanel == null) {
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.fill = GridBagConstraints.BOTH;
			gridBagConstraints.gridy = 0;
			gridBagConstraints.weightx = 1.0;
			gridBagConstraints.weighty = 1.0;
			gridBagConstraints.gridx = 0;
			musteriPanel = new JPanel();
			musteriPanel.setLayout(new GridBagLayout());
			musteriPanel.add(getList(), gridBagConstraints);
		}
		return musteriPanel;
	}

	/**
	 * This method initializes list	
	 * 	
	 * @return java.awt.List	
	 */
	private List getList() {
		if (list == null) {
			list = new List();
		}
		return list;
	}

	/**
	 * This method initializes dataPuan	
	 * 	
	 * @return java.awt.TextField	
	 */
	private TextField getDataPuan() {
		if (dataPuan == null) {
			dataPuan = new TextField();
			dataPuan.setBounds(new Rectangle(241, 161, 531, 48));
			dataPuan.setEditable(false);
			dataPuan.setFont(new Font("Dialog", Font.PLAIN, 36));
		}
		return dataPuan;
	}

	/**
	 * This method initializes btnSiparisiYolaCikar	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getBtnSiparisiYolaCikar() {
		if (btnSiparisiYolaCikar == null) {
			btnSiparisiYolaCikar = new Button();
			btnSiparisiYolaCikar.setBounds(new Rectangle(560, 378, 205, 44));
			btnSiparisiYolaCikar.setLabel("Sipariş Yola Çıktı");
			btnSiparisiYolaCikar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if (aktif == null) return;
					aktif.setOrderInProgress();
					filler();
				}
			});
		}
		return btnSiparisiYolaCikar;
	}

	/**
	 * This method initializes btnSiparisTeslimEdildi	
	 * 	
	 * @return java.awt.Button	
	 */
	private Button getBtnSiparisTeslimEdildi() {
		if (btnSiparisTeslimEdildi == null) {
			btnSiparisTeslimEdildi = new Button();
			btnSiparisTeslimEdildi.setBounds(new Rectangle(555, 427, 210, 43));
			btnSiparisTeslimEdildi.setLabel("Sipariş Yerine Ulaştı");
			btnSiparisTeslimEdildi.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if (aktif == null) return;
					aktif.setOrderDelivered();
					filler();
				}
			});
		}
		return btnSiparisTeslimEdildi;
	}

}
