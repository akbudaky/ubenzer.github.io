public class ColRowChar {
	
/* sat�r s�tun bilgisinin d�s�nda bunun hangi karaktere ait oldugu bilgisi tutuluyor...*/
	int col;
	int row;
	char c;
	
	public ColRowChar(ColRow cr, char c) {
		this.row = cr.row;
		this.col = cr.col;
		this.c = c;
	}
	
}
