public class ColRow {
	/* yaln�zca sat�r s�tun bilgisi tutuluyor... */
	int col;
	int row;
	
	public ColRow(int row, int col) {
		this.row = row;
		this.col = col;
	}	
	
}