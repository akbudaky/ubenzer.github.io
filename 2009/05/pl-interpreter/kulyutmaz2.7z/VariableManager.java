import java.util.Hashtable;

public class VariableManager {
	Hashtable<String,Integer> vm = new Hashtable<String,Integer>();
	
	public void addVariable(String name, int value) {
		vm.put(name, value);
	}
	
	public boolean isVariableExists(String name) {
		return vm.containsKey(name);
	}
	
	public int getVariableValue(String string) {
		return vm.get(string);
	}
}
