import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

public class Main {

	public static ErrHandler e = new ErrHandler();
	public static VariableManager vm = new VariableManager();

	public static void main(String[] args) {
		int lineNumber = 1;
		int columnNumber = 1;

		System.out.println("K�lyutmaz 2.1");
		System.out.println("05-06-7699 Umut BENZER");
		System.out.println("05-06-7670 G�l DEL�ORMAN\n");

		CString girdi = new CString();
		
		String path;
		path = JOptionPane.showInputDialog("Dosya yolunu giriniz:");
		if (path == null) {
			e.addError("I/O Error. User cancelled.", -1, -1);
		}
		try {
			
			final BufferedReader in = new BufferedReader(new FileReader(path));
			String txt = null;
			/*
			 * Dosyadan bilgiler sat�r sat�r okunurken hangi s�rada okundugu=
			 * column ! ve ka��nc� sat�ra ait oldugu bilgisi= line !, yeni
			 * string s�n�f�ndan olusan stringe ekleniyor
			 */
			while ((txt = in.readLine()) != null) {
				for (int i = 0; i < txt.length(); i++) {
					girdi.addChar(txt.charAt(i), lineNumber, columnNumber);
					columnNumber++;
				}
				girdi.addChar('\n', lineNumber, columnNumber);
				columnNumber = 1;
				lineNumber++;
			}
			in.close();
		} catch (final IOException a) {
			e.addError("I/O Error. Check path for file. (" + path + ")", -1, -1);
		}
		/* girdi = <oldu�u gibi metin dosyas� sat�r sonu falan da var. */
		statements(girdi);
		if (vm.isVariableExists("result")) {
			System.out.println("Result: " + vm.getVariableValue("result"));
		} else {
			e.addError("Variable result is not defined.", -1, -1);
		}
	}

	public static boolean statements(CString input) {
		CString one_word = new CString();
		for (int i = 0; i < input.length(); i++) {
			/* Toplam koddaki harf say�s� kadar d�n�ver */
			/* Bu k�s�mda komut komut ayr��t�r�r�z. */
			if (input.charAt(i) == ';') {
				boolean status = false;
				for (int ii = 0; ii < one_word.length(); ii++) {
					if (!(one_word.charAt(ii) == '\t' || one_word.charAt(ii) == '\n' || one_word.charAt(ii) == ' ')) {
						status = true;
					}
				}
				if (!status) {
					e.addError("Unexpected character ';'. A proper statement nexpected? expected. :)", input.rowAt(i),input.colAt(i) + 1);
				}
				
				assignment(one_word);
				one_word = new CString(); // Elimizdekini s�f�rlama yolu!
			} else {
				one_word.addChar(input.everythingAt(i));
			}
		}
		for (int i = 0; i < one_word.length(); i++) {
			if (!(one_word.charAt(i) == ' ' || one_word.charAt(i) == '\t' || one_word.charAt(i) == '\n')) {
				e.addError("';' exptected at the end of the line.", one_word.rowAt(one_word.length() - 1), one_word.colAt(one_word.length() - 1));
			}
		}
		return true;
	}

	public static void assignment(CString one_word) {
		/* Bu k�s�mda sa� sol ayr��t�r�yoruz! */
		CString temp = new CString();
		CString left = new CString();
		CString right = new CString();
		boolean equal = false;
		int ass_cord = 0;
		
		for (int x = 0; x < one_word.length(); x++) {
			/*
			 * Bir sat�r gezilir ve sa� ve sol de�i�kenlerine nap�l�r?
			 * ayr��t�r�l�r.
			 */			
			if (one_word.charAt(x) == ':' && one_word.length() > x+1 && one_word.charAt(x + 1) == '=') {
				ass_cord = x;
				equal = true;
				left = temp;

				temp = new CString();
				x++; /* := iki karakter oldu�u i�in. */
			} else {
				temp.addChar(one_word.everythingAt(x));
			}
		}
		right = temp;
		if (equal) {
			
			boolean status = false;			
			if (left.length() > 0) {
				for (int i = 0; i < left.length(); i++) {
					if (!(left.charAt(i) == ' ' || left.charAt(i) == '\t' || left.charAt(i) == '\n')) {
						status = true;
					}
				}	
			}
			if (!status) {
				e.addError("Identifer expected on the left side of assignment operator.",one_word.rowAt(ass_cord),one_word.colAt(ass_cord));
			}
			
			status = false;			
			if (right.length() > 0) {
				for (int i = 0; i < right.length(); i++) {
					if (!(right.charAt(i) == ' ' || right.charAt(i) == '\t' || right.charAt(i) == '\n')) {
						status = true;
					}
				}	
			}
			if (!status) {
				e.addError("An operation excpected on the right side of assignment operator.",one_word.rowAt(ass_cord) + 1,one_word.colAt(ass_cord) + 1);
			}
			
			is_variable(left);
			vm.addVariable(varName(left), nexpr(right));
		} else {
			e.addError("Assigment operator ':=' exptected.", one_word.rowAt(one_word.length() - 1), one_word.colAt(one_word.length() - 1));
		}		
	}

	public static String varName(CString coming) {
		CString data = new CString();

		boolean started = false;
		boolean finished = false;
		for (int i = 0; i < coming.length(); i++) {
			if (!started) {
				if (!(coming.charAt(i) == '\t' || coming.charAt(i) == '\n' || coming.charAt(i) == ' ')) {
					started = true;
				}
			}
			if (started && !finished) {
				if (coming.charAt(i) == '\t' || coming.charAt(i) == '\n'|| coming.charAt(i) == ' ') {
					finished = true;
				} else {
					data.addChar(coming.everythingAt(i));
				}
			}
			if (started && finished) {
				if (!(coming.charAt(i) == '\t' || coming.charAt(i) == '\n' || coming.charAt(i) == ' ')) {
					e.addError("Unexpected character '" + coming.charAt(i) + "'.", coming.rowAt(i), coming.colAt(i));
				}
			}
		}

		return data.toString();
	}


	public static int nexpr(CString in) {

		/* ��lem �nceliksizine g�re ay�rmak laz�m */
		
		/* �nce +/-
		 * Sonra *
		 * Sonra ()
		 */
		
		/* TOPLA �IKAR */
		CString left = new CString();
		CString right = new CString();
		int count = 0;
		int last_pos = 0;
		
		for (int i = 0; i < in.length(); i++) {
			if (in.charAt(i) == '(') {
				count++;
			}
			if (in.charAt(i) == ')') {
				count--;
			}
			if (count < 0) { e.addError("Paratesis mismatch.", in.rowAt(i), in.colAt(i)); }
			if (count == 0) {
				if (in.charAt(i) == '+' || in.charAt(i) == '-') {
					last_pos = i;
				}
			}
		}
		if (last_pos > 0) {
			for (int i = 0; i < last_pos; i++) {
				left.addChar(in.everythingAt(i));
			}
			if (in.charAt(last_pos) == '+') {
				boolean status = false;
				for (int ii = last_pos+1; ii < in.length(); ii++) {
					if (!(in.charAt(ii) == '\t' || in.charAt(ii) == '\n' || in.charAt(ii) == ' ')) {
						status = true;
					}
					right.addChar(in.everythingAt(ii));
				}
				if (!status) {
					e.addError("Number or variable expected on the right side of +.", in.rowAt(in.length()-1),in.colAt(in.length()-1));
				}
				
				return safeAdd(nexpr(left), nexpr(right));
			}
			if (in.charAt(last_pos) == '-') {
				boolean negativeNumber = true;
				if (left.length() != 0) {
					for (int ii = 0; ii<left.length();ii++) {
						if (!(left.charAt(ii) == ' ' || left.charAt(ii) == '\t' || left.charAt(ii) == '\n')) {
							negativeNumber = false;
						}
					}
				}
				if (!negativeNumber) {
					boolean status = false;
					for (int ii = last_pos+1; ii < in.length(); ii++) {
						if (!(in.charAt(ii) == '\t' || in.charAt(ii) == '\n' || in.charAt(ii) == ' ')) {
							status = true;
						}
						right.addChar(in.everythingAt(ii));
					}
					if (!status) {
						e.addError("Number or variable expected on the right side of -.", in.rowAt(in.length()-1),in.colAt(in.length()-1));
					}
					return safeSubtract(nexpr(left), nexpr(right));
				}		
			}	
		}		
		
		/* �ARP */
		left = new CString();
		right = new CString();
		count = 0;
		last_pos = 0;
		
		for (int i = 0; i < in.length(); i++) {
			if (in.charAt(i) == '(') {
				count++;
			}
			if (in.charAt(i) == ')') {
				count--;
			}
			if (count < 0) { e.addError("Paratesis mismatch.", in.rowAt(i), in.colAt(i)); }
			if (count == 0) {
				if (in.charAt(i) == '*') {
					last_pos = i;
				}
			}
		}
		if (last_pos > 0) {
			for (int i = 0; i < last_pos; i++) {
				left.addChar(in.everythingAt(i));
			}			
			boolean status = false;
			for (int ii = last_pos+1; ii < in.length(); ii++) {
				if (!(in.charAt(ii) == '\t' || in.charAt(ii) == '\n' || in.charAt(ii) == ' ')) {
					status = true;
				}
				right.addChar(in.everythingAt(ii));
			}
			if (!status) {
				e.addError("Number or variable expected on the right side of *.", in.rowAt(in.length()-1),in.colAt(in.length()-1));
			}
					
			status = false;
			for (int ii = 0; ii < left.length(); ii++) {
				if (!(left.charAt(ii) == '\t' || left.charAt(ii) == '\n' || left.charAt(ii) == ' ')) {
					status = true;
				}
			}
			if (!status) {
				e.addError("Number or variable expected on the left side of *.", in.rowAt(in.length()-1),in.colAt(in.length()-1));
			}					
					
			return safeMultiple(nexpr(left), nexpr(right));
		}
					
		
		/* PARANTEZ */
		right = new CString();
		
		for (int i = 0; i < in.length(); i++) {
			if (in.charAt(i) == '(') {
				for (int ii = i; ii < in.length(); ii++) {
					right.addChar(in.everythingAt(ii));					
				}
				CString temp = inParant(right);
				if (temp.length() == 0) {
					e.addError("Variable or constant expected inside the paranthesis.", in.rowAt(in.length()-1), in.colAt(in.length()-1));	
				}
				return nexpr(temp);
			}
		}		
		
		/* SAYI YA DA VER�EYBIL */
		CString data = new CString();

		boolean started = false;
		boolean finished = false;
		
		for (int i = 0; i < in.length(); i++) {
			if (!started) {
				if (!(in.charAt(i) == '\t' || in.charAt(i) == '\n' || in.charAt(i) == ' ')) {
					started = true;
				}
			}
			
			if (started && !finished) {
				if (in.charAt(i) == '\t' || in.charAt(i) == '\n' || in.charAt(i) == ' ') {
					finished = true;
				} else {
					data.addChar(in.everythingAt(i));
				}
			}
			
			if (started && finished) {
				if (!(in.charAt(i) == '\t' || in.charAt(i) == '\n' || in.charAt(i) == ' ')) {
					e.addError("Unexpected character '" + in.charAt(i) + "'.", in.rowAt(i), in.colAt(i));
				}
			}
		}
		
		if (!started) {
			e.addError("Unexpected character '" + in.charAt(in.length()-1) + "'. Constant or variable expected.", in.rowAt(in.length()-1), in.colAt(in.length()-1));
		}
		
		if (is_numeric(data.charAt(0)) || data.charAt(0) == '-') {
			if (is_integer(data)) {
				/* H�m, demek ki bu bi say�. */
				return Integer.parseInt(data.toString());
			} else {
				for (int j = 1; j < data.length(); j++) {
					if (!is_numeric(data.charAt(j))) {
						e.addError("Unexpected character " + data.charAt(j)	+ ". Expecting numeric value.", data.rowAt(j), data.colAt(j));
					}
				}
				e.addError("Constant value out of bounds.", data.rowAt(0), data.colAt(0));
			}
		}

		is_variable(data);
		/* Hay�r, de�i�ken. */
		if (!vm.isVariableExists(data.toString())) {
			e.addError("Variable used before it was initialized.", data.rowAt(0), data.colAt(0));
		}
		return vm.getVariableValue(data.toString());
	}
	
	public static CString inParant(CString in) {
		boolean started = false;
		boolean finished = false;
		CString data = new CString();
		int count = 0;
		for (int i = 0; i < in.length(); i++) {
			if (!started) {
				if (in.charAt(i) == '(') {
					started = true;
				} else if (!(in.charAt(i) == '\t' || in.charAt(i) == '\n' || in.charAt(i) == ' ')) {
					e.addError("Unexpected character '" + in.charAt(i) + "'. '(' expected.", in.rowAt(i), in.colAt(i));
				}
			} else if (started && !finished) {
				if (in.charAt(i) == ')') {
					if (count == 0) {
						finished = true;
						continue;
					} else {
						data.addChar(in.everythingAt(i));
						count--;
					}
				} else if (in.charAt(i) == '(') {
					count++;
					data.addChar(in.everythingAt(i));
				} else {
					data.addChar(in.everythingAt(i));
				}
			} else if (started && finished) {
				if (!(in.charAt(i) == '\t' || in.charAt(i) == '\n' || in.charAt(i) == ' ')) {
					e.addError("Unexpected character '" + in.charAt(i) + "'.", in.rowAt(i), in.colAt(i));
				}
			}
		}
		if (!started) {
			e.addError("'(' expected. Parantesis mismatch.", in.rowAt(0), in.colAt(0));
		}
		return data;
	}

	/**
	 * G�nderilen Stringin ge�erli bir variable olup olmad���n� bulur
	 * 
	 * @param suspect
	 * @return boolean
	 */
	public static boolean is_variable(CString suspect) {
		boolean started = false;
		boolean finished = false;
		int count = 0;
		for (int i = 0; i < suspect.length(); i++) {
			if (!started) {
				if (is_character(suspect.charAt(i))) {
					started = true;
				} else if (!(suspect.charAt(i) == '\t' || suspect.charAt(i) == '\n' || suspect.charAt(i) == ' ')) {
					e.addError("Unexpected character '" + suspect.charAt(i)	+ "' in variable name.", suspect.rowAt(i), suspect.colAt(i));
					return false;
				}
			}
			if (started && !finished) {
				count++;
				if (count > 32) {
					e.addError("Variable name larger than 32 characters.", suspect.rowAt(i), suspect.colAt(i));
					return false;
				}
				if (!is_character(suspect.charAt(i))) {
					finished = true;
				}
			}
			if (started && finished) {
				if (!(suspect.charAt(i) == '\t' || suspect.charAt(i) == '\n' || suspect.charAt(i) == ' ')) {
					e.addError("Unexpected character '" + suspect.charAt(i)	+ "' in variable name.", suspect.rowAt(i), suspect.colAt(i));
					return false;
				}
			}
		}
		return true;
	}

	public static boolean is_character(char in) {
		if (!(in == 'A' || in == 'B' || in == 'C' || in == 'D' || in == 'E'
				|| in == 'F' || in == 'G' || in == '�' || in == 'H'
				|| in == 'I' || in == '�' || in == 'J' || in == 'K'
				|| in == 'L' || in == 'M' || in == 'N' || in == 'O'
				|| in == '�' || in == 'P' || in == 'R' || in == 'S'
				|| in == '�' || in == 'T' || in == 'U' || in == '�'
				|| in == 'V' || in == 'Y' || in == 'Z' ||

				in == 'a' || in == 'b' || in == 'c' || in == 'd' || in == 'e'
				|| in == 'f' || in == 'g' || in == '�' || in == 'h'
				|| in == '�' || in == 'i' || in == 'j' || in == 'k'
				|| in == 'l' || in == 'm' || in == 'n' || in == 'o'
				|| in == '�' || in == 'p' || in == 'r' || in == 's'
				|| in == '�' || in == 't' || in == 'u' || in == '�'
				|| in == 'v' || in == 'y' || in == 'z' || in == '_'))
			return false;
		return true;
	}

	/**
	 * G�nderilen karakterin rakam olup olmad���n� bulur.
	 * 
	 * @param in
	 * @return boolean
	 */
	public static boolean is_numeric(char in) {
		if (!(in == '1' || in == '2' || in == '3' || in == '4' || in == '5'
				|| in == '6' || in == '7' || in == '8' || in == '9' || in == '0'))
			return false;
		return true;
	}

	public static boolean is_integer(CString data) {
		try {
			Integer.parseInt(data.toString());
			return true;
		} catch (NumberFormatException nfe) {
			return false;
		}
	}
	
	public static int safeAdd(final int x, final int y) {
	    final int z = x + y;
	    if (x > 0) {
	        if (y > 0 && z < 0)
	            e.addError("Overflow adding " + x + " + " + y + "!",-1,-1);
	    } else if (y < 0 && z > 0)
	    	e.addError("Overflow adding " + x + " + " + y + "!",-1,-1);
	    return z;
	}

	public static int safeMultiple(final int x, final int y) {
	    final int z = x * y;
	    if (x > 0) {
	        if (y > 0 && z < 0)
	            e.addError("Overflow multiplying " + x + " with " + y + "!",-1,-1);
	    } else if (y < 0 && z < 0)
	    	e.addError("Overflow multiplying " + x + " with " + y + "!",-1,-1);
	    return z;
	}
	
	public static int safeSubtract(final int x, final int y) {
	    final int z = x - y;
	    if (x > 0) {
	        if (y < 0 && z < 0)
	        	e.addError("Overflow subtracting " + x + " + " + y + "!",-1,-1);
	    } else if (y > 0 && z > 0)
	    	e.addError("Overflow subtracting " + x + " + " + y + "!",-1,-1);
	    return z;
	}
}
