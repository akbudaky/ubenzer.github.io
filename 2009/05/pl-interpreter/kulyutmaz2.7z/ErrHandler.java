public class ErrHandler {

	public void addError(String message, int row, int col) {
		System.out.println(message + " Line: " + row + " Column: " + col);
		System.exit(0);
	}
}
