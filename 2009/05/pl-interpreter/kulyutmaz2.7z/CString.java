import java.util.Vector;

public class CString {

	private Vector<ColRow> colrow = new Vector<ColRow>();

	private String str = new String();
	private int index = 0;

	public void addChar(char chaR, int row, int col) {
		/* Gelen karakteri row coloumn degerleriyle stringe ekliyor... */
		str = str + chaR;
		colrow.add(index, new ColRow(row, col));
		index++;
	}

	public void addChar(ColRowChar crc) {
		/*
		 * ColRowChar s�n�f�ndan gelen karakteri row coloumn degerletiyle
		 * stringe ekliyor...
		 */
		str = str + crc.c;
		colrow.add(index, new ColRow(crc.row, crc.col));
		index++;
	}

	public int length() {
		/* string uzunlugunu d�nd�r�yor... */
		return str.length();
	}

	public char charAt(int i) {
		/* Belirtilen indexteki karakteri d�nd�r�yor... */
		return str.charAt(i);
	}

	/*
	 * Bundan sonraki metodlar i�in ColRow nesnesi t�retilerek sat�r s�tun
	 * bilgileri okunuyor..
	 */

	public int rowAt(int i) {
		/*
		 * Belirtilen indexteki karakterin ka��nc� sat�ra ait oldugu bilgisi
		 * d�nd�r�l�yor...
		 */
		ColRow temp = colrow.elementAt(i);
		return temp.row;
	}

	public int colAt(int i) {
		/*
		 * Belirtilen indexteki karakterin ka��nc� s�tuna ait oldugu bilgisi
		 * d�nd�r�l�yor...
		 */
		ColRow temp = colrow.elementAt(i);
		return temp.col;
	}

	public ColRowChar everythingAt(int i) {
		/*
		 * Belirtilen indexteki karakterin ka��nc� sat�r&s�tuna ait oldugu
		 * bilgisi ve hangi karaktere ait oldugu d�nd�r�l�yor...
		 */
		return new ColRowChar(colrow.elementAt(i), str.charAt(i));
	}

	public String toString() {
		/* Stringi d�nd�r�yor... */
		return str;
	}

	public CString concat(CString s1, CString s2) {
		/* Stringlerde ;Cstring tipi i�in concat i�lemini sa�l�yor... */

		for (int i = 0; i < s2.length(); i++) {
			s1.addChar(s2.everythingAt(i));
		}
		return s1;
	}
}
