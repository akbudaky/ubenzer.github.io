<?php 

/* 
	Session tabanlı basit bir oturum açma/kapama sistemi.
	A session based, simple user login/logout system.	
	----------------------------------------------------------------------
	Bu projede yer alan kodlar ticari bir amaçla kullanılmadığı sürece
	ücretsizdir. Zaten bu projeyi ticari bir amaçla kullanmanın anlamı
	nedir? Sadece eğitim amaçlı bir projedir bu ve bir kuruş bile edecek
	değeri de yoktur. :)
	----------------------------------------------------------------------
	This project is free of charge unless used in commercial 
	projects. An what is the point of using these codes in commercial
	projects. They are just for edicional purposes, and event doesn't
	worth a penny! :)
	-----------------------------------------------------------------------
	Copyleft Umut Benzer. Ege University Computer Engineering. 2008
	http://Www.ubenzer.com/
*/

/* Projenin diğer dosyaları doğrudan çağrılınca çalışmamaları için */
/* Other php's of project shouldn't call directly. */
define('DUYURU',1);

/* Session */
session_start();
header('Content-Type: text/html; charset=utf-8');

/* Veritabanı ve Fonksiyonlar*/
/* Database and Functions */
require_once("./db/settings.php"); /* Genel ve veritabanı ayarlarını tutar.  General and database connection settings. */
require_once("functions.php"); /* Projenin gerekli fonksiyonlarını içerir. Functions needed by this project. */ 

/* Post-Get İşleyici: Eğer sayfaya get ya da post verileriyle gelinirse gerekli fonksiyonlara yönlendirme yapılır. */
/* Post-Get Processor: If user sent data includes POST or GET data, then user redirects to proper function. */
if (isset($_GET['action'])) {
	
	switch ($_GET['action']) {
		case 'logout':
			logout();
			break;
		case 'login':
			login();
			break;
	}
	
}
/* Post-Get İşleyici Bitti*/
/* End of Post-Get Processor */

/* Çıktı Başlangıcı */
/* Projenin bu adımından sonra istediğiniz çıktıyı alabilrisiniz. Oturum 
   açılıp açılmadığını projinizin herhangi bir noktasında is_logged() fonksiyonu 
   ile yapabilirsiniz.
   
   is_logged: Eğer oturum açıldıysa 1, oturum açılmadıysa 0 döndürür. Örnek kod
   aşağıdadır.   
*/

/* Start of Output ?/
/* At this stage of project. You can output whatevet you want. If you want to check
   if user logged in or not, just use is_logged() function.
   
   is_logged: If user logged returns 1, else returns 0. Sample code is bellow.
*/

if (!is_logged()) { ?>
	<form name="loginform" id="loginform" action="index.php?action=login" method="post">
		<p>
			<label>Kullanıcı adı<br />
			<input type="text" name="user" id="user" class="input" value="" size="20" tabindex="10" /></label>
		</p>
		<p>
			<label>Şifre<br />
			<input type="password" name="pass" id="pass" class="input" value="" size="20" tabindex="20" /></label>
		</p>
		<input name="key" type="hidden" value="<?php echo(md5(session_id())); ?>"/>
		<p class="submit">
			<input type="submit" id="wp-submit" value="Giriş" tabindex="100" />
		</p>
	</form>
<?php } else { ?>
	Tebrikler oturum açtın. Şimdi <a href="index.php?action=logout">kapat</a>. :)
<?php } ?>