<?php

/* 
	Session tabanl� basit bir oturum a�ma/kapama sistemi.
	A session based, simple user login/logout system.	
	----------------------------------------------------------------------
	Bu projede yer alan kodlar ticari bir ama�la kullan�lmad��� s�rece
	�cretsizdir. Zaten bu projeyi ticari bir ama�la kullanman�n anlam�
	nedir? Sadece e�itim ama�l� bir projedir bu ve bir kuru� bile edecek
	de�eri de yoktur. :)
	----------------------------------------------------------------------
	This project is free of charge unless used in commercial 
	projects. An what is the point of using these codes in commercial
	projects. They are just for edicional purposes, and event doesn't
	worth a penny! :)
	-----------------------------------------------------------------------
	Copyleft Umut Benzer. Ege University Computer Engineering. 2008
	http://Www.ubenzer.com/
*/

if (!defined('DUYURU')) {
	/* You can't reach this page directly. */
	/* Bu sayfaya do�rudan eri�ilemez. */
	die('Yasak. :)');
}

/* ez_SQL s�n�flar� �a��r�l�r. */
/* ez_SQL classes */
include ("./db/core.php");
include ("./db/mysql.php");

/* Sunucu Ayarlar� */
$db_server = 'localhost';
$db_name = 'veritaban�_ad�';
$db_user = 'veritaban�_kullan�c�s�';
$db_passwd = 'veritaban�_�iresi';
$prefix = "log_"; /* Veritaan� �neki. */
$version = 0.1; /* Proje s�r�m� - Project version */ 

$db = new ezSQL_mysql($db_user,$db_passwd,$db_name,$db_server);

/* GEREKL� VER�TABANI TABLOSU YAPISI - REQUIRED DATABASE TABLE STRUCTURE */

/* 
CREATE TABLE IF NOT EXISTS `log_user` (
  `ID` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `pass` text NOT NULL,
  `real_name` text NOT NULL,
  `last_login` datetime NOT NULL default '0000-00-00 00:00:00',
  `login_count` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

INSERT INTO `yse_user` (`ID`, `name`, `pass`, `real_name`, `last_login`, `login_count`) VALUES
(1, 'Umut', '202cb962ac59075b964b07152d234b70', 'Umut Benzer', '2008-07-09 01:56:10', 0);

*/

/* Bu tablo ile kullan�c� ad� Umut �ifre 123 olan bir test kullan�c�s� yarat�l�r. */
/* With this table a test user created with username Umut pass 123 */

?>