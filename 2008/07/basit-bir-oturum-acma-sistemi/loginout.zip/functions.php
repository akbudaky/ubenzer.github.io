<?php

/* 
	Session tabanl� basit bir oturum a�ma/kapama sistemi.
	A session based, simple user login/logout system.	
	----------------------------------------------------------------------
	Bu projede yer alan kodlar ticari bir ama�la kullan�lmad��� s�rece
	�cretsizdir. Zaten bu projeyi ticari bir ama�la kullanman�n anlam�
	nedir? Sadece e�itim ama�l� bir projedir bu ve bir kuru� bile edecek
	de�eri de yoktur. :)
	----------------------------------------------------------------------
	This project is free of charge unless used in commercial 
	projects. An what is the point of using these codes in commercial
	projects. They are just for edicional purposes, and event doesn't
	worth a penny! :)
	-----------------------------------------------------------------------
	Copyleft Umut Benzer. Ege University Computer Engineering. 2008
	http://Www.ubenzer.com/
*/

if (!defined('DUYURU')) { 
	/* You can't reach this page directly. */
	/* Bu sayfaya do�rudan eri�ilemez. */
	die('Yok art�k Lebron James!');
}

function is_logged() {
	/* Return values: 
		1 = LOGGED;
		0 = GUEST 
	*/
	if (isset($_SESSION['logged'])) {
		return $_SESSION['logged'];
	} else {
		return 0;
	}
}

function login() {
	/* Zaten a��k oturumu bir daha a�amay�z. */
	/* Can't login, if person already logged in. */
	if (!$_SESSION['logged'] == 1) {
		/* Input values; 
			$_POST['user'] = user_name
			$_POST['pass'] = password
			$_POST['key'] = session in md5
		*/	
		/* Return values: 
			1: Login OK, $_SESSION['logged'] = 1;
		    -1: Login Failed.
		*/
		global $db, $prefix, $mesaj;
		
		if (!(isset($_POST['user']) && isset($_POST['pass']) && isset($_POST['key']))) {
			$mesaj = 'invalid_data';
			return -1;	
		}
		
		$session = htmlspecialchars($_POST['key']);
		$user = htmlspecialchars($_POST['user']);
		$pass = htmlspecialchars($_POST['pass']);
		
		if (htmlspecialchars(md5(session_id())) != $session) {
			$mesaj = 'session_invalid';
			return -1;
		}	
		
		if ($user == NULL || $user == "" || $pass == NULL || $pass == "") {
			$mesaj = 'invalid_data';
			return -1;
		}
		
		$sonuc = $db->get_row('SELECT pass FROM '.$prefix.'user WHERE name = "'.$user.'"');
		if (md5($pass) == $sonuc->pass && $_SESSION['logged'] != 1) {
			$sonuc = $db->get_row('SELECT ID, name, real_name, login_count FROM '.$prefix.'user WHERE name = "'.$user.'"');
			$_SESSION['name'] = $sonuc->name;
			$_SESSION['real_name'] = $sonuc->real_name;
			$_SESSION['ID'] = $sonuc->ID;
			$db->query('UPDATE '.$prefix.'user SET login_count = "'.++$sonuc->login_count.'" WHERE ID = "'.$_SESSION['ID'].'"');
			$db->query('UPDATE '.$prefix.'user SET last_login = NOW() WHERE ID = "'.$_SESSION['ID'].'"');

			$_SESSION['logged'] = 1;
			header('Location: index.php');
			return 1;
		}

		$mesaj = 'invalid_data';
		return -1;
	}
}

function logout() {
	/* A��k olmayan oturumun nesini sonland�raca��m! */
	/* Can't logoff, if person is not login. */
	if ($_SESSION['logged'] == 1) {
		global $mesaj;
		$_SESSION['logged'] = 0;
		$mesaj = 'logged_out';
	}
}
?>