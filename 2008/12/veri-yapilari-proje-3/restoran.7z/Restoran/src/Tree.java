import java.io.*;
import java.util.Vector;

class Tree implements Serializable {
	private static final long serialVersionUID = 7152535335347442892L;
	private Restoran root;
	Vector<Restoran> RestoranVektor = new Vector<Restoran>();
	
	public Tree() {
		root = null;
	}

	public Restoran getRestoran(String restoranAdi) {
		if (root == null) {
			return null;
		}
		Restoran current = root;
		while (!current.ad.equalsIgnoreCase(restoranAdi)) {
			if (restoranAdi.compareTo(current.ad) < 0) {
				current = current.leftChild;
			} else {
				current = current.rightChild;
			}
			if (current == null) {
				return null;
			}
		}
		return current;
	}

	public void addRestoran(Restoran gelenRest) {
		if (root == null) {
			root = gelenRest;
		} else {
			Restoran current = root;
			Restoran parent;
			while (true) {
				parent = current;
				if (gelenRest.ad.compareTo(current.ad) < 0) {
					current = current.leftChild;
					if (current == null) {
						parent.leftChild = gelenRest;
						return;
					}
				} else {
					current = current.rightChild;
					if (current == null) {
						parent.rightChild = gelenRest;
						return;
					}
				}
			} 
		}
	}

	public boolean removeRestoran(String restoranAdi) {
		if (root == null) {
			return false;
		}
		
		Restoran current = root;
		Restoran parent = root;
		boolean isLeftChild = true;

		while (!current.ad.equalsIgnoreCase(restoranAdi)) {
			parent = current;
			if (restoranAdi.compareTo(current.ad) < 0) {
				isLeftChild = true;
				current = current.leftChild;
			} else {
				isLeftChild = false;
				current = current.rightChild;
			}
			if (current == null) {
				return false;
			}
		}

		if (current.leftChild == null && current.rightChild == null) {
			if (current == root) {
				root = null;
			} else if (isLeftChild) {
				parent.leftChild = null;
			} else {
				parent.rightChild = null;				
			}
		} else if (current.rightChild == null) {
			if (current == root) {
				root = current.leftChild;
			} else if (isLeftChild) {
				parent.leftChild = current.leftChild;
			} else {
				parent.rightChild = current.leftChild;
			}
		} else if (current.leftChild == null) {
			if (current == root) {
				root = current.rightChild;
			} else if (isLeftChild) {
				parent.leftChild = current.rightChild;
			} else {
				parent.rightChild = current.rightChild;
			}
		} else {
			Restoran successor = getSuccessor(current);
			if (current == root) {
				root = successor;
			} else if (isLeftChild) {
				parent.leftChild = successor;
			} else {
				parent.rightChild = successor;
			}				
			successor.leftChild = current.leftChild;			
		} 
		return true; 
	}

	private Restoran getSuccessor(Restoran delNode) {
		Restoran successorParent = delNode;
		Restoran successor = delNode;
		Restoran current = delNode.rightChild;
		while (current != null) {
			successorParent = successor;
			successor = current;
			current = current.leftChild;
		}

		if (successor != delNode.rightChild) {
			successorParent.leftChild = successor.rightChild;
			successor.rightChild = delNode.rightChild;
		}
		return successor;
	}

	public Vector<Restoran> preOrder() {
		RestoranVektor.clear();
		preOrder_i(root);
		return RestoranVektor;
	}
	
	public Vector<Restoran> inOrder() {
		RestoranVektor.clear();
		inOrder_i(root);
		return RestoranVektor;
	}
	
	public Vector<Restoran> postOrder() {
		RestoranVektor.clear();
		postOrder_i(root);
		return RestoranVektor;
	}
	
	private void preOrder_i(Restoran localRoot) {
		if(localRoot != null) {
			RestoranVektor.add(localRoot);
			preOrder_i(localRoot.leftChild);
			preOrder_i(localRoot.rightChild);
		}		
	}

	private void inOrder_i(Restoran localRoot) {
		if(localRoot != null) {
			preOrder_i(localRoot.leftChild);
			RestoranVektor.add(localRoot);
			preOrder_i(localRoot.rightChild);
		}		
	}
	
	private void postOrder_i(Restoran localRoot) {
		if(localRoot != null) {
			preOrder_i(localRoot.leftChild);
			preOrder_i(localRoot.rightChild);
			RestoranVektor.add(localRoot);
		}		
	}
	
	public int depthMeter (Restoran localRoot) {
		int depth=0;
		if (root == null) {
			return -1;
		}
		Restoran current = root;
		while (!current.ad.equalsIgnoreCase(localRoot.ad)) {
			if (localRoot.ad.compareTo(current.ad) < 0) {
				current = current.leftChild;
				depth++;
			} else {
				current = current.rightChild;
				depth++;
			}
			
		}
		return depth;
	}

	public Tree balance() {
		Tree t = new Tree();
		Vector<Restoran> v = this.inOrder();
		balance_i(v,t);		
		return t;
	}
	
	public void balance_i(Vector<Restoran> v, Tree t){
		Vector<Restoran> vLeft= new Vector<Restoran>();
		Vector<Restoran> vRight= new Vector<Restoran>();
		
		if(v.size()==0)
			return;
		if(v.size()==1){
			t.addRestoran(v.elementAt(0));
			return;
		}
		int mid;
		if(v.size()%2==0)
			mid=v.size()/2-1;
		else
			mid=(v.size()-1)/2;
		
		t.addRestoran(v.elementAt(mid));
		
		for(int i=0;i<mid-1;i++){
			vLeft.addElement(v.elementAt(i));
		}
		
		balance_i(vLeft, t);
		
		for(int i=mid+1;i<v.size();i++){
			vRight.addElement(v.elementAt(i));
		}
		
		balance_i(vRight,t);
		
	}
}