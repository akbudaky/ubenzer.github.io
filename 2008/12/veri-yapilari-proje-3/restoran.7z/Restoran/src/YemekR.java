import java.io.Serializable;
import java.util.*;

public class YemekR implements Serializable {
	private static final long serialVersionUID = -7004561629413171261L;
	Vector<YemekRYapi> yemekList = new Vector<YemekRYapi>();
	
	/* Ad� ve fiyat� verilen yeme�i ekler. */
	public void addYemek(String yemekAdi, float fiyati) {
		yemekList.addElement(new YemekRYapi(yemekAdi,fiyati));
	}
	
	public void addYemek(YemekRYapi yemek) {
		yemekList.addElement(yemek);
	}
	
	/* Ad� verilen yeme�i siler. */
	public void removeYemek(String yemekAdi) {
		for (int i=0; i < yemekList.size(); i++) {
			if (yemekList.elementAt(i).yemekAdi.equalsIgnoreCase(yemekAdi)) {
				yemekList.removeElementAt(i);
				break;
			}				
		}
	}
	
	/* yemekAdi isimli yemek olup olmad���n� bulur. */
	public boolean hasYemek(String yemekAdi) {
		for (int i=0; i < yemekList.size(); i++) {
			if (yemekList.elementAt(i).yemekAdi.equalsIgnoreCase(yemekAdi)) {
				return true;
			}				
		}
		return false;
	}
	
	public float getYemekFiyati(String yemekAdi) {
		for (int i=0; i < yemekList.size(); i++) {
			if (yemekList.elementAt(i).yemekAdi.equalsIgnoreCase(yemekAdi)) {
				return yemekList.elementAt(i).fiyati;
			}				
		}
		return -1;		
	}
	
	/* Yemek ad�nda de�i�iklik yapmak i�in kullan�l�r. */
	public void changeYemek(String oldYemekAdi, String newYemekAdi) {
		for (int i=0; i < yemekList.size(); i++) {
			if (yemekList.elementAt(i).yemekAdi.equalsIgnoreCase(oldYemekAdi)) {
				yemekList.elementAt(i).yemekAdi = newYemekAdi;
			}				
		}
	}

	/* Yemek ad�nda de�i�iklik yapmak i�in kullan�l�r. */
	public void changeYemek(String yemekAdi, float newFiyati) {
		for (int i=0; i < yemekList.size(); i++) {
			if (yemekList.elementAt(i).yemekAdi.equalsIgnoreCase(yemekAdi)) {
				yemekList.elementAt(i).fiyati = newFiyati;
			}				
		}
	}
	
	/* Alt limit ve �st limit kriterine uygun yemekleri YemekR nesnesi i�inde d�nd�r�r.
	 * Bir anlamda filtre g�revi g�r�r. 
	*/
	public YemekR yemekFiltre(float fiyatAltLimit, float fiyatUstLimit) {
		YemekR filtre = new YemekR();
		for (int i=0; i < yemekList.size(); i++) {
			if (yemekList.elementAt(i).fiyati >= fiyatAltLimit &&
					yemekList.elementAt(i).fiyati <= fiyatUstLimit) {
				filtre.addYemek(yemekList.elementAt(i));
			}				
		}
		
		return filtre;
		
	}

}
