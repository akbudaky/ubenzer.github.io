import java.awt.*;
import javax.swing.*;
import javax.swing.JOptionPane;

public class Console extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private TextArea out = null;
	/**
	 * This is the default constructor
	 */
	public Console() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(940, 600);
		this.setContentPane(getJContentPane());
		this.setTitle("��kmez Bili�im Sistemleri");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getOut(), BorderLayout.CENTER);
		}
		return jContentPane;
	}

	/**
	 * This method initializes out	
	 * 	
	 * @return java.awt.TextArea	
	 */
	private TextArea getOut() {
		if (out == null) {
			out = new TextArea();
			out.setBackground(Color.black);
			out.setEditable(false);
			out.setFont(new Font("Consolas", Font.PLAIN, 14));
			out.setForeground(Color.cyan);
		}
		return out;
	}
	
	public void write(String metin) {
		out.setText(out.getText() + (out.getText().equals("") ? "" : "\n") + metin);
	}
	
	public String read() {
		return read("Se�im:",true);
	}
	public String read(boolean acceptNull) {
		return read("Se�im:",acceptNull);
	}
	public String read(String msg) {
		return read(msg, true);
	}	
	public String read(String msg, boolean acceptNull) {
		String sonuc = null;
		sonuc = JOptionPane.showInputDialog(msg);
		if (acceptNull != true) {			
			while (sonuc == null) {
				sonuc = JOptionPane.showInputDialog(msg);				
			}
		}
		return sonuc;
		
	}
	
	public int readInt() {
		return readInt("Se�im:");
	}
	public int readInt(String msg) {
		String metin;
		metin = read(msg, false);
		
		while(!isParsableToInt(metin)) {
			metin = read(msg, false);
		}
		return Integer.parseInt(metin);
	}
	public boolean isParsableToInt(String i) {
		try {
			Integer.parseInt(i);
			return true;
		} catch (NumberFormatException nfe) {
			return false;
		}
	}
	
	public float readFloat() {
		return readFloat("Se�im:");
	}
	public float readFloat(String msg) {
		String metin;
		metin = read(msg, false);
		
		while(!isParsableToInt(metin)) {
			metin = read(msg, false);
		}
		return Float.parseFloat(metin);
	}
	public boolean isParsableToFloat(String i) {
		try {
			Float.parseFloat(i);
			return true;
		} catch (NumberFormatException nfe) {
			return false;
		}
	}	
	
	public boolean readBoolean() {
		return readBoolean("Se�im: (E/H)");
	}
	public boolean readBoolean(String msg) {
		String metin;
		metin = read(msg, false);
		
		while(!isParsableToBoolean(metin)) {
			metin = read(msg, false);
		}
		return Boolean.parseBoolean(metin);
	}
	public boolean isParsableToBoolean(String i) {
		try {
			Boolean.parseBoolean(i);
			return true;
		} catch (NumberFormatException nfe) {
			return false;
		}
	}	
	
	
	public void cls() {
		out.setText("");
	}
	public void beklet() {
		JOptionPane.showMessageDialog(null,"Devam etmek i�in a�a��daki tu�a bas�n.","�BS Restoran Sistemi",JOptionPane.PLAIN_MESSAGE);
		this.cls();
	}


}  //  @jve:decl-index=0:visual-constraint="10,10"
