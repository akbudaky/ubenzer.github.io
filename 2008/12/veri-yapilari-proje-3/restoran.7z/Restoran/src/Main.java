import java.io.*;
import java.util.*;

public class Main {
	static Tree Restoranlar = new Tree();
	static Hashtable<String, Yemek> Yemekler = new Hashtable<String, Yemek>();
	static Hashtable<String, Vector<String>> Malzemeler = new Hashtable<String, Vector<String>>();
	static Vector<Kategori> Kategoriler = new Vector<Kategori>();
	
	/* Veri yap�lar�n� dosyaya kaydeder. */
	public static int save(String dosyaAdi) {
		/* Kaynak: http://www.javadb.com/writing-objects-to-file-with-objectoutputstream */
		/* Kaynak: Do�an Hoca. (labda anlatt�klar�) */
		ObjectOutputStream outputStream = null;
        
	    try {
			outputStream = new ObjectOutputStream(new FileOutputStream(dosyaAdi));
		    outputStream.writeObject(Restoranlar);
		    outputStream.writeObject(Yemekler);
		    outputStream.writeObject(Malzemeler);
		    outputStream.writeObject(Kategoriler);
		     
		    if (outputStream != null) {
		        outputStream.flush();
		        outputStream.close();
		    }
		} catch (FileNotFoundException e) {
			return -1;
		} catch (IOException e) {
			return -2;
		}
	    
		return 0;
	}
	
	/* Veri yap�lar�n� dosyadan okur (tabi varsa) */
	@SuppressWarnings("unchecked")
	public static int load(String dosyaAdi) {
		/* Kaynak: http://www.javadb.com/reading-objects-from-file-using-objectinputstream */
		/* Kaynak: Do�an Hoca. (labda anlatt�klar�) */
		ObjectInputStream inputStream = null;
        
	    try {
			inputStream = new ObjectInputStream(new FileInputStream(dosyaAdi));
			/* Hangi veriler oldu�unu ve s�ras�n� bildi�imden EOF kontrol�ne gerek yok. */
			Restoranlar = (Tree)inputStream.readObject();
			Yemekler = (Hashtable<String, Yemek>)inputStream.readObject();
			Malzemeler = (Hashtable<String, Vector<String>>)inputStream.readObject();
			Kategoriler = (Vector<Kategori>)inputStream.readObject();
		     
		    if (inputStream != null) {
		        inputStream.close();
		    }
		    
		} catch (FileNotFoundException e) {
			return  -1;
		} catch (IOException e) {
			return -2;
		} catch (ClassNotFoundException e) {
			return -3;
		}
	    
		return 0;
	}
	
	public static String hakkinda() {
		return  "��kmez Bili�im Sistemleri Restoran Ticaret Sanayi Turizm A.�.\n" +
				"��kmez Restoran Takip Sistemi\n" + 
				"S�r�m 1\n\n" +
				"H�seyin YA�AR 05-06-7657\n" +
				"Didem KAYALI  05-06-7669\n" +
				"Umut BENZER   05-06-7670\n" +
				"�zlem G�RSES  05-07-8496\n\n";
	}
	
	public static void main(String[] args) {
		String dosyaAdi = "restoran.cokmezbilisim";
		
		/* Konsol �nit */
		Console c = new Console();
		c.setVisible(true);		

		/* Progrm �nit */
		c.write("Program ba�lat�l�yor...\n" + 
				"Veriler okunurken l�tfen bekleyin...\n" + 
				dosyaAdi + " dosyas� okunuyor...");
		
		switch(load(dosyaAdi)) {
			case -1:
				c.write(dosyaAdi + " dosyas� bulunamad�.\nProgram veriler olmadan ba�layacak.");
				break;
			case -2:
			case -3:
				c.write("Dosya bozuk ya da zarar g�rm��.\n" +
						"Program ge�ersiz bir i�lem y�r�tt� ve kapat�lacak.\n" + 
						"�smimize de o kadar ��kmez Bili�im Sistemleri demi�tik. �ronik oldu.");
				c.beklet();
				System.exit(0);
				break;		
		}
		
		/* DEBUG Restoranlar� Seviyeleriyle Beraber Listeleme */
		System.out.println("DEBUG Restoranlar� Seviyeleriyle Beraber Listeleme");
		for(Restoran x: Restoranlar.inOrder()) {
			System.out.println(x.ad + " " + Restoranlar.depthMeter(x));
		}
		/* END DEBUG */
		
		hakkinda();
		boolean sag_serbest = false;
		boolean sag_serbest_child = false;
		boolean sag_serbest_child_child = false;

		int secenek;
		String secenekS;
	
		while (!sag_serbest) {

	        /* Menu Ba�lang�c� */
			c.write("*** �n misiniz cin mi? ***\n");
			c.write("1. �n");
			c.write("2. Cin");
			c.write("3. Patron");
			c.write("4. Yemek yiyecek yer arayan a� bir insan");
			c.write("5. Merakl� bir kedi");
			c.write("6. Yolunu kaybeden turist\n");
			
			c.write("Karar�n�z� veriniz.");
			/*Men� Bitimi */
			
			secenek = c.readInt("�stedi�iniz se�ene�in numaras�n� yaz�n�z:");
			
			c.cls();
			
			switch(secenek) {
				case 1:
					c.write("�nmi�siniz. Tebrikler. :)");
					c.beklet();
					break;
				
				case 2:
					c.write("Cinmi�siniz. Tebrikler. :)");
					c.beklet();
					break;
				
				case 3:
					sag_serbest_child = false;
					c.write("Bu b�l�me girebilmek i�in yetkili giri�i yapman�z laz�m.");
					String user = "-1";
					user = c.read("Kullan�c� ad�:");
					boolean logged = false;
					
					if(user != null && (user.equalsIgnoreCase("daydin") || user.equalsIgnoreCase("ub") || 
						user.equalsIgnoreCase("huss") || user.equalsIgnoreCase("kayali") || 
						user.equalsIgnoreCase("ozlem"))) {
							logged = true;
					}
						
					if (logged) {
						logged = false;
						String pass = "";
						pass = c.read("Parola:");
						if (pass != null && pass.equals("ant")) {
							logged = true;
						}
					} 
					
					if (!logged) {
						sag_serbest_child = true;
					} else {
						c.cls();
						c.write("Merhaba " + user + "\n");
					}					
					
					while (!sag_serbest_child) {

				        /* Menu Ba�lang�c� */
						c.write("*** �RS Y�netici Men�s� ***\n");
						c.write("1. Restoran ��lemleri");
						c.write("2. Yemek Kategorileri ��lemleri");
						c.write("3. Yemek ��lemleri");
						c.write("4. Yemek Malzemeleri ��lemleri");
						c.write("5. Y�netici ��k���\n");
						
						c.write("Karar�n�z� veriniz.");
						/*Men� Bitimi */
						
						secenek = c.readInt("�stedi�iniz se�ene�in numaras�n� yaz�n�z:");
						
						c.cls();
						
						switch(secenek) {
							case 1:
								
								sag_serbest_child_child = false;
								while (!sag_serbest_child_child) {

							        /* Menu Ba�lang�c� */
									c.write("*** �RS Y�netici Men�s� -> Restoran ��lemleri ***\n");

									c.write("1. Restoran Ekle");
									c.write(" Sisteme yeni bir restoran ekler. Restoran�n ��kard��� \n" +
											" yemek �e�itlerini daha sonra 'Bir Restorana Yeni Yemek �e�idi/�e�itleri Ekle'" +
											" se�ene�ini kullanarak ekleyebilirsiniz.\n");
									
									c.write("2. Bir Restorana Yeni Yemek �e�idi/�e�itleri Ekle");
									c.write(" Sistemde var olan bir restorana yeni yemek �e�idi ekler. \n" +
											" Bu yemek(ler) daha �nceden �RS'de kay�tl� olmal�d�r.\n");									

									c.write("3. Bir Restorandan Yemek �e�idi Sil");
									c.write(" Sistemde var olan bir restorandan bir yemek �e�idi siler.\n");	
									
									c.write("4. Restoran Bilgilerinde D�zenleme Yap");
									c.write(" Sistemde var olan bir restoran�n ad, web adresi ve benzeri bilgilerinde \n" +
											" de�i�iklik yapman�z� sa�lar.\n");									
									
									c.write("5. Yemek Fiyatlar�nda D�zenleme Yap");
									c.write(" Sistemde var olan bir restoranda ��kan yemeklerin fiyatlar�nda\n" +
											" de�i�iklik yapman�z� sa�lar.\n");
																
									c.write("6. Restoran Sil");
									c.write(" Sistemden restoran siler.\n");
									
									c.write("7. �st men�\n");
									c.write("Karar�n�z� veriniz.");
									/*Men� Bitimi */
									
									secenek = c.readInt("�stedi�iniz se�ene�in numaras�n� yaz�n�z:");
									c.cls();
									String restoranAdi, il, adres, telefon, faks, eposta, www, yemekAdi;
									float fiyati;
									switch(secenek) {
										case 1: /* Restoran Ekle */										
											restoranAdi = c.read("Restoran ad�:",false);
											if (restoranAdi.equals("")) {
												c.write("Tamam, eklemek istemiyorsan�z giderim ben.");
												c.beklet();
												c.cls();
												break;												
											}
											
											if (Restoranlar.getRestoran(restoranAdi) != null) {
												c.write("Bu restoran zaten sistemde var.");
												c.beklet();
												c.cls();
												break;
											}
											il = c.read("Bulundu�u �l:",false);
											adres = c.read("Adresi:",false);
											telefon = c.read("Telefon:",false);
											faks = c.read("Faks:",false);
											eposta = c.read("E-Posta:",false);
											www = c.read("WWW:",false);
											YemekR ylist = new YemekR();

											restoran_ekle(restoranAdi, il, adres, telefon, faks, eposta, www, ylist);
											c.write("Restoran sisteme eklendi.");
											c.beklet();
											break;										
										case 2: /* Bir Restorana Yeni Yemek �e�idi/�e�itleri Ekle */						
											restoranAdi = c.read("Restoran ad�:",false);
											if (restoranAdi.equals("")) {
												c.write("Tamam, eklemek istemiyorsan�z giderim ben.");
												c.beklet();
												c.cls();
												break;												
											}
											if (Restoranlar.getRestoran(restoranAdi) == null) {
												c.write("B�yle bir restoran yok.");
												c.beklet();
												c.cls();
												break;
											}
											
											do {
												yemekAdi = c.read("Restorana eklenecek yeme�in ad�:", false);
												
												if(!is_yemek_exists(yemekAdi)) {
													if(!yemekAdi.equals("")) {
														c.write(yemekAdi + " �RS'de kay�tl� de�il. Bir restorana yemek " +
														"ekleyebilmek i�in �nce sisteme kaydetmelisiniz.");
													}
													continue;
												}
												
												if(Restoranlar.getRestoran(restoranAdi).yemekler.hasYemek(yemekAdi)) {
													c.write("Bu yemek zaten restoran�n men�s�nde yer al�yor. �kinci defa " +
															"eklemeniz m�mk�n de�il.");
													continue;
												}
												
												fiyati = 0;
												while(fiyati <= 0) {
													fiyati = c.readFloat("Yeme�in bu restorandaki fiyat�:");
												}
												
												Restoranlar.getRestoran(restoranAdi).yemekler.addYemek(yemekAdi, fiyati);
												
												Yemekler.get(yemekAdi).olduguRestoranlar.add(restoranAdi);
												
												c.write(yemekAdi + " restoran�n men�s�ne eklendi.");
											} while(!yemekAdi.equals(""));
											
											c.write("Yemek ekleme tamamland�.");
											c.beklet();
											c.cls();
											break;
											
										case 3: /* Bir Restorandan Yemek �e�idi Sil */						
											restoranAdi = c.read("Restoran ad�:",false);
											if (restoranAdi.equals("")) {
												c.write("Tamam, giderim ben.");
												c.beklet();
												c.cls();
												break;												
											}
											if (Restoranlar.getRestoran(restoranAdi) == null) {
												c.write("B�yle bir restoran yok.");
												c.beklet();
												c.cls();
												break;
											}
											
											yemekAdi = c.read("Restorandan silinecek yemek �e�idi:", false);												
			
											if(!Restoranlar.getRestoran(restoranAdi).yemekler.hasYemek(yemekAdi)) {
												c.write("Bu restoran bu yeme�i zaten ��karm�yor ya da b�yle bir yemek yok.");
												c.beklet();
												c.cls();
												break;
											}
												
											Restoranlar.getRestoran(restoranAdi).yemekler.removeYemek(yemekAdi);
											Yemekler.get(yemekAdi).olduguRestoranlar.remove(restoranAdi);
												
											c.write(yemekAdi + " art�k bu restoranda ��km�yor.");
											c.beklet();
											c.cls();
											break;
											
										case 4: /* Restoran Bilgilerinde D�zenleme */
											String newRestoranAdi;
											
											c.write("De�i�iklik yapmak istemediklerinizi bo� ge�ebilirsiniz.");
											restoranAdi = c.read("Bilgileri d�zenlenecek restoran ad�:",false);
											if (restoranAdi.equals("")) {
												c.write("Tamam, giderim ben.");
												c.beklet();
												c.cls();
												break;												
											}
											if (Restoranlar.getRestoran(restoranAdi) == null) {
												c.write("B�yle bir restoran yok ki be yav :)");
												c.beklet();
												c.cls();
												break;
											}
											
											newRestoranAdi = c.read("Restoran�n yeni ad�",false);
											if (newRestoranAdi.equals("")) {
												c.write("Tamam, giderim ben.");
												c.beklet();
												c.cls();
												break;												
											}
											if (Restoranlar.getRestoran(newRestoranAdi) != null) {
												c.write("Yeni restoran ad� sistemde zaten var. :'(");
												c.beklet();
												c.cls();
												break;
											}
											
											il = c.read("Bulundu�u �l:",false);
											adres = c.read("Adresi:",false);
											telefon = c.read("Telefon:",false);
											faks = c.read("Faks:",false);
											eposta = c.read("E-Posta:",false);
											www = c.read("WWW:",false);

											restoran_guncelle(restoranAdi, newRestoranAdi, il, adres, telefon, faks, 
													eposta, www);
											c.write("��lem tamam. Afiyet olsun.");
											c.beklet();
											break;
										
										case 5: /* Yemek Fiyatlar�nda D�zenleme Yap */
											
											restoranAdi = c.read("Yemek Fiyatlar� d�zenlenecek restoran ad�:",false);
											if (restoranAdi.equals("")) {
												c.write("Tamam, giderim ben.");
												c.beklet();
												c.cls();
												break;												
											}
											if (Restoranlar.getRestoran(restoranAdi) == null) {
												c.write("B�yle bir restoran yok.");
												c.beklet();
												c.cls();
												break;
											}
											
											yemekAdi = c.read("Fiyat� d�zenlenecek yemek ad�:",false);								
											if(!Restoranlar.getRestoran(restoranAdi).yemekler.hasYemek(yemekAdi)) {
												c.write("Restoranda b�yle bir yemek ��km�yor ya da bo� ge�tiniz.");
												c.beklet();
												c.cls();
												break;
											}

											fiyati = c.readFloat("Yeme�in bu restorandaki yeni fiyat�:");											
											Restoranlar.getRestoran(restoranAdi).yemekler.changeYemek(yemekAdi, fiyati);

											c.write("Fiyat de�i�ikli�i tamam. Yemek hakk�ndaki di�er t�m \n" +
													" yemek de�i�ikliklerini 'Yemek ��lemleri' k�sm�ndan yapabilirsiniz.");
											c.beklet();
											c.cls();
											break;
										
										case 6: /* Restoran Sil */
											restoranAdi = c.read("Silinecek Restoran ad�:",false);
											if (restoranAdi.equals("")) {
												c.write("Tamam, giderim ben.");
												c.beklet();
												c.cls();
												break;												
											}
											if (Restoranlar.getRestoran(restoranAdi) == null) {
												c.write("B�yle bir restoran yok.");
												c.beklet();
												c.cls();
												break;
											}
											
											restoran_sil(restoranAdi);
											c.write("Restoran bizi terk etti.");
											c.beklet();
											break;
											
										case 7: /* ��k�� */
							                 sag_serbest_child_child = true;
							                 break;
											
							            default:
							                /* Elleri yanl�� tu�a basan kullan�c�lar i�in */
							                c.write("Houston houston, hatal� giri� yapt�n�z.");
							                c.beklet();
							                break;									
									}									
								}
								break;
							
							case 2: /* Kategori ��lemleri */
								sag_serbest_child_child = false;
								String kategoriAdi;
								
								while (!sag_serbest_child_child) {

							        /* Menu Ba�lang�c� */
									c.write("*** �RS Y�netici Men�s� -> Yemek Kategorileri ��lemleri ***\n");

									c.write("1. Kategori Ekle");
									c.write(" Sisteme yeni kategori ekler.\n" +
											" (�sterseniz yemek eklerken de yapabilirsiniz.)\n");

									c.write("2. Kategori Yeniden Adland�r");
									c.write(" Bir kategorinin ad�n� de�i�tirmek i�in kullan�l�r.\n");

									c.write("3. Kategorinin Yemeklerini Listele");
									c.write(" Bir kategoride hangi yemeklerin bulundu�unu listeler.\n");
									
									c.write("4. Kategoriyi ve Kategoriye Ait Yemekleri Sil");
									c.write(" Ad� verilen kategori ve ve bu kategoriye ait t�m yemekleri sistemden\n" +
											" kald�r�r.\n");

									c.write("5. �st men�\n");
									c.write("Karar�n�z� veriniz.\n");
									
									c.write("Bilgi: Yemeklerin kategorilerindeki de�i�iklik Yemek ��lemleri k�sm�ndan yap�labilir.");
									/*Men� Bitimi */
									
									secenek = c.readInt("�stedi�iniz se�ene�in numaras�n� yaz�n�z:");
									c.cls();
									
									switch(secenek) {
										case 1: /* Kategori Ekle */
											kategoriAdi = c.read("Kategori ad�:", false);
											if(!kategoriAdi.equals("")) {
												if(kategori_ekle(kategoriAdi)) {
													c.write(kategoriAdi + " eklendi.");
												} else {
													c.write(kategoriAdi + " zaten sisteme kay�tl�ym��.");
												}
												c.beklet();
											} 

											c.cls();
											break;
										
										case 2: /* Kategori Yeniden Adland�r */
											String yeniKategoriAdi;
											kategoriAdi = c.read("Yeniden adland�r�lacak kategori ad�:", false);
											if(!is_kategori_exists(kategoriAdi)) {
												c.write("Sistemde b�yle bir kategori yok ki yeniden adland�ras�n�z...");
												c.beklet();
												break;
											}
											
											yeniKategoriAdi = "";
											while(yeniKategoriAdi.equals("")) {
												yeniKategoriAdi = c.read("Yeni kategori ad�:");
											}
											
											if(is_kategori_exists(yeniKategoriAdi)) {
												c.write("Var olan bir kategoriye adland�ramazs�n�z!");
												c.beklet();
												break;
											}
											/* Ad�m Ad�m Kategori Yeniden Adland�rma
											 * 1. Kategoriyi yeniden adland�r.
											 * 2. Kategorinin t�m yemeklerini gez.
											 * 3. Yemeklerin kategorilerini de adland�r.
										 	*/											
											for(Kategori i : Kategoriler) {
												if (i.kategoriAdi.equals(kategoriAdi)) {
													i.kategoriAdi = yeniKategoriAdi;
													for (String y : i.aitYemekler) {
														if(Yemekler.get(y) != null) {
															Yemekler.get(y).kategorisi = yeniKategoriAdi;
														}														
													}													
												}
											}
												
											c.write("Adland�rma tamam.");
											c.beklet();
											c.cls();
											break;
											
										case 3: /*  Kategorinin Yemeklerini Listele */											
											kategoriAdi = c.read("Kategori ad�:", false);
											if(!is_kategori_exists(kategoriAdi)) {
												c.write("B�yle bir kategori yok ki.");
												c.beklet();
												break;
											}
											
											for (Kategori i: Kategoriler) {
												if(i.kategoriAdi.equalsIgnoreCase(kategoriAdi)) {
													for (String x: i.aitYemekler) {
														c.write(x);
													}
												}												
											}
											
											c.beklet();
											c.cls();
											break;
											
										case 4: /* Kategoriyi ve Kategoriye Ait Yemekleri Sil */
											kategoriAdi = c.read("Kategori ad�:", false);
											if(!is_kategori_exists(kategoriAdi)) {
												c.write("B�yle bir kategori yok ki.");
												c.beklet();
												break;
											}
											
											kategori_sil(kategoriAdi);
											c.write("��lem tamam.");
											c.beklet();
											break;
										
										case 5: /* �st Men� */
							                 sag_serbest_child_child = true;
							                 break;											
							            default:
							                /* Elleri yanl�� tu�a basan kullan�c�lar i�in */
							                c.write("Houston houston, hatal� giri� yapt�n�z.");
							                c.beklet();
							                break;				
									}
									
								}
								break;

							
							case 3: /* Yemek ��lemleri */
								sag_serbest_child_child = false;
								while (!sag_serbest_child_child) {

							        /* Menu Ba�lang�c� */
									c.write("*** �RS Y�netici Men�s� -> Yemek ��lemleri ***\n");

									c.write("1. Yemek Ekle");
									c.write(" Sisteme yeni yemek ekler. Bir yeme�i bir defa sisteme ekledikten sonra\n" +
											" restoranlar bu yeme�i kendi men�lerine ekleyebilir. E�er yeme�i ilave\n" +
											" etmek istedi�iniz kategori sistemde yoksa otomatik yarat�lacakt�r.\n" +
											" Yeme�i bir defa sisteme ekledikten sonra Yeme�e Malzeme Ekle se�ene�i ile\n" +
											" yeme�in i�inde neler oldu�unu sisteme giriniz.\n");

									c.write("2. Yemek Bilgilerini D�zenle");
									c.write(" Sistemde var olan bir yeme�in ad� ve di�er bilgilerini de�i�tirmek i�in\n" +
											" bu k�sm� kullanabilirsiniz.\n");
									
									c.write("3. Yeme�e Malzeme Ekle");
									c.write(" Yeme�in yap�m�nda yeni bir malzeme kullan�lmaya ba�land�ysa buradan\n" +
											" yeme�e ilave edebilirsiniz. Yeme�e ilave edece�iniz malzeme daha �nce\n" +
											" sistemde kay�tl� olmal�d�r.\n");
									
									c.write("4. Yeme�in ��indeki Malzemelere Bak");
									c.write(" Ad� verilen yeme�in i�inde hangi malzemelerin kullan�ld���n� g�sterir.\n");
									
									c.write("5. Yeme�in ��kt��� Restoranlara Bak");
									c.write(" Ad� verilen yeme�in hangi restoranlarda ��kt���n� g�sterir.\n");
									
									c.write("6. Yemekten Malzeme Sil");
									c.write(" Yeme�in i�eri�inden bir malzeme kald�rmak i�in gerekli i�lem buradan yap�lmal�d�r.\n");										

									c.write("7. Yemek Sil");
									c.write(" Sistemden bir yemek silinir.\n");		
									
									c.write("8. �st men�\n");
									c.write("Karar�n�z� veriniz.");
									/*Men� Bitimi */
									
									secenek = c.readInt("�stedi�iniz se�ene�in numaras�n� yaz�n�z:");
									c.cls();
									String yemekAdi, malzemeAdi;
									Yemek yemek = null;
									
									switch(secenek) {
										case 1: /* Yemek Ekle */
											
											String ekBilgi, kategorisi;
											
											yemekAdi = c.read("Yemek ad�:", false);
											if(yemekAdi.equals("") || is_yemek_exists(yemekAdi)) {
												c.write(((yemekAdi.equals("")) ? "Bo�luk ge�erli bir yemek de�il." : yemekAdi + " sistemde zaten var."));
												c.beklet();
												break;
											}
											
											ekBilgi = c.read("Ek bilgi: ",false);
											
											kategorisi = "";
											while(kategorisi.equals("")) {
												kategorisi = c.read("Yeme�in kategorisi: ",false);
											}
											
											if(is_kategori_exists(kategorisi)) {
												c.write(yemekAdi + " zaten var olan " + kategorisi + " kategorisine eklenecek.");
											} else {
												kategori_ekle(kategorisi);
												c.write(kategorisi + " kategorisi yok. Yeni yarat�ld�.");
											}
											
											for(Kategori i : Kategoriler) {
												if (i.kategoriAdi.equals(kategorisi)) {
													if (!i.aitYemekler.contains(yemekAdi)) {
														i.aitYemekler.add(yemekAdi);
													}													
												}
											}
											yemek_ekle(yemekAdi, ekBilgi, new Vector<String>(), kategorisi, new Vector<String>());

											c.write("Yemek sisteme eklendi. :)");
											c.beklet();
											break;
										
										case 2: /* Yemek Bilgilerini D�zenle */
											
											String newYemekAdi;
											c.write("De�i�tirmek istemediklerinizi bo� ge�ebilirsiniz.");
											yemekAdi = c.read("D�zenlenecek yemek ad�:", false);
											if(!is_yemek_exists(yemekAdi)) {
												c.write("B�yle bir yemek yok ama. Everybody lies. House MD.");
												c.beklet();
												break;
											}
											
											newYemekAdi = c.read("Yeme�in yeni ad�:", false);
											if(is_yemek_exists(newYemekAdi)) {
												c.write("Yeni yemek ad� zaten sistemde var.");
												c.beklet();
												break;
											}
											
											ekBilgi = c.read("Yeni ek bilgi: ",false);											
											kategorisi = c.read("Yeme�in yeni kategorisi: ",false);
											
											if(!kategorisi.equals("")) {
												if(!is_kategori_exists(kategorisi)) {					
													kategori_ekle(kategorisi);
													c.write(kategorisi + " kategorisi yok. Yeni yarat�ld�.");
												}			
											}
											
											yemek_duzenle(yemekAdi, newYemekAdi, ekBilgi, kategorisi);

											c.write("De�i�iklik tamam. :)");
											c.beklet();
											break;
										case 3: /* Yeme�e Malzeme Ekle */
											 
											yemekAdi = c.read("Malzemeler hangi yeme�e eklenecek?",false);
											if(!is_yemek_exists(yemekAdi)) {
												 c.write("B�yle bir yemek yok!");
												 c.beklet();
												 break;
											}
											
											yemek = Yemekler.get(yemekAdi);
											
											malzemeAdi = c.read("Malzeme ad�:", false);
											while(!malzemeAdi.equals("")) {
												
												if(!yemek.icindekiMalzemeler.contains(malzemeAdi)) {
													yemek.icindekiMalzemeler.add(malzemeAdi);
													c.write(yemekAdi + " art�k " + malzemeAdi + " i�eriyor!");
												} else {
													c.write(yemekAdi + " zaten " + malzemeAdi + " i�eriyordu!");
												}
												
												if(malzeme_ekle(malzemeAdi)) {
													c.write("Bilgi: " + malzemeAdi + " sisteme de eklendi.");
												}
												
												if(!Malzemeler.get(malzemeAdi).contains(yemekAdi)) {
													Malzemeler.get(malzemeAdi).add(yemekAdi);
												}
												malzemeAdi = c.read("Malzeme ad�:", false);
											}	 
											
											c.cls();
							                break;
							                 
										case 4: /* Yeme�in ��indeki Malzemelere Bak */											
											yemekAdi = c.read("Hangi yeme�in malzemelerine bak�lacak?",false);
											if(!is_yemek_exists(yemekAdi)) {
												 c.write("Er�r: B�yle bir yemek yok!");
												 c.beklet();
												 break;
											}
											
											yemek = Yemekler.get(yemekAdi);											
											for(String y :yemek.icindekiMalzemeler) {
												c.write(y);
											}	 
											
											c.beklet();
											c.cls();
							                break;
							                
										case 5: /* Yeme�in Restoranlar�na Bak */											
											yemekAdi = c.read("Hangi yeme�in restoranlar�na bak�lacak?",false);
											if(!is_yemek_exists(yemekAdi)) {
												 c.write("Er�r: B�yle bir yemek yok!");
												 c.beklet();
												 break;
											}
											
											yemek = Yemekler.get(yemekAdi);											
											for(String y :yemek.olduguRestoranlar) {
												c.write(y);
											}	 
											
											c.beklet();
											c.cls();
							                break;
							                
										case 6: /* Yemekten Malzeme Sil */
											
											yemekAdi = c.read("Hangi yemekten malzeme ��kar�lacak?",false);
											if(!is_yemek_exists(yemekAdi)) {
												 c.write("B�yle bir yemek yok!");
												 c.beklet();
												 break;
											} 
											
											yemek = Yemekler.get(yemekAdi);
											
											malzemeAdi = c.read("Malzeme ad�:", false);
											
											if(!yemek.icindekiMalzemeler.contains(malzemeAdi)) {
												c.write(yemekAdi + " zaten bu malzemeyi i�ermiyordu ki. :)");
												c.beklet();
												break;
											}
											
											yemek.icindekiMalzemeler.remove(malzemeAdi);
											
											if(Malzemeler.get(malzemeAdi) != null) {
												if(Malzemeler.get(malzemeAdi).contains(yemekAdi)) {
													Malzemeler.get(malzemeAdi).remove(yemekAdi);
												}
											}
											
											c.write("��lem tamam.");
											c.beklet();
											c.cls();
											break;
										
										case 7: /* Yemek Sil */
											yemekAdi = c.read("Hangi yemek silinecek?",false);
											if(!is_yemek_exists(yemekAdi)) {
												 c.write("B�yle bir yemek yok!");
												 c.beklet();
												 break;
											} 
											
											yemek_sil(yemekAdi);
											c.write("D�nyada bu yemek yasakland�.");
											c.beklet();
											break;
										case 8: /* �st men� */
							                 sag_serbest_child_child = true;
							                 break;
							                 
							            default:
							                /* Elleri yanl�� tu�a basan kullan�c�lar i�in */
							                c.write("Houston houston, hatal� giri� yapt�n�z.");
							                c.beklet();
							                break;				
									}
									
								}
								break;
							
							case 4: /* Yemek Malzemeleri ��lemleri */
								sag_serbest_child_child = false;
								String malzemeAdi;
								
								while (!sag_serbest_child_child) {

							        /* Menu Ba�lang�c� */
									c.write("*** �RS Y�netici Men�s� -> Yemek Malzemeleri ��lemleri ***\n");

									c.write("1. Malzeme Ekle");
									c.write(" Sisteme yemeklerde kullan�labilecek yen bir malzeme ekler.\n" +
											" (Pirin�, muz, tuz, biber vs.)\n");

									c.write("2. Yemek Listesi");
									c.write(" Ad� verilen malzemenin hangi yemeklerde oldu�unu bulur.\n");
									
									c.write("3. �st men�\n");
									c.write("Karar�n�z� veriniz.");
									/*Men� Bitimi */
									
									secenek = c.readInt("�stedi�iniz se�ene�in numaras�n� yaz�n�z:");
									c.cls();
									
									switch(secenek) {
										case 1: /* Malzeme Ekle */
											malzemeAdi = c.read("Malzeme ad�:", false);
											while(!malzemeAdi.equals("")) {
												if(malzeme_ekle(malzemeAdi)) {
													c.write(malzemeAdi + " eklendi.");
												} else {
													c.write(malzemeAdi + " zaten sisteme kay�tl�ym��.");
												}
												malzemeAdi = c.read("Malzeme ad�:", false);
											}
											
											c.cls();
											break;
										
										case 2: /* Malzeme Listesi */
											malzemeAdi = c.read("Malzeme ad�:", false);
											if(Malzemeler.get(malzemeAdi) == null) {
												c.write("Sistemde b�yle bir malzeme yok.");
												c.beklet();
												break;
											}
											
											for(String y : Malzemeler.get(malzemeAdi)) {
												c.write(y);
											}
											
											c.write("Listeleme tamam.");
											c.beklet();
											c.cls();
											break;
											
										case 3: /* �st Men� */

							                 sag_serbest_child_child = true;
							                 break;
											
							            default:
							                /* Elleri yanl�� tu�a basan kullan�c�lar i�in */
							                c.write("Houston houston, hatal� giri� yapt�n�z.");
							                c.beklet();
							                break;				
									}
									
								}
								break;
							
							case 5: /* Y�netici ��k��� */
				                do {
				                    c.write("Y�netici alan�ndan ��kmak istedi�inizden emin misiniz? (E/H) ");
				                    secenekS = c.read("Y�netici alan�ndan ��kmak istedi�inizden emin misiniz? (E/H) ");
				                    if (secenekS.equalsIgnoreCase("E")) {
				                        sag_serbest_child = true;
				                        secenekS = "H";
				                    }
				                } while (!secenekS.equalsIgnoreCase("H"));
				                c.cls();
				                break;
								
				            default:
				                /* Elleri yanl�� tu�a basan kullan�c�lar i�in */
				                c.write("Houston houston, hatal� giri� yapt�n�z.");
				                c.beklet();
				                break;				
						
						}
						
					}
					
					break;
				
				case 4: /* Ziyaret�i k�sm� alt men�s� */
					
					sag_serbest_child = false;
					while (!sag_serbest_child) {

				        /* Menu Ba�lang�c� */
						c.write("*** �RS M��teri Men�s� ***\n");
						c.write("1. Ad�na g�re restoran arama");
						c.write("2. Ad� verilen bir yeme�i ��karan restoranlar� arama");
						c.write("3. Belirli fiyat aral�klar�na g�re yemek arama");
						c.write("4. ��indeki malzemeye g�re yemek arama");
						c.write("5. Bir ildeki t�m restoranlar� listeleme");
						c.write("6. �st men�\n");
						
						c.write("Karar�n�z� veriniz.");
						/*Men� Bitimi */
						
						secenek = c.readInt("�stedi�iniz se�ene�in numaras�n� yaz�n�z:");						
						c.cls();
						Vector<Restoran> rest;
						switch(secenek) {
							case 1: /* Ad�na g�re restoran arama */
								String restoranAdi;
								
								c.write("Powered by Google.");
								restoranAdi = c.read("Restoran ad�:",false);
								Restoran bulundu = Restoranlar.getRestoran(restoranAdi);
								if (bulundu == null) {
									c.write("Ne yaz�k ki ad�n� verdi�iniz restoran para verip sistemimize kaydolmam��.\n" +
											"Kendileri kaybederler.");
									c.beklet();
									c.cls();
									break;
								}
								c.cls();
								
								c.write("Restoran Ad�: " + bulundu.ad);
								c.write("Bulundu�u �ehir: " + bulundu.il);
								c.write("Adres: " + bulundu.adres);
								c.write("Telefon: " + bulundu.telefon);
								c.write("Belgege�er:" + bulundu.faks);
								c.write("E-posta: " + bulundu.eposta);
								c.write("WWW: " + bulundu.www);
								
								c.write("\n*** M�n� ***\n");
								for(YemekRYapi i : bulundu.yemekler.yemekList) {
									c.write(i.yemekAdi + "\t\t" + i.fiyati + "\t\t" + (Yemekler.get(i.yemekAdi) != null ? Yemekler.get(i.yemekAdi).kategorisi : ""));
								}
								
								c.beklet();
								break;
							case 2:	/* Ad� verilen bir yeme�i ��karan restoranlar� arama */
								String yemekAdi;
								
								c.write("Powered by Google.");
								yemekAdi = c.read("Aranan yeme�in ad�:",false);
								if(!is_yemek_exists(yemekAdi)) {
									c.write("Sistemimize b�yle bir yemek kay�tl� de�ildir.");
									c.beklet();
									break;
								}
								
								rest = Restoranlar.preOrder();
								for(Restoran x: rest) {
									if(x.yemekler.hasYemek(yemekAdi)) {
										c.write("Restoran Ad�: " + x.ad);
										c.write("Bulundu�u �ehir: " + x.il);
										c.write("Adres: " + x.adres);
										c.write("Telefon: " + x.telefon);
										c.write("Belgege�er:" + x.faks);
										c.write("E-posta: " + x.eposta);
										c.write("WWW: " + x.www);
										c.write("Restorandaki Fiyat�: " + x.yemekler.getYemekFiyati(yemekAdi));
										c.beklet();
										c.cls();
									}
								}								

								c.write("Arama tamam.");
								c.beklet();
								c.cls();
								break;

							case 3:	/* Belirli fiyat aral�klar�na g�re yemek arama */
								float altF, ustF;
								c.write("Powered by Gug�l.");
								altF = c.readFloat("Fiyat alt limiti:");
								ustF = c.readFloat("Fiyat �st limiti:");
								if(altF < 0 || ustF < 0 || altF >= ustF) {
									c.write("Sintaks er�r.");
									c.beklet();
									break;
								}
								
								rest = Restoranlar.preOrder();
								YemekR yemek = null;
								for(Restoran x: rest) {
									yemek = x.yemekler.yemekFiltre(altF, ustF);
									for(YemekRYapi b: yemek.yemekList) {
										c.write("Yemek Ad�: " + b.yemekAdi);
										c.write(x.ad + " isimli restoranda " + b.fiyati + "YTL'ye yenilebilir.");
										c.beklet();
										c.cls();	
									}									
								}									
								
								c.write("Arama tamamland�.");
								c.beklet();
								break;
							case 4:	/* ��indeki malzemeye g�re yemek arama */
								String malzemeAdi;								
								c.write("Powered by Aybars U�ur\n");
								
								malzemeAdi = c.read("Hangi malzemeyi i�eren yemekler ve restoranlar?", false);
								if(Malzemeler.get(malzemeAdi) == null) {
									c.write("Sistemde b�yle bir malzeme yok.");
									c.beklet();
									break;
								}
								
								c.write("*** Oldu�u yemek Listesi *** \n");
								for(String a: Malzemeler.get(malzemeAdi)) {
									c.write("Yemek ad�:" + a);
									c.write("Bu yemek a�a��daki restoranlarda ��kar: ");
									if(Yemekler.get(a) != null) {
										for(String b : Yemekler.get(a).olduguRestoranlar) {
											c.write(b);										
										}										
									}									
									c.beklet();									
								}
								
								c.write("Arama tamamland�.");
								c.beklet();
								break;
							case 5:	/* Bir ildeki t�m restoranlar� listeleme */
								String il;
								
								c.write("Powered by Google.\n");
								il = c.read("Hangi ilin restoranlar�?",false);
								rest = Restoranlar.preOrder();
								
								for(Restoran x: rest) {
									if(x.il.equalsIgnoreCase(il)) {
										c.write("Restoran Ad�: " + x.ad);
										c.write("Bulundu�u �ehir: " + x.il);
										c.write("Adres: " + x.adres);
										c.write("Telefon: " + x.telefon);
										c.write("Belgege�er:" + x.faks);
										c.write("E-posta: " + x.eposta);
										c.write("WWW: " + x.www);
										
										c.write("\n*** M�n� ***\n");
										for(YemekRYapi i : x.yemekler.yemekList) {
											c.write(i.yemekAdi + "\t\t" + i.fiyati + "\t\t" + (Yemekler.get(i.yemekAdi) != null ? Yemekler.get(i.yemekAdi).kategorisi : ""));
										}
										
										c.beklet();
										c.cls();
									}									
								}

								c.write("Arama tamamland�.");
								c.beklet();
								c.cls();
							case 6: /* �st Men� */
				                 sag_serbest_child = true;
				                 break;								
				            default:
				                /* Elleri yanl�� tu�a basan kullan�c�lar i�in */
				                c.write("Houston houston, hatal� giri� yapt�n�z.");
				                c.beklet();
				                break;
						}
					}
					break;
				
				case 5:
					c.write(hakkinda());
					c.beklet();
					break;
					
				case 6: /* ��k�� */
	                do {
	                    c.write("Cidden ��kmak istiyor musunuz? (E/H) ");
	                    secenekS = c.read("Cidden ��kmak istiyor musunuz? (E/H) ");
	                    if (secenekS.equalsIgnoreCase("E")) {
	                        sag_serbest = true;
	                        secenekS = "H";
	                    }
	                } while (!secenekS.equalsIgnoreCase("H"));
	                c.cls();
	                break;
					
	            default:
	                /* Elleri yanl�� tu�a basan kullan�c�lar i�in */
	                c.write("Houston houston, hatal� giri� yapt�n�z.");
	                c.beklet();
	                break;				
			
			}
			
		}
		
		switch(save(dosyaAdi)) {
			case -1:
			case -2:
				c.write("Dosyaya yazmada bir s�k�nt� olu�tu.\n" +
						"Program verileri dosyaya yazmadan kapanacak.\n" + 
						"�smimize de o kadar ��kmez Bili�im Sistemleri demi�tik." +
						"�ronik oldu.");
				break;
			case 0:
				c.write("Sistemdeki t�m bilgiler " + dosyaAdi + " dosyas�na kaydedildi.");
				c.write("Program� bir sonraki a����n�zda kald���n�z yerden devam edebilirsiniz.");
				break;
		}

		c.write("�RS iyi g�nler diler...");
		c.beklet();	
		System.exit(0);
	}
	
	/* Restoran ��lemleri */
		
	/* Restoran bilgilerini ekler. Restoran �nceden varsa FALSE, restoran eklendiyse TRUE d�nd�r�r. */
	public static boolean restoran_ekle(String restoranAdi, String il, String adres, String telefon,
			String faks, String eposta, String www, YemekR yemekler) {
		
		if (Restoranlar.getRestoran(restoranAdi) == null) {
			Restoranlar.addRestoran(new Restoran(restoranAdi, il, adres, telefon,
					faks, eposta, www, yemekler));
			return true;
		}
		
		return false;
	}

	/* Restoran bilgilerini g�nceller. Restoran yoksa FALSE bilgiler g�ncellenirse TRUE d�nd�r�r. */
	public static boolean restoran_guncelle(String oldRestoranAdi, String newRestoranAdi, String newIl, 
			String newAdres, String newTelefon, String newFaks, String newEposta, String newWWW) {
	
		Restoran degisiklikYapilacak = Restoranlar.getRestoran(oldRestoranAdi);
		if (degisiklikYapilacak == null) return false;
		
		/* Restoran ad� de�i�tiyse a�a�ta da oynama yap�laca�� i�in iki ad�mda g�ncelleme yap�l�r. */
		if (newRestoranAdi == null || oldRestoranAdi.equalsIgnoreCase(newRestoranAdi) 
				|| newRestoranAdi.equals("")) {
			
			if (newIl != null && !newIl.equals("")) {
				degisiklikYapilacak.il = newIl;
			}
			
			if (newAdres != null && !newAdres.equals("")) {
				degisiklikYapilacak.adres = newAdres;
			}		

			if (newTelefon != null && !newTelefon.equals("")) {
				degisiklikYapilacak.telefon = newTelefon;
			}
			
			if (newFaks != null && !newFaks.equals("")) {
				degisiklikYapilacak.faks = newFaks;
			}
			
			if (newEposta != null && !newEposta.equals("")) {
				degisiklikYapilacak.eposta = newEposta;
			}
			
			if (newWWW != null && !newWWW.equals("")) {
				degisiklikYapilacak.www = newWWW;
			}
		} else {
			/* Restoran Ad� G�ncelleme Prosed�r�:
			 * 1. Restoran ad� de�i�ince a�ac� tekrar ayarla.
			 * 2. Yemek hash tablosunda yemeklerin bulunduklar�
			 * restoranlar k�sm�nda restoran�n ad�n� de�i�tir.
			 * 3. Bu kadar.
			 */
			Restoranlar.removeRestoran(oldRestoranAdi);
			degisiklikYapilacak.ad = newRestoranAdi;
			Restoranlar.addRestoran(degisiklikYapilacak);
			for(YemekRYapi i : degisiklikYapilacak.yemekler.yemekList) {
				Yemek x = Yemekler.get(i.yemekAdi);
				if(x != null) {
					for(String y :x.olduguRestoranlar) {
						if(y.equalsIgnoreCase(oldRestoranAdi)) {
							y = newRestoranAdi;
							break;
						}
					}					
				}
			}
			
			return restoran_guncelle(newRestoranAdi, null, newIl, newAdres, newTelefon,
					newFaks, newEposta,newWWW);
		}
		
		return true;
	}
	
	/* Restoran� siler. Restoran yoksa FALSE, ba�ar�yla silindiyse TRUE d�nd�r�r. */
	public static boolean restoran_sil(String restoranAdi) {
		/* Restoran Silme Prosed�r�:
		 * 1. Yemek Hashtableden restoran ad� silinir.
		 * 2. A�a�tan restoran silinir.
		 * 3. Bu kadar.
		 */
		Restoran silinecek = Restoranlar.getRestoran(restoranAdi);
		if (silinecek == null) return false;
		
		for(YemekRYapi i : silinecek.yemekler.yemekList) {
			Yemek x = Yemekler.get(i.yemekAdi);
			if(x != null) {
				for(String y :x.olduguRestoranlar) {
					if(y.equalsIgnoreCase(restoranAdi)) {
						x.olduguRestoranlar.remove(y);
						break;
					}
				}					
			}
		}
		
		Restoranlar.removeRestoran(restoranAdi);
		return true;
	}

	/* Sisteme kategori ekler. E�er kategori zaten varsa FALSE, eklenirse TRUE d�nd�r�r. */
	public static boolean kategori_ekle(String kategoriAdi) {
		if (is_kategori_exists(kategoriAdi)) {
			return false;
		}
		Kategoriler.add(new Kategori(kategoriAdi, new Vector<String>()));
		return true;
	}

	/* Kategorinin sistemde olup olmad���n� d�nd�r�r. */
	public static boolean is_kategori_exists(String kategoriAdi) {
		for (Kategori i : Kategoriler) {
			if(i.kategoriAdi.equals(kategoriAdi)) {
				return true;
			}
		}		
		return false;
	}
	
	/* Kategori ��lemleri */

	public static boolean kategori_sil(String kategoriAdi) {
		
		if (!is_kategori_exists(kategoriAdi)) {
			return false;
		}
		Vector<String> silinecekYemek = null;
		Kategori silinecek = null;
		for(Kategori i:Kategoriler) {
			if(i.kategoriAdi.equalsIgnoreCase(kategoriAdi)) {
				silinecekYemek = i.getYemek(kategoriAdi);
				silinecek = i;
				break;
			}			
		}
		
		if (silinecekYemek == null) {
			return false;
		}
		
		for(String y: silinecekYemek) {
			yemek_sil(y);
		}
		/* Kategoriye ait yemekler silinir. */

		Kategoriler.remove(silinecek);
		
		return false;
	}
	
	/* Malzeme ��lemleri */
	public static boolean malzeme_ekle(String malzemeAdi) {
		if (Malzemeler.get(malzemeAdi) != null) {
			return false;
		}
		Malzemeler.put(malzemeAdi, new Vector<String>());
		return true;
	}	
	
	/* Malzeme ismi de�i�tirme ve malzeme silme i�lemleri �dev kapsam�nda
	 * istenmedi�inden projede yer almamaktad�r.
	 */
	
	/* Yemek ��lemleri */
	public static boolean yemek_duzenle(String oldYemekAdi, String newYemekAdi, String newEkBilgi, String newKategorisi) {
		if(!is_yemek_exists(oldYemekAdi)) {
			return false;
		}
		
		Yemek degisiklik = Yemekler.get(oldYemekAdi);

		/* �simde de�i�iklik yok */
		if (newYemekAdi == null || oldYemekAdi.equalsIgnoreCase(newYemekAdi) 
				|| newYemekAdi.equals("")) {
			
			if (newEkBilgi != null && !newEkBilgi.equals("")) {
				degisiklik.ekBilgi = newEkBilgi;
			}
			
			if (newKategorisi != null && !newKategorisi.equals("")) {
				degisiklik.kategorisi = newKategorisi;
			
				for(Kategori i: Kategoriler) {
					if(i.kategoriAdi.equals(degisiklik.kategorisi)) {
						if(i.aitYemekler.contains(oldYemekAdi)) {
							i.aitYemekler.remove(oldYemekAdi);
						}
					}
					
					if(i.kategoriAdi.equals(newKategorisi)) {
						if(!i.aitYemekler.contains(oldYemekAdi)) {
							i.aitYemekler.add(oldYemekAdi);
						}
					}				
				}
			}
			

		} else {
			Yemekler.remove(oldYemekAdi);
			Yemekler.put(newYemekAdi, degisiklik);
			
			Vector<Restoran> a = Restoranlar.preOrder();
			for(Restoran b: a) {
				b.yemekler.changeYemek(oldYemekAdi, newYemekAdi);
			}
			
			for(Kategori i: Kategoriler) {
				if(i.kategoriAdi.equals(degisiklik.kategorisi)) {
					if(i.aitYemekler.contains(oldYemekAdi)) {
						i.aitYemekler.remove(oldYemekAdi);
						i.aitYemekler.add(newYemekAdi);
						break;
					}
				}			
			}
			
			for(String i: degisiklik.icindekiMalzemeler) {
				if(Malzemeler.get(i) != null) {
					if(Malzemeler.get(i).contains(oldYemekAdi)) {
						Malzemeler.get(i).remove(oldYemekAdi);
						Malzemeler.get(i).add(newYemekAdi);
					}						
				}			
			}
			return yemek_duzenle(newYemekAdi, null, newEkBilgi, newKategorisi);
		}		
		return true;	
	}
	
	public static boolean yemek_ekle(String yemekAdi, String ekBilgi, Vector<String> olduguRestoranlar, 
			String kategorisi, Vector<String> icindekiMalzemeler) {
	
		if(is_yemek_exists(yemekAdi)) {
			return false;
		}
		
		Yemekler.put(yemekAdi, new Yemek(ekBilgi,kategorisi, icindekiMalzemeler, olduguRestoranlar));
		return true;		
	}
	
	public static boolean yemek_sil(String yemekAdi) {
		if(!is_yemek_exists(yemekAdi)) {
			return false;
		}
		
		Yemek silinecek = Yemekler.get(yemekAdi);
		for(String i: silinecek.icindekiMalzemeler) {
			if(Malzemeler.get(i) != null) {
				Malzemeler.get(i).remove(yemekAdi);
			}
		}
		for(String i: silinecek.olduguRestoranlar) {
			if(Restoranlar.getRestoran(i) != null) {
				Restoranlar.getRestoran(i).yemekler.removeYemek(yemekAdi);
			}
		}	
		for(Kategori i: Kategoriler) {
			if(i.kategoriAdi.equals(silinecek.kategorisi)) {
				if(i.aitYemekler.contains(yemekAdi)) {
					i.aitYemekler.remove(yemekAdi);
				}
			}		
		}
		Yemekler.remove(yemekAdi);
		return true;		
	}
	
	public static boolean is_yemek_exists(String yemekAdi) {
		if (Yemekler.get(yemekAdi) != null) {
			return true;
		}
		return false;
	}

}