import java.io.Serializable;

public class YemekRYapi implements Serializable {
	private static final long serialVersionUID = 6604357498353361559L;
	public String yemekAdi;
	public float fiyati;
	
	public YemekRYapi(String yemekAdi, float fiyati) {
		this.yemekAdi = yemekAdi;
		this.fiyati = fiyati;
	}
}
