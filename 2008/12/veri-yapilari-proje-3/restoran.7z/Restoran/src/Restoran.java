import java.io.Serializable;

public class Restoran implements Serializable {
	private static final long serialVersionUID = 3691088602217859963L;
	/* A�a� H�d�leri */
	public Restoran leftChild;
	public Restoran rightChild;
	   
	/* Gerekli Bilgiler */
	public String ad;
	public String il;
	public String adres;
	public String telefon;
	public String faks;
	public String eposta;
	public String www;
	public YemekR yemekler;
	
	public Restoran (String ad, String il, String adres, String telefon, String faks,
			String eposta, String www,YemekR yemekler) {

		this.ad = ad;
		this.il = il;
		this.adres = adres;
		this.telefon = telefon;
		this.faks = faks;
		this.eposta = eposta;
		this.www = www;
		
		if (yemekler == null) {
			this.yemekler = new YemekR();
		} else {
			this.yemekler = yemekler;
		}
		
	}

}