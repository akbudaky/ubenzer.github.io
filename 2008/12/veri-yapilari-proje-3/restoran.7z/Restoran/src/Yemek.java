import java.io.Serializable;
import java.util.*;

public class Yemek implements Serializable {
	private static final long serialVersionUID = -5233500000353592564L;
	public String ekBilgi;
	public String kategorisi;
	Vector<String> icindekiMalzemeler = new Vector<String>();
	Vector<String> olduguRestoranlar = new Vector<String>();
	
	public Yemek(String ekBilgi, String kategorisi,
			Vector<String> icindekiMalzemeler, Vector<String> olduguRestoranlar) {
		this.ekBilgi = ekBilgi;
		this.kategorisi = kategorisi;
		this.icindekiMalzemeler = icindekiMalzemeler;
		this.olduguRestoranlar = olduguRestoranlar;
	}
}
