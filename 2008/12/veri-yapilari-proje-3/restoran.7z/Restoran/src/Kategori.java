import java.io.Serializable;
import java.util.Vector;

public class Kategori implements Serializable {

	private static final long serialVersionUID = 6860809380021603294L;
	String kategoriAdi;
	Vector<String> aitYemekler;
	
	public Kategori(String kategoriAdi, Vector<String> aitYemekler) {
		this.kategoriAdi = kategoriAdi;
		this.aitYemekler = aitYemekler;
	}
	
	@SuppressWarnings("unchecked")
	public Vector<String> getYemek(String kategoriAdi) {
		return (Vector<String>) aitYemekler.clone();
	}
}
