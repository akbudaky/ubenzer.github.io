/* class IMKB
 * Authors: Umut Benzer, �zlem G�rses, H�seyin Ya�ar, Didem Kayal�
 * 
 */

public class IMKB {
	/* function main 
	 * Author: Umut Benzer
	 */
	public static void main(String[] args) {

		System.out.println("��kmez Bili�im Sistemleri Gururla Sunar :)\n"
				+ "Veri Yap�lar� Proje 1.2\n" + "IMKB Endeks 0.2\n\n"
				+ "05-06-7657  H�seyin YA�AR\n" + "05-06-7669  Didem KAYALI\n"
				+ "05-06-7670  Umut BENZER\n" + "05-07-8496  �zlem G�RSES\n\n");

		int ay = 1;
		float toplamIMKBDeger = 0;
		int toplamIMKBSayi = 0;
		float gecenAyIMKBDeger = deger(0);

		int oncekiIMKBSeans = 0;

		/* En y�ksek �� de�erin ve seans numaralar�n�n tutulaca�� yap�. */
		float IMKBEnYuksekDeger[] = { -1, -1, -1 };
		int IMKBEnYuksekSeans[] = { -1, -1, -1 };

		/* En d���k �� de�erin ve seans numaralar�n�n tutulaca�� yap�. */
		float IMKBEnDusukDeger[] = { -1, -1, -1 };
		int IMKBEnDusukSeans[] = { -1, -1, -1 };

		for (int sayac = 1; sayac <= 730; sayac++) {
			/*
			 * Bu y�l�n her seans� i�in i�lem tekrarlan�r.
			 */

			if (deger(sayac) != -1) { /* E�er tatil g�n�ne denk gelmediysek */

				/* Her seans i�in de�i�im fark� bulunup ekrana yazd�r�l�r */
				System.out
						.println(((oncekiIMKBSeans == 0) ? "Bir �nceki y�l�n son g�n� "
								: hangiAy(oncekiIMKBSeans) + ". ay�n "
										+ hangiGun(oncekiIMKBSeans) + ". g�n� ")
								+ ((sayac % 2 == 0) ? "1" : "2")
								+ ". seans ile "
								+ hangiAy(sayac)
								+ ".ay�n "
								+ hangiGun(sayac)
								+ ". g�n� "
								+ ((sayac % 2 == 0) ? "2" : "1")
								+ ". seans� aras� de�i�im oran�: "
								+ degisimOrani(deger(oncekiIMKBSeans), deger(sayac))
								+ "%");

				/*
				 * De�i�im oranlar�n� hesaplarken tatil g�nlerinde hata olmamas�
				 * i�in bir �nceki seans�n de�eri bu de�i�kende tutulur.
				 */
				oncekiIMKBSeans = sayac;

				/*
				 * O ay�n seans verileri toplamIMKBDeger de�i�kenine eklenir.
				 * Ayda ka� seans oldu�u toplamIMKBSayi ile hat�rlan�r.,
				 */
				toplamIMKBDeger += deger(sayac);
				toplamIMKBSayi++;

				/*
				 * En d���k de�er olup olmad���n� ara�t�r. IMKBEnDusuk[2] k���k
				 * de�erlerin en b�y���n�, IMKBEnDusuk[0] k���k de�erlerin en
				 * k�����n� saklar.
				 */
				if ((deger(sayac) <= IMKBEnDusukDeger[2])
						|| IMKBEnDusukDeger[2] == -1) {
					if ((deger(sayac) <= IMKBEnDusukDeger[1])
							|| IMKBEnDusukDeger[1] == -1) {
						if ((deger(sayac) <= IMKBEnDusukDeger[0])
								|| IMKBEnDusukDeger[0] == -1) {
							/* �imdiye kadarki en k���k de�eri bulduk! */
							IMKBEnDusukDeger[2] = IMKBEnDusukDeger[1];
							IMKBEnDusukSeans[2] = IMKBEnDusukSeans[1];

							IMKBEnDusukDeger[1] = IMKBEnDusukDeger[0];
							IMKBEnDusukSeans[1] = IMKBEnDusukSeans[0];

							IMKBEnDusukDeger[0] = deger(sayac);
							IMKBEnDusukSeans[0] = sayac;
						} else {
							/* �imdiye kadarki en k���k ikinci de�eri bulduk! */
							IMKBEnDusukDeger[2] = IMKBEnDusukDeger[1];
							IMKBEnDusukSeans[2] = IMKBEnDusukSeans[1];

							IMKBEnDusukDeger[1] = deger(sayac);
							IMKBEnDusukSeans[1] = sayac;
						}
					} else {
						/* �imdiye kadarki en k���k ���nc� de�eri bulduk! */
						IMKBEnDusukDeger[2] = deger(sayac);
						IMKBEnDusukSeans[2] = sayac;
					}
				}

				/*
				 * En y�ksek de�er olup olmad���n� ara�t�r. IMKBEnYuksek[2]
				 * b�y�k de�erlerin en k�����n�, IMKBEnYuksek[0] b�y�k
				 * de�erlerin en b�y���n� saklar.
				 */
				if ((deger(sayac) >= IMKBEnYuksekDeger[2])
						|| IMKBEnYuksekDeger[2] == -1) {
					if ((deger(sayac) >= IMKBEnYuksekDeger[1])
							|| IMKBEnYuksekDeger[1] == -1) {
						if ((deger(sayac) >= IMKBEnYuksekDeger[0])
								|| IMKBEnYuksekDeger[0] == -1) {
							/* �imdiye kadarki en b�y�k de�eri bulduk! */
							IMKBEnYuksekDeger[2] = IMKBEnYuksekDeger[1];
							IMKBEnYuksekSeans[2] = IMKBEnYuksekSeans[1];

							IMKBEnYuksekDeger[1] = IMKBEnYuksekDeger[0];
							IMKBEnYuksekSeans[1] = IMKBEnYuksekSeans[0];

							IMKBEnYuksekDeger[0] = deger(sayac);
							IMKBEnYuksekSeans[0] = sayac;
						} else {
							/* �imdiye kadarki en k���k ikinci de�eri bulduk! */
							IMKBEnYuksekDeger[2] = IMKBEnYuksekDeger[1];
							IMKBEnYuksekSeans[2] = IMKBEnYuksekSeans[1];

							IMKBEnYuksekDeger[1] = deger(sayac);
							IMKBEnYuksekSeans[1] = sayac;
						}
					} else {
						/* �imdiye kadarki en k���k ���nc� de�eri bulduk! */
						IMKBEnYuksekDeger[2] = deger(sayac);
						IMKBEnYuksekSeans[2] = sayac;
					}
				}

				/* Ay�n son seans�na gelmi�sek */
				if (hangiAy(sayac + 1) != ay) {
					System.out.println("\n" + ay
							+ ".ay i�in endeks ortalamas�: "
							+ (toplamIMKBDeger / toplamIMKBSayi));
					System.out.println(((ay == 1) ? "Ge�en y�l�n son ay�"
							: (ay - 1) + ". ay")
							+ " ile "
							+ ay
							+ ". ay aras�ndaki de�i�im oran�: "
							+ degisimOrani(gecenAyIMKBDeger, deger(sayac))
							+ "%\n");
					gecenAyIMKBDeger = deger(sayac);
					toplamIMKBDeger = 0;
					toplamIMKBSayi = 0;
					ay++;
				}
			}
		}

		System.out.println("\n\nEndeksin en d���k oldu�u �� g�n:");

		for (int sayac = 0; sayac < 3; sayac++) {
			System.out.println(hangiAy(IMKBEnDusukSeans[sayac]) + ". ay�n "
					+ hangiGun(IMKBEnDusukSeans[sayac]) + ". g�n�n�n "
					+ ((IMKBEnDusukSeans[sayac] % 2 == 0) ? "2" : "1")
					+ ". seans�. (Puan: " + IMKBEnDusukDeger[sayac] + ")");
		}

		System.out.println("\n\nEndeksin en y�ksek oldu�u �� g�n:");

		for (int sayac = 0; sayac < 3; sayac++) {
			System.out.println(hangiAy(IMKBEnYuksekSeans[sayac]) + ". ay�n "
					+ hangiGun(IMKBEnYuksekSeans[sayac]) + ". g�n�n�n "
					+ ((IMKBEnYuksekSeans[sayac] % 2 == 0) ? "2" : "1")
					+ ". seans�. (Puan: " + IMKBEnYuksekDeger[sayac] + ")");
		}

	}

	/* function hangiGun 
	 * Author: Didem Kayal�
	 * 
	 * @param: Seans numaras�
	 * @return: Ay�n bir g�n� (1-31) Seans�n ay�n hangi
	 * g�n�ne ait oldu�unu d�nd�r�r.
	 */
	private static int hangiGun(int seansno) {
		int kalan = seansno % 2;

		if ((seansno >= 1) && (seansno <= 62)) {
			if (kalan == 1)
				return ((seansno / 2) + 1);
			else
				return (seansno / 2);
		} else if ((seansno >= 63) && (seansno <= 118)) {
			if (kalan == 1)
				return (((seansno - 62) / 2) + 1);
			else
				return ((seansno - 62) / 2);

		} else if ((seansno >= 119) && (seansno <= 180)) {
			if (kalan == 1)
				return (((seansno - 118) / 2) + 1);
			else
				return ((seansno - 118) / 2);
		} else if ((seansno >= 181) && (seansno <= 240)) {
			if (kalan == 1)
				return (((seansno - 180) / 2) + 1);
			else
				return ((seansno - 180) / 2);
		} else if ((seansno >= 241) && (seansno <= 302)) {
			if (kalan == 1)
				return (((seansno - 240) / 2) + 1);
			else
				return ((seansno - 240) / 2);
		} else if ((seansno >= 303) && (seansno <= 362)) {
			if (kalan == 1)
				return (((seansno - 302) / 2) + 1);
			else
				return ((seansno - 302) / 2);
		} else if ((seansno >= 363) && (seansno <= 424)) {
			if (kalan == 1)
				return (((seansno - 362) / 2) + 1);
			else
				return ((seansno - 362) / 2);
		} else if ((seansno >= 425) && (seansno <= 486)) {
			if (kalan == 1)
				return (((seansno - 424) / 2) + 1);
			else
				return ((seansno - 424) / 2);
		} else if ((seansno >= 487) && (seansno <= 546)) {
			if (kalan == 1)
				return (((seansno - 486) / 2) + 1);
			else
				return ((seansno - 486) / 2);
		} else if ((seansno >= 547) && (seansno <= 608)) {
			if (kalan == 1)
				return (((seansno - 546) / 2) + 1);
			else
				return ((seansno - 546) / 2);
		} else if ((seansno >= 609) && (seansno <= 668)) {
			if (kalan == 1)
				return (((seansno - 608) / 2) + 1);
			else
				return ((seansno - 608) / 2);
		} else if ((seansno >= 669) && (seansno <= 730)) {
			if (kalan == 1)
				return (((seansno - 668) / 2) + 1);
			else
				return ((seansno - 668) / 2);
		} else
			return -1;
	}

	/* function hangiAy
	 * Author: Didem Kayal�
	 * 
	 * @param: Seans numaras�
	 * @return: Y�l�n bir ay� (1-12) Seans�n ay�n hangi
	 * aya ait oldu�unu d�nd�r�r.
	 */
	private static int hangiAy(int seansno) {
		/* Didem */
		/* E�er 730'dan fazlaysa -1 d�nd�rmeli */
		if ((seansno >= 1) && (seansno <= 62))
			return 1;

		else if ((seansno >= 63) && (seansno <= 118))

			return 2;

		else if ((seansno >= 119) && (seansno <= 180))

			return 3;

		else if ((seansno >= 181) && (seansno <= 240))

			return 4;

		else if ((seansno >= 241) && (seansno <= 302))

			return 5;

		else if ((seansno >= 303) && (seansno <= 362))

			return 6;

		else if ((seansno >= 363) && (seansno <= 424))

			return 7;

		else if ((seansno >= 425) && (seansno <= 486))

			return 8;

		else if ((seansno >= 487) && (seansno <= 546))

			return 9;

		else if ((seansno >= 547) && (seansno <= 608))

			return 10;

		else if ((seansno >= 609) && (seansno <= 668))

			return 11;

		else if ((seansno >= 669) && (seansno <= 730))

			return 12;

		else

			return -1;
	}

	/* function degisimOrani
	 * Author: Didem Kayal�
	 * 
	 * @param: �lk seans�n de�eri
	 * @param: �kinci seans�n de�eri
	 * @return: Seanslar aras� de�i�im oran� 
	 * 
	 * Seanslar aras�ndaki de�i�im oran�n� %
	 * cinsinden d�nd�r�r.
	 */
	private static float degisimOrani(float ilkyuzde, float sonyuzde) {
		return (100 * (sonyuzde - ilkyuzde)) / ilkyuzde;
	}

	/* function tatilMi 
	 * Author: �zlem G�rses
	 * 
	 * @param: Seans numaras�
	 * @return: Seans�n olmas� gerekti�i g�n�n tatil olup
	 * olmad���
	 */
	private static boolean tatilMi(int no) {
		int yil[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		int ay = hangiAy(no);
		int gun = 0;
		for (int i = 0; i < ay; i++) {
			gun += yil[i];
		}
		gun += hangiGun(no);

		/*
		 * JOptionPane.showMessageDialog(null, "G�n: " + gun + "\n" + "No" + no +
		 * "\nAy =" + ay + "\nhangigun(no) " + hangiGun(no),
		 * "tatilMi",JOptionPane.PLAIN_MESSAGE);
		 */

		if (gun % 7 == 0 || gun % 7 == 6)
			return true;
		else
			return false;

	}

	/* function deger
	 * Author: H�seyin Ya�ar
	 * 
	 * @param: Seans numaras�
	 * @return: E�er seans tatil g�n�ne denk gelmiyorsa
	 * rastgele bir seans de�eri �retir. Tatil g�nleri i�in -1 d�nd�r�r.
	 */
	private static float deger(int seansno) {
		if (tatilMi(seansno))
			return -1;

		float IMKBdegeri;
		IMKBdegeri = 30000 + 20000 * randomFonksiyon(seansno);
		return IMKBdegeri;
	}

	private static float randomFonksiyon(int x) {
		float y;
		y = (float) Math.sin(x) + (float) Math.sin(x / 2) + 2
				+ parcaliFonksiyon(x);
		// Math.sin(double x) metodu double d�nd�rd��� i�in her kullan�m�ndan
		// �nce floata �evrilir.
		y /= 4;
		return y;
	}

	private static float parcaliFonksiyon(int a) {
		float x, y;
		x = a;
		if (0 <= x && x < 70)
			y = 0;
		else if (70 <= x && x < 315)
			y = -x / 180 + 1;
		else if (315 <= x && x < 450)
			y = 1;
		else if (450 <= x && x < 720)
			y = x / 360 + 2;
		else if (720 <= x)
			y = 0;
		else {
			System.out.println("Random hatas�");
			return -1;
		}
		return y;
	}
}
