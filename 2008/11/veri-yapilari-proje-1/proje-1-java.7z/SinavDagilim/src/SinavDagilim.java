import java.util.Scanner;

/* class SinavDagilim
 * Authors: �zlem G�rses, H�seyin Ya�ar, Didem Kayal�
 * Beta Tester: Umut Benzer
 */
public class SinavDagilim {
	
	/* function kacSinirKullanilacak
	 * Author: H�seyin Ya�ar
	 *
	 * @param: ��renci say�s� ve s�n�f kapasiteleri
	 * @return: ��rencilerin ka� s�n�fa yerle�tirilece�i
	 */
	private static int kacSinifKullanilacak(int ogrSayi, int sinifKapasite[]) {
		int kapasitelerToplami = 0;
		int kullanilacakSinifSayisi = 0;
		for (int i = 0; i < 5; i++) {
			kapasitelerToplami+=sinifKapasite[i];
			kullanilacakSinifSayisi++;
			if(kapasitelerToplami>=ogrSayi)
				break;
		}
		return kullanilacakSinifSayisi;
	}
	
	/* function dagilimBul
	 * Author: H�seyin Ya�ar
	 *
	 * @param: S�ralanm�� s�n�f kapasiteleri, ��renci say�s�, bo� s�n�f mevcudu dizisi
	 * @return: S�n�flara ka�ar ki�i koyulaca��n�n bilgisi
	 */
	private static void dagilimBul(int sinifKapasite[], int ogrSayi,
			int sinifMevcut[]) {
		int kapasitelerToplami = 0;
		int a = kacSinifKullanilacak(ogrSayi, sinifKapasite);
		float[] sinifMevcutOndalikli = new float[a];
		float kusuratlarToplami = 0;
		for (int i = 0; i < a; i++) {
			kapasitelerToplami += sinifKapasite[i];
		}
		for (int i = 0; i < a; i++) {
			sinifMevcutOndalikli[i] = sinifKapasite[i]
					* ((float) ogrSayi / (float) kapasitelerToplami);
			sinifMevcut[i] = (int) sinifMevcutOndalikli[i];
			kusuratlarToplami += sinifMevcutOndalikli[i] - sinifMevcut[i];
		}

		if (kusuratlarToplami > 0) {
			for (int i = 0; i < a; i++) {
				sinifMevcut[i]++;
				kusuratlarToplami--;
				if (kusuratlarToplami <= 0)
					break;
				/* k�s�ratlar�n toplam� olan tamsay�y� soldan sa�a 
				 * birer birer bitene kadar da��t�r
				 * kusuratlar toplam� daima tamsay� gelmesi gereken bir 
				 * say�d�r, �rne�in 0.2 ve 0.8 gibi artanlar olur,
				 * bunlar�n toplam� daima tamsay�d�r, ama bazen b�l�mlerde
				 * 0.19999999 ve 0.7999999999 gibi say�lar gelebilir,
				 * bunlar�n toplamlar� 0.999999 gibi say�lard�r, dolay�s�yla
				 * 1 eksildi�i zaman 0'�n alt�na d��er, bu y�zden if sat�r�nda 
				 * k���kt�r ibaresi kullan�lm��t�r.
				 */	 				
			}
		}
	}
	
	/* function sirala
	 * Author: Didem Kayal�
	 *
	 * @param: S�ralanacak integer dizisi
	 * @return: S�ralanm�� integer dizisi (b�y�kten k����e)
	 *
	 * Dizi referans olarak g�nderilece�inden void d�nd�rmesi
	 * yeterlidir. As�l de�i�iklikler as�l diziye yans�t�l�r.
	 */
	private static void sirala(int sinifKapasite[]) {
		/* Standart Bubble Sort Algoritmas� */
		for (int i = 0; i < sinifKapasite.length - 1; i++) {
			for (int j = i + 1; j < sinifKapasite.length; j++) {
				if (sinifKapasite[j] > sinifKapasite[i]) {
					int b = sinifKapasite[j];
					sinifKapasite[j] = sinifKapasite[i];
					sinifKapasite[i] = b;
				}
			}
		}
	}
	
	/* function dagit
	 * Author: �zlem G�rses
	 *
	 * @param: S�ralanm�� s�n�f kapasiteleri, i�erilerine yerle�tirilecek ��renci say�s�
	 * @return: Ekrana ��kt�
	 */
	private static void dagit(int sinifKapasite[], int sinifMevcut[]) {
		String ad[] = { "umut", "didem", "�zlem", "h�seyin", "h�lya", "banu",
				"ajdar","ay�e","mehmet","h�sn�","canan","metin","ok�an" };
		String soyad[] = { "benzer", "kayal�", "g�rses", "ya�ar", "av�ar",
				"alkan", "an�k","sert","and��","y�lmaz","�ahin","kurt","�elik",
				"boya","h�y�k","g�ler","sever","ceylan"};
		
		/*
		 * "" say�s�n�n fazla olmas�, daha az ek se�ilmesini sa�lamaya
		 * y�neliktir.
		 */
		String ekleAd[] = { "can", "g�l", "nur", "su", "","","" };
		String ekleSoyad[] = { "o�lu", "gil", "�z", "","","","" };

		for (int i = 0; i <= sinifKapasite.length-1; i++) { /* UBenzer d�zenleme */
			if(sinifKapasite[i]==0) {
				System.out.print((i+1)+". s�n�f bo� s�n�ft�r.\n");
			} else if(sinifMevcut[i]==0){
				System.out.print(sinifKapasite[i]+" ki�ilik s�n�fa ��renci yerle�tirilmemi�tir.\n");
			} else {
				float ort = (float) 100 * sinifMevcut[i] / sinifKapasite[i];
				System.out.println("\n\n" + sinifKapasite[i] + " ki�ilik s�n�fa "
					+ sinifMevcut[i]
					+ " ki�i yerle�tirildi.\ns�n�f�n doluluk oran�: " + ort
					+ " %d�r.");
				for (int k = 0; k < sinifMevcut[i]; k++) {
					String yeniIsim = ad[(int) (Math.random() * ad.length)]
							.concat(ekleAd[(int) (Math.random() * ekleAd.length)]);
					String yeniSoyisim = soyad[(int) (Math.random() * soyad.length)]
							.concat(ekleSoyad[(int) (Math.random() * ekleSoyad.length)]);
					int yil = (int) (Math.random() * 8);
					System.out.print((k+1) + ". 05-0"
							+ yil + "-" + (int) (Math.random() * 9)
							+ (int) (Math.random() * 9) + (int) (Math.random() * 9)
							+ (int) (Math.random() * 9) + " "+yeniIsim + " " + yeniSoyisim+"\n");
				}			
			}
		}

	}
	
	/* function main
	 * Author: H�seyin Ya�ar
	 */
	public static void main(String[] args) {
		int[] sinifKapasite = new int[5];
		int[] sinifMevcut = new int[5];
		int ogrSayi;
		int top;
		int kntrl = 0;
		Scanner str = new Scanner(System.in);
		do {
			top=0;
			if(kntrl==1)
				System.out.println("Hatal� giri�.");
			
			System.out.println("Yerlestirilecek ogrenci sayisini giriniz: ");
			ogrSayi = str.nextInt();
			if(ogrSayi < 100 || ogrSayi > 200){
				 kntrl = 1;
				 continue;
			}
		
			for(int i=0; i<sinifKapasite.length; i++){
			System.out.println((i+1)+". sinifin kapasitesini giriniz: ");
				sinifKapasite[i]=str.nextInt();
				if(sinifKapasite[i]<0) {
					kntrl = 1;
					break;
				}
				top+=sinifKapasite[i];
			}
			if(top < ogrSayi) {
				 kntrl = 1;
			} else {
				kntrl = 0;
			}
		} while(kntrl==1);
			
		sirala(sinifKapasite);
		dagilimBul(sinifKapasite, ogrSayi, sinifMevcut);
		/* Hata ay�klama */
		System.out.println(sinifMevcut[0] +  " " + sinifMevcut[1] +  " " + sinifMevcut[2] +  " " + sinifMevcut[3] +  " " + sinifMevcut[4] +  " " );
		dagit(sinifKapasite, sinifMevcut);
	}
}
