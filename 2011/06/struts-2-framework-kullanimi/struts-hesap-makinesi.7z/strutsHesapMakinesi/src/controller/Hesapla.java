package controller;

import model.DortIslem;
import com.opensymphony.xwork2.ActionSupport;

public class Hesapla extends ActionSupport {
	
	private static final long serialVersionUID = 4344235555986205402L;
	
	private Integer elemanX;
	private Integer elemanY;
	private String islem;
	private String sonuc;
	
	public String getIslem() {
		return islem;
	}
	public void setIslem(String islem) {
		this.islem = islem;
	}	
	public Integer getElemanX() {
		return elemanX;
	}
	public void setElemanX(Integer eleman1) {
		this.elemanX = eleman1;
	}
	public Integer getElemanY() {
		return elemanY;
	}
	public void setElemanY(Integer eleman2) {
		this.elemanY = eleman2;
	}	
	public String getSonuc() {
		return sonuc;
	}

	public void setSonuc(String sonuc) {
		this.sonuc = sonuc;
	}
	
	@Override
	public void validate() {
		/*
		if(getIslem().equals("bol") && elemanY == 0) {
			addFieldError("elemanY", "Sifır olamaz");
		} */
	}
	public String execute() throws Exception {
		
		if(getIslem().equals("topla")) {
			this.setSonuc(String.valueOf(DortIslem.Topla(elemanX, elemanY)));
		} else if(getIslem().equals("cikar")) {
			this.setSonuc(String.valueOf(DortIslem.Cikar(elemanX, elemanY)));
		} else if(getIslem().equals("carp")) {
			this.setSonuc(String.valueOf(DortIslem.Carp(elemanX, elemanY)));			
		} else if(getIslem().equals("bol")) {
			this.setSonuc(String.valueOf(DortIslem.Bol(elemanX, elemanY)));
		} else {
			throw new Exception ("İşlem tanımlı değil exception.");
		}
		return "success";
	}
}
