package model;

public class DortIslem {
	
	public static double Topla(Integer eleman1, Integer eleman2) {
		return eleman1 + eleman2;
	}
	public static double Carp(Integer eleman1, Integer eleman2) {
		return eleman1*eleman2;
	}
	public static double Bol(Integer eleman1, Integer eleman2) {
		return eleman1/eleman2;
	}
	public static double Cikar(Integer eleman1, Integer eleman2) {
		return eleman1-eleman2;
	}
}
