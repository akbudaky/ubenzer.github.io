/**
 * Öğrenci ile ilgili arayüzlerin bilgilerinin yönetildiği
 * beandır.
 */
package com.ubenzer.sst.proje2.beans;

import com.ubenzer.sst.proje2.model.Ogrenci;

public class OgrenciBean {

	private Double gpa = new Double(0);
	private String interests = new String();
	private String mesaj = new String();
	private String name = new String();
	private Ogrenci o;
	private String password = new String();
	private String user = new String();

	/* Getter metotlar */
	public Double getGpa() {
		return gpa;
	}

	public String getInterests() {
		return interests;
	}

	public String getMesaj() {
		return mesaj;
	}

	public String getName() {
		return name;
	}

	public Ogrenci getO() {
		return o;
	}

	public String getPassword() {
		return password;
	}

	public String getUser() {
		return user;
	}

	/**
	 * Şu an beanda bulunan bilgileri kullanarak User ve Password bilgilerine
	 * uyan bir öğrencinin sistemde bulunup bulunmadığını denetler.
	 * 
	 * Eğer öğrenci sistemde yoksa, yeni yatatılır. Eğer öğrenci sistemde ve
	 * şifresi doğruysa bilgileri düzenlenir.
	 * 
	 * Bunlar "valid" döndürür. Dönen değerler faces.xml'de işlenir.
	 * 
	 * Eğer şifre hatalı ise "invalid" döner.
	 * 
	 * @return "valid" or "invalid"
	 */
	public String isOgrenciValid() {

		o = Ogrenci.getOgrenciByUser(getUser());

		if (o == null) {
			setMesaj("Öğrenci sistemde yok. Yeni yaratacağız.");
			setName("");
			setGpa(0.0);
			setInterests("");
			return "valid";
		}
		if (o.getPassword().equals(this.getPassword())) {
			setMesaj("Hoş geldin sayın öğrenci ;)");
			setName(o.getName());
			setGpa(o.getGpa());
			setInterests(o.getInterests());
			return "valid";
		} else {
			setMesaj("Öğrenci mevcut ama parola hatalı. Bence bir de '"
					+ o.getPassword()
					+ "' girmeyi deneyin. [hiii, güvenlik açığı]");
			return "invalid";
		}
	}

	/* Setter metotlar */
	public void setGpa(Double gpa) {
		this.gpa = gpa;
	}

	public void setInterests(String interests) {
		this.interests = interests;
	}

	public void setMesaj(String mesaj) {
		this.mesaj = mesaj;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public void setPassword(final String password) {
		this.password = password;
	}

	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * Güncel öğrencinin bilgilerinde yapılan değişikliği veritabanına yazar.
	 * Eğer öğrenci yeni yaratılıyorsa, önce bir Öğrenci nesnesi yaratılarak bu
	 * veritabanına eklenir.
	 * 
	 * Öğrenci güncelleniyorsa Bean aracılığı ile bilgileri güncellenmiş
	 * öğrencinin bilgileri öğrenci nesnesinde güncellenir ve bu bilgiler
	 * veritabanına aktarılır.
	 * 
	 * Eğer DB ile alakalı bir sıkıntı olursa (bağlantı problemi, unique
	 * username problemi "error" döner.
	 * 
	 * @return "success" or "error"
	 */
	public String updateOgrenci() {
		if (o == null) {
			try {
				o = Ogrenci.InsertOgrenci(getUser(), getPassword(), getName(),
						getGpa(), getInterests());
				setMesaj("Ekleme tamam.");
			} catch (Exception e) {
				setMesaj("Sıkıntı oldu. Öğrenciyi güncelleyemedik.");
				e.printStackTrace();
				return "error";
			}

		} else {

			o.setGpa(getGpa());
			o.setInterests(getInterests());
			o.setName(getName());
			o.setPassword(getPassword());
			o.setUser(getUser());

			try {
				o.UpdateOgrenci();
				setMesaj("Güncelleme tamam.");
			} catch (Exception e) {
				setMesaj("Sıkıntı oldu. Öğrenciyi ekleyemedik.");
				e.printStackTrace();
				return "error";
			}
		}
		return "success";
	}
}
