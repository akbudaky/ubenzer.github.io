/**
 * Öğrenci bilgilerinin tutulduğu bir domain nesnesi,
 * aynı zamanda öğrencilerle ilgili işlerin yapılabildiği
 * statik metotlar içeren bir sınıftır.
 */
package com.ubenzer.sst.proje2.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Ogrenci {

	/* Statik Metotlar */

	/**
	 * Veritabanındaki tüm öğrencileri bir ArrayList halinde döndürür.
	 * 
	 * @return Tüm öğrenciler
	 */
	public static ArrayList<Ogrenci> getAllOgrenci() {
		Connection con;
		ArrayList<Ogrenci> don = new ArrayList<Ogrenci>();
		try {

			con = DAL.getAConnection();

			PreparedStatement pstmt = con
					.prepareStatement("SELECT * FROM ogrenci");
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				don.add(new Ogrenci(rs.getInt("ID")));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return don;
	}

	/**
	 * Kullanıcı adına göre öğrenci sorgulaması yapar ve eğer öğrenci varsa
	 * döndürür.
	 * 
	 * @param Kullanıcı
	 *            adı
	 * @return Varsa öğrenci, yoksa null
	 */
	public static Ogrenci getOgrenciByUser(String user) {
		Connection con;
		try {
			con = DAL.getAConnection();

			PreparedStatement pstmt = con
					.prepareStatement("SELECT * FROM ogrenci WHERE user = ?");
			pstmt.setString(1, user);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return new Ogrenci(rs.getInt("ID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}

	/**
	 * Öğrencileri isimlerine göre arar. Sonuçlar ArrayList içerisinde
	 * döndürülür.
	 * 
	 * @param Aranacak isim
	 * @return Öğrenci listesi
	 */
	public static ArrayList<Ogrenci> getOgrenciByUserS(String searchUser) {

		if (searchUser.length() < 1)
			return getAllOgrenci();

		Connection con;
		ArrayList<Ogrenci> don = new ArrayList<Ogrenci>();
		try {

			con = DAL.getAConnection();

			PreparedStatement pstmt = con
					.prepareStatement("SELECT * FROM ogrenci WHERE name LIKE ?");
			pstmt.setString(1, "%" + searchUser + "%");
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				don.add(new Ogrenci(rs.getInt("ID")));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return don;
	}

	/**
	 * Öğrencileri ilgi alanlarına göre arar. Sonuçlar ArrayList içerisinde
	 * döndürülür.
	 * 
	 * @param Aranacak ilgi alanı
	 * @return Öğrenci listesi
	 */
	public static ArrayList<Ogrenci> getOgrenciInterestS(String searchInterest) {

		if (searchInterest.length() < 1)
			return getAllOgrenci();

		Connection con;
		ArrayList<Ogrenci> don = new ArrayList<Ogrenci>();
		try {

			con = DAL.getAConnection();

			PreparedStatement pstmt = con
					.prepareStatement("SELECT * FROM ogrenci WHERE interests LIKE ?");
			pstmt.setString(1, "%" + searchInterest + "%");
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				don.add(new Ogrenci(rs.getInt("ID")));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return don;
	}

	/**
	 * Verilen bilgilerle bir öğrenci nesnesi yaratır ve bunu veritabanına
	 * ekler.
	 * 
	 * @param Kullanıcı adı (unique)
	 * @param Şifre
	 * @param İsim
	 * @param Ortalama
	 * @param İlgi alanları
	 * @return Yeni eklenen öğrenci nesnesi
	 * @throws Veritabanı veya unique key ile ilgili hatalar
	 */
	public static Ogrenci InsertOgrenci(String user, String pass, String name,
			Double gpa, String interests) throws Exception {

		Connection con = DAL.getAConnection();
		PreparedStatement pstmt = con
				.prepareStatement(
						"INSERT INTO ogrenci (user, pass, name, gpa, interests) VALUES (?,?,?,?,?)",
						Statement.RETURN_GENERATED_KEYS);
		pstmt.setString(1, user);
		pstmt.setString(2, pass);
		pstmt.setString(3, name);
		pstmt.setDouble(4, gpa);
		pstmt.setString(5, interests);
		pstmt.executeUpdate();
		ResultSet rs = pstmt.getGeneratedKeys();

		rs.next();
		int key = rs.getInt(1);

		pstmt.close();

		return new Ogrenci(key);

	}

	private Double gpa;
	private Integer ID;
	private String interests;
	private String name;
	private String password;
	private String user;

	/**
	 * Constuctor. Bir öğrenciID'si ile nesne yaratılır.
	 * 
	 * @param ID
	 */
	public Ogrenci(int ogrenciID) {
		try {
			Connection con = DAL.getAConnection();
			PreparedStatement pstmt = con
					.prepareStatement("SELECT * FROM ogrenci WHERE ID = ?");
			pstmt.setInt(1, ogrenciID);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				ID = ogrenciID;
				setUser(rs.getString("user"));
				setPassword(rs.getString("pass"));
				setName(rs.getString("name"));
				setGpa(rs.getDouble("gpa"));
				setInterests(rs.getString("interests"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Nesne eşitliğinin ID'lere göre karşılaştırılması sağlanır.
	 */
	public boolean equals(Object o) {
		if (o instanceof Ogrenci && ((Ogrenci) o).getID() == this.getID()) {
			return true;
		}
		return false;
	}

	/* Getter metotlar */
	public Double getGpa() {
		return gpa;
	}

	public Integer getID() {
		return ID;
	}

	public String getInterests() {
		return interests;
	}

	public String getName() {
		return name;
	}

	public String getPassword() {
		return password;
	}

	public String getUser() {
		return user;
	}

	/* Setter metotlar */
	public void setGpa(Double gpa) {
		this.gpa = gpa;
	}

	public void setInterests(String interests) {
		this.interests = interests;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * Nesnede yapılan değişiklikleri veritabanına aktarır.
	 */
	public void UpdateOgrenci() throws Exception {

		Connection con = DAL.getAConnection();
		PreparedStatement pstmt = con
				.prepareStatement("UPDATE ogrenci SET user=?, pass=?, name=?, gpa=?, interests=? WHERE ID=?");
		pstmt.setString(1, getUser());
		pstmt.setString(2, getPassword());
		pstmt.setString(3, getName());
		pstmt.setDouble(4, getGpa());
		pstmt.setString(5, getInterests());
		pstmt.setInt(6, getID());
		pstmt.executeUpdate();
		pstmt.close();
	}
}
