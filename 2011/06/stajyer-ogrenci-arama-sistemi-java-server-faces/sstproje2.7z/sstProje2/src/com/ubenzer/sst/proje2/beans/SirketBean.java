/**
 * Şirket ile ilgili arayüzlerin bilgilerinin yönetildiği
 * beandır.
 */
package com.ubenzer.sst.proje2.beans;

import java.util.ArrayList;

import com.ubenzer.sst.proje2.model.Ogrenci;
import com.ubenzer.sst.proje2.model.SecilebilirOgrenci;
import com.ubenzer.sst.proje2.model.Sirket;

public class SirketBean {

	private String mesaj = new String();
	private ArrayList<SecilebilirOgrenci> ogrenciListesi;
	private String password = new String();
	private Sirket s;
	private String searchInterest = new String();
	private String searchUser = new String();
	private ArrayList<SecilebilirOgrenci> seciliOgrenciListesi = new ArrayList<SecilebilirOgrenci>();
	private String user = new String();

	/* Getter metotlar */
	public String getMesaj() {
		return mesaj;
	}

	public ArrayList<SecilebilirOgrenci> getOgrenciListesi() {
		if (ogrenciListesi == null)
			populateOgreciListesi();
		return ogrenciListesi;
	}

	public String getPassword() {
		return password;
	}

	public Sirket getS() {
		return s;
	}

	public String getSearchInterest() {
		return searchInterest;
	}

	public String getSearchUser() {
		return searchUser;
	}

	public ArrayList<SecilebilirOgrenci> getSeciliOgrenciListesi() {
		return seciliOgrenciListesi;
	}

	public String getUser() {
		return user;
	}

	/**
	 * Seçili öğrenci listesini güncellemektedir. Seçili öğrenciler
	 * seciliOgrenciListesi ArrayList'inde tutulur.
	 * 
	 * @return success
	 */
	public String guncelle() {
		/*
		 * Eğer sadecee zaten daha önce seçilmemişse seçeceğiz. Bunun kontrolü
		 * için nesnelerin eşitliğinden faydalanılırız.
		 */
		for (SecilebilirOgrenci o : ogrenciListesi) {
			if (o.isSecili() && !seciliOgrenciListesi.contains(o))
				seciliOgrenciListesi.add(o);
		}
		return "success";
	}

	/**
	 * Şu an beanda bulunan bilgileri kullanarak User ve Password bilgilerine
	 * uyan bir şirketin sistemde bulunup bulunmadığını denetler.
	 * 
	 * Eğer şirket sistemde ve şifresi doğruysa bilgileri s nesnesine atılır.
	 * Oturum açılmış olur.
	 * 
	 * Bu "valid" döndürür. Dönen değerler faces.xml'de işlenir.
	 * 
	 * Eğer şifre hatalı ise veya şirket yoksa "invalid" döner.
	 * 
	 * @return "valid" or "invalid"
	 */
	public String isSirketValid() {

		s = Sirket.getSirketByUser(getUser());

		if (s == null) {
			setMesaj("Şirket sistemde yok.");
			return "invalid";
		}
		if (s.getPassword().equals(this.getPassword())) {
			setMesaj("Hoş geldin sayın yetkili. Artık arama yapabilirsin. ;)");
			return "valid";
		} else {
			setMesaj("Hatalı şifre. Hekır mısınız? Şifre olarak deneyin: "
					+ s.getPassword());
			s = null;
			return "invalid";
		}
	}

	/**
	 * Tüm öğrencileri veritabanından alarak ekranda gösterilmeye hazırlar.
	 */
	public void populateOgreciListesi() {
		ogrenciListesi = new ArrayList<SecilebilirOgrenci>();

		ArrayList<Ogrenci> ogrs = Ogrenci.getAllOgrenci();
		for (Ogrenci o : ogrs) {
			ogrenciListesi.add(new SecilebilirOgrenci(o, false));
		}
	}

	/**
	 * Sadece belirli özelliğe sahip öğrencileri veritabanından alarak ekranda
	 * gösterilmeye hazırlar.
	 * 
	 * @return success
	 */
	public String searchByInterest() {
		ogrenciListesi = new ArrayList<SecilebilirOgrenci>();

		ArrayList<Ogrenci> ogrs = Ogrenci.getOgrenciInterestS(this
				.getSearchInterest());
		for (Ogrenci o : ogrs) {
			ogrenciListesi.add(new SecilebilirOgrenci(o, false));
		}
		return "success";
	}

	/**
	 * Sadece belirli isime sahip öğrencileri veritabanından alarak ekranda
	 * gösterilmeye hazırlar.
	 * 
	 * @return success
	 */
	public String searchByUser() {
		ogrenciListesi = new ArrayList<SecilebilirOgrenci>();

		ArrayList<Ogrenci> ogrs = Ogrenci.getOgrenciByUserS(this
				.getSearchUser());
		for (Ogrenci o : ogrs) {
			ogrenciListesi.add(new SecilebilirOgrenci(o, false));
		}
		return "success";
	}

	/* Setter metotlar */
	public void setMesaj(String mesaj) {
		this.mesaj = mesaj;
	}

	public void setOgrenciListesi(ArrayList<SecilebilirOgrenci> ogrenciListesi) {
		this.ogrenciListesi = ogrenciListesi;
	}

	public void setPassword(final String password) {
		this.password = password;
	}

	public void setSearchInterest(String searchInterest) {
		this.searchInterest = searchInterest;
	}

	public void setSearchUser(String searchUser) {
		this.searchUser = searchUser;
	}

	public void setSeciliOgrenciListesi(
			ArrayList<SecilebilirOgrenci> seciliOgrenciListesi) {
		this.seciliOgrenciListesi = seciliOgrenciListesi;
	}

	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * Seçili öğreci listesini boşaltır.
	 * 
	 * @return success
	 */
	public String sil() {
		seciliOgrenciListesi = new ArrayList<SecilebilirOgrenci>();
		return "success";
	}
}
