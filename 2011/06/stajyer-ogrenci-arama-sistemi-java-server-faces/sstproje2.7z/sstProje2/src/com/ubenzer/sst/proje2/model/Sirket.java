/**
 * Şirket bilgilerinin tutulduğu bir domain nesnesi,
 * aynı zamanda şirketlerle ilgili işlerin yapılabildiği
 * statik metotlar içeren bir sınıftır.
 */
package com.ubenzer.sst.proje2.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Sirket {

	/* Statik Metotlar */

	/**
	 * Kullanıcı adına göre şirket sorgulaması yapar ve eğer şirket varsa
	 * döndürür.
	 * 
	 * @param Kullanıcı adı
	 * @return Varsa şirket, yoksa null
	 */
	public static Sirket getSirketByUser(String user) {
		Connection con;
		try {
			con = DAL.getAConnection();

			PreparedStatement pstmt = con
					.prepareStatement("SELECT * FROM sirket WHERE user = ?");
			pstmt.setString(1, user);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return new Sirket(rs.getInt("ID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}

	private Integer ID;
	private String password;
	private String user;

	/**
	 * Constuctor. Bir sirketID ile nesne yaratılır.
	 * 
	 * @param ID
	 */
	public Sirket(int sirketID) {
		try {
			Connection con = DAL.getAConnection();
			PreparedStatement pstmt = con
					.prepareStatement("SELECT * FROM sirket WHERE ID = ?");
			pstmt.setInt(1, sirketID);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				ID = sirketID;
				setUser(rs.getString("user"));
				setPassword(rs.getString("pass"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/* Getter metotlar */
	public Integer getID() {
		return ID;
	}

	public String getPassword() {
		return password;
	}

	public String getUser() {
		return user;
	}

	/* Setter metotlar */
	public void setPassword(String password) {
		this.password = password;
	}

	public void setUser(String user) {
		this.user = user;
	}
}
