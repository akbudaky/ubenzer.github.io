/**
 * Öğrencilerin sunum katmanında seçilebilir olmasını
 * sağlamak amaçlı kullanılan bir ara sınıftır.
 */
package com.ubenzer.sst.proje2.model;

public class SecilebilirOgrenci {

	private Ogrenci o;
	private boolean secili = false;

	public SecilebilirOgrenci(Ogrenci o, boolean b) {
		this.o = o;
		this.secili = b;
	}

	/**
	 * Seçilebilir öğrencilerin eşit olması, içerisindeki öğrenci nesnelerinin
	 * eşit olması demektir.
	 */
	public boolean equals(Object o) {
		if (o instanceof SecilebilirOgrenci
				&& ((SecilebilirOgrenci) o).getO().equals(this.getO())) {
			return true;
		}
		return false;
	}

	/* Getter metotlar */
	public Ogrenci getO() {
		return o;
	}

	public boolean isSecili() {
		return secili;
	}

	/* Setter metotlar */
	public void setO(Ogrenci o) {
		this.o = o;
	}

	public void setSecili(boolean secili) {
		this.secili = secili;
	}
}
