/**
 * Data Access Layer: Projenin veritabanı bağlantısı
 * kurmak için gereken bağlantıyı aldığı utility sınıfıdır.
 */
package com.ubenzer.sst.proje2.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DAL {

	/**
	 * Veritananına bağlanmak için gerekli bir bağlantı döndürür.
	 * 
	 * @return Bağlantı
	 */
	public static Connection getAConnection() throws SQLException,
			ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/sstproje2?useUnicode=true&characterEncoding=utf8";
		Connection con = DriverManager.getConnection(url, "root", "");

		return con;
	}
}
