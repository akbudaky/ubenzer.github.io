<?php

require_once "ezsql/core.php";
require_once "ezsql/mysql.php";

$vt_kullanici="KULLANICI ADI";
$vt_parola="��FRE";
$vt_isim="VER�TABANI ADI";
$vt_sunucu="localhost";

$db = new ezSQL_mysql($vt_kullanici, $vt_parola, $vt_isim, $vt_sunucu);

