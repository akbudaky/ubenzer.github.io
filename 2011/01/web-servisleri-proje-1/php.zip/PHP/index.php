<?php

require_once("nusoap/nusoap.php");
require_once("db.php");

$namespace = "http://ws.ubenzer.com/index.php";
$server = new soap_server();
$server->configureWSDL("Dusunceler");
$server->wsdl->schemaTargetNamespace = $namespace;


$server->wsdl->addComplexType('DusunceTip','complexType','struct','all','',
		array(
			'Ad' => array('name' => 'Ad','type' => 'xsd:string'),
			'Soyad' => array('name' => 'Soyad','type' => 'xsd:string'),
                        'Dusunce' => array('name' => 'Dusunce','type' => 'xsd:string')
		));
$server->wsdl->addComplexType('DusuncelerTip','complexType','array','','SOAP-ENC:Array',
		array(),
		array(array('ref'=>'SOAP-ENC:arrayType','wsdl:arrayType'=>'tns:DusunceTip[]')),'tns:DusunceTip');
$server->register(
            'SonNDusunceyiGetir',
            array('Limit' => "xsd:int"),
            array('Result' => 'tns:DusuncelerTip'),
            $namespace,
            false,
            'rpc',
            'encoded',
            'Sisteme girilmis toplam dusunce sayisini dondurur.');

$server->register(
            'DusunceEkle',
            array('TCKimlik' => 'xsd:long',
                  'Ad' => 'xsd:string',
                  'Soyad' => 'xsd:string',
                  'DogumYili' => 'xsd:int',
                  'Dusunce' => 'xsd:string'),
            array('Result' => 'xsd:boolean', 'Aciklama' => 'xsd:string'),
            $namespace,
            false,
            'rpc',
            'encoded',
            'Bir vatandasin istek ve dusuncelerini alir, veritabanina kaydeder.');



       
$POST_DATA = isset($GLOBALS['HTTP_RAW_POST_DATA']) ? $GLOBALS['HTTP_RAW_POST_DATA'] : '';  
$server->service($POST_DATA);                

function SonNDusunceyiGetir($n) {
    global $db;
    if(!is_numeric($n)) return null;
	$db->query("SET NAMES utf8");
    $gecici = $db->get_results('SELECT Ad,Soyad,Dusunce FROM dusunce ORDER BY ID DESC LIMIT '.$db->escape($n));
    $dondur = array();
    foreach ($gecici as $g) {
        $dondur[] = array('Ad' => $g->Ad, 'Soyad' => $g->Soyad, 'Dusunce' => $g->Dusunce);
    }
	
    return $dondur;

}

function DusunceEkle($TCKimlik, $Ad, $Soyad, $DogumYili, $Dusunce) {
    global $db;

    list($sonuc, $aciklama) = TCDogrula($TCKimlik, $Ad, $Soyad, $DogumYili);
    if(!$sonuc) {
        return (array(false, $aciklama.' '));
    }

	$db->query("SET NAMES utf8");
	
    $TCKimlik = $db->escape($TCKimlik);
    $Ad = $db->escape($Ad);
    $Soyad = $db->escape($Soyad);
    $DogumYili = $db->escape($DogumYili);
    $Dusunce = $db->escape($Dusunce);

    $db->query('INSERT INTO dusunce (TCKimlik, Ad, Soyad, DogumYili, Dusunce) VALUES ('.$TCKimlik.',"'.$Ad.'","'.$Soyad.'",'.$DogumYili.',"'.$Dusunce.'")');
    return array(true, "");
}

function TCDogrula($TCKimlik, $Ad, $Soyad, $DogumYili) {
    $client = new soapclientNusoap('http://tckimlik.nvi.gov.tr/Service/KPSPublic.asmx?WSDL', true,'','','','');

    $param = array('TCKimlikNo' => $TCKimlik, 'Ad' => $Ad, 'Soyad' => $Soyad, 'DogumYili' => $DogumYili);
    $result = $client->call('TCKimlikNoDogrula', array('parameters' => $param), '', '', false, true);


    if ($client->fault) {
       return array(false,(isset($result["faultstring"]) ? $result["faultstring"] : "Bilinmeyen hata."));
    } else {
	// Check for errors
	$err = $client->getError();
	if ($err) {
            return array(false,$err);
	} else {
            return array(isset($result["TCKimlikNoDogrulaResult"]) ? $result["TCKimlikNoDogrulaResult"] : false, "Bilinmeyen hata 2.");
	}
    }
}