﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Runtime.InteropServices;
using System.Windows.Interop;

namespace Web_Servisi
{
    public partial class MainWindow : Window
    {
        WS.Dusunceler WS = new WS.Dusunceler();
        TC.KPSPublic TC = new TC.KPSPublic();

        public MainWindow()
        {
            InitializeComponent();
   
            Ekle.Click += new RoutedEventHandler(Ekle_Click);
            WS.DusunceEkleCompleted += new Web_Servisi.WS.DusunceEkleCompletedEventHandler(WS_DusunceEkleCompleted);
            WS.SonNDusunceyiGetirCompleted += new Web_Servisi.WS.SonNDusunceyiGetirCompletedEventHandler(WS_SonNDusunceyiGetirCompleted);
            Dogrula.Click += new RoutedEventHandler(Dogrula_Click);
            TC.TCKimlikNoDogrulaCompleted += new Web_Servisi.TC.TCKimlikNoDogrulaCompletedEventHandler(TC_TCKimlikNoDogrulaCompleted);
            hakkndaButon.Click += new RoutedEventHandler(hakkndaButon_Click);

            AdText.TextChanged += new TextChangedEventHandler(TCYenidenDogrula);
            SoyadText.TextChanged += new TextChangedEventHandler(TCYenidenDogrula);
            DogumText.TextChanged += new TextChangedEventHandler(TCYenidenDogrula);
            TCText.TextChanged += new TextChangedEventHandler(TCYenidenDogrula);

            dusunceOku.Click += new RoutedEventHandler(dusunceOku_Click);
        }

        void hakkndaButon_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Bu proje web servislerinin kullanımına basit bir örnektir. İstemci PHP ile yazılmıştır." + "\r\n" + "\r\n" +
                "40 yıllık alanında uzman tecrübeli kadromuz:" + "\t(şaka şaka :D )" + "\r\n" +
                "Umut BENZER (http://www.ubenzer.com)" + "\r\n" +
                "Ediz TÜRKOĞLU" + "\r\n" +
                "Savaş YILDIZ" + "\r\n" +
                "Özlem GÜRSES" + "\r\n" ,"Hakkında");
        }

        void WS_DusunceEkleCompleted(object sender, WS.DusunceEkleCompletedEventArgs e)
        {
            if (e.Result)
            {
                AdText.Text = "";
                SoyadText.Text = "";
                dusuncelerText.Text = "";
                DogumText.Text = "";
                TCText.Text = "";
                status.Content = "Düşünceleriniz başarıyla kaydedildi. :)";
            }
            else
            {
                status.Content = e.Aciklama;
            }
            frameDusunce.IsEnabled = true;
            Ekle.IsEnabled = false;
        }

        void WS_SonNDusunceyiGetirCompleted(object sender, WS.SonNDusunceyiGetirCompletedEventArgs e)
        {
            try
            {
                status.Content = "";   
                if (e.Result != null)
                {
                    string Metin = "";
                    int sayi = 1;
                    foreach (var m in e.Result)
                    {
                        Metin += "#" + sayi + "\n\r";
                        Metin += "-------------------------------" + "\n\r";
                        Metin += "Gönderen: " + m.Ad + " " + m.Soyad + "\n\r";
                        Metin += m.Dusunce + "\n\r";
                        Metin += "-------------------------------" + "\n\r";
                        Metin += "\n\r";
                        sayi++;
                    }
                    if (Metin == "") Metin = "Hiiç, öyle boş boş oturdu halk, bir şey demedi.";
                    MessageBox.Show(Metin, "... halk ne dedi ...");
                }
            }
            catch (Exception)
            {
                status.Content = "Beklenmeyen bir hata oluştu. Bağlantınız mı koptu?";
            }
            dusunceOku.IsEnabled = true;
        }
        void dusunceOku_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                WS.SonNDusunceyiGetirAsync(Convert.ToInt32(dusunceN.Text.Trim()));
                status.Content = "Düşünceler getiriliyoré...";
                dusunceOku.IsEnabled = false;
            }
            catch (Exception)
            {
                status.Content = "Sayı girmelisiniz.";
            }
        }

        void TCYenidenDogrula(object sender, TextChangedEventArgs e)
        {
            Ekle.IsEnabled = false;
        }

        void TC_TCKimlikNoDogrulaCompleted(object sender, TC.TCKimlikNoDogrulaCompletedEventArgs e)
        {            
            try
            {
                if (e.Result)
                {
                    Ekle.IsEnabled = true;
                    status.Content = "Kimliğiniz onaylandı.";
                }
                else
                {
                    Ekle.IsEnabled = false;
                    status.Content = "TC numaranız ile bilgileriniz tutmuyor.";
                }                
            }
            catch (Exception)
            {
                status.Content = e.Error.Message;
            }
            frameDusunce.IsEnabled = true;
        }

        void Dogrula_Click(object sender, RoutedEventArgs e)
        {
            frameDusunce.IsEnabled = false;
            status.Content = "TC doğrulanıyor...";
            try
            {
                TC.TCKimlikNoDogrulaAsync(Convert.ToInt64(TCText.Text.Trim()), AdText.Text.Trim(), SoyadText.Text.Trim(), Convert.ToInt32(DogumText.Text.Trim()));
            }
            catch (Exception)
            {
                status.Content = "Verilerde sakatlık var.";
                frameDusunce.IsEnabled = true;
            }
        }

        void Ekle_Click(object sender, RoutedEventArgs e)
        {
            frameDusunce.IsEnabled = false;
            Ekle.IsEnabled = false;
            status.Content = "Bilgileriniz gönderiliyor...";
            WS.DusunceEkleAsync(Convert.ToInt64(TCText.Text.Trim()), AdText.Text.Trim(), SoyadText.Text.Trim(), Convert.ToInt32(DogumText.Text.Trim()), dusuncelerText.Text.Trim());
        }


        [DllImport("dwmapi.dll")]
        public static extern int DwmExtendFrameIntoClientArea(IntPtr hWnd, ref MARGINS pMargins);

        [DllImport("dwmapi.dll", PreserveSig = false)]
        public static extern bool DwmIsCompositionEnabled();

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (Environment.OSVersion.Version.Major >= 6 && DwmIsCompositionEnabled())
            {
                // Get the current window handle
                IntPtr mainWindowPtr = new WindowInteropHelper(this).Handle;
                HwndSource mainWindowSrc = HwndSource.FromHwnd(mainWindowPtr);
                mainWindowSrc.CompositionTarget.BackgroundColor = Colors.Transparent;

                this.Background = Brushes.Transparent;

                // Set the proper margins for the extended glass part
                MARGINS margins = new MARGINS();
                margins.cxLeftWidth = -1;
                margins.cxRightWidth = -1;
                margins.cyTopHeight = -1;
                margins.cyBottomHeight = -1;

                int result = DwmExtendFrameIntoClientArea(mainWindowSrc.Handle, ref margins);

                if (result < 0)
                {
                    MessageBox.Show("An error occured while extending the glass unit.");
                }
            }
        }
    }
}

[StructLayout(LayoutKind.Sequential)]
public class MARGINS
{
    public int cxLeftWidth, cxRightWidth,
        cyTopHeight, cyBottomHeight;
}