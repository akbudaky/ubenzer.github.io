SciLor's grooveshark(tm).com Downloader v0.4.8 Beta
                            i.
                            .7.
                           .. :v
                          c:  .X
                           i.::
                             :
                            ..i..
                           #MMMMM
                           QM  AM
                           9M  zM
                           6M  AM
                           2M  2MX#MM@1.
                           OM  tMMMMMMMMMM;
                      .X#MMMM  ;MMMMMMMMMMMMv
                  cEMMMMMMMMMU7@MMMMMMMMMMMMM@
            .n@MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
           MMMMMMMM@@#$BWWB#@@#$WWWQQQWWWWB#@MM.
           MM                                ;M.
           $M                                EM
           WMO$@@@@@@@@@@@@@@@@@@@@@@@@@@@@#OMM
           #M                                cM
           QM         Another Cake by        tM
           MM              SciLor            CMO
        .MMMM                                oMMMt
       1MO 6MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM iMM
      .M1  BM     For all Portal Lovers!     vM  ,Mt
      1M   @M............................... WM   M6
       MM  .A8OQWWWWWWWWWWWWWWWWWWWWWWWWWWWOAz2  #M
        MM                                      MM.
         @MMY                                vMME
           UMMMbi                        i8MMMt
              C@MMMMMbt;;i.......i;XQMMMMMMt
                   ;ZMMMMMMMMMMMMMMM@A;.

ReadMe

You will need the .NET Framework 4.0

SciLor's grooveshark(tm).com Downloader is a tool for downloading and playing music from grooveshark(tm).com.
I am not responsible for any violations to the Terms of Use of grooveshark(tm).com this tool may do. It is more or less a proove of concept. 

I am not related to grooveshark(tm).com in any way!

ToDo:

Additional:
If you create a file named "customIcon.ico" in the SciLor's grooveshark(tm).com Downloader directory you can override the icon in the taskbar (Requested by a user)

Known Bugs:

If you like my hard work PLEASE DONATE! :)
http://www.scilor.com/donate.html

ChangeLog:

v0.4.8 Beta(2011-01-04)
-Enhancement: Faster inital connect :)
-Fix: Improved autoartistsearch (crashes/bugs)

-----------------------

v0.4.7 Beta(2011-01-04)
-Feature: Language Engine :), including some translations(catalan, french, german, germanbavarian, portuguese, spanish, swedish) Thanks fly out to all translators!
-Feature: Click on Search result marks/unmarks it
-Feature: Mark your results, right click and Select!
-Feature: Search Autocomplete :)
-Enhancement: Better resizing of the Controls to fit longer/shorter language strings ;)

v0.4.6 Beta(2010-12-22)
-Feature: Go to download directory(May have problems with long paths) under the "Extra" menu entry ("mniGoToDownloadDir" in the Skinfile!)
-Fix: Change on the grooveshark(tm).com Website made some problems ;)

v0.4.5 Beta(2010-12-15)
-Fix: Problems with loading Skin if starting from Shortcut(thanks fly out to anerathil)

v0.4.4 Beta(2010-12-12)
-Feature: Import Batch Search & Add from file (New button in the skin "btnImportBatch")
-Feature: Skip/Overwrite/Autorename existing files (New radiobuttons "rbtExistingSkip"/"rbtExistingOverwrite"/"rbtExistingAutoRename"
-Fix: Counting from one instead of zero (deleting)

v0.4.3 Beta(2010-12-03)
-Fix: Cowbell error fixed ;)

v0.4.2 Beta(2010-12-02)
-Feature: Right click any song to search for all songs having the same album or same artist :)
-Enhancement: Timeout set to 10 from 5 seconds
-Fix: Possible crash on Timeout on reconnect
-Fix: Broken downloadlists should be handled correctly now!

v0.4.1 Beta(2010-11-25)
-Feature: Recover Downloadlist on Startup(May need admin rights!)
-Enhancement: Most things are now working in an extra thread (Downloading etc.) to make the app more responsible
-Fix: Icon was broken
-Fix: Sorting of the download list would cause errors, now it's disabled

v0.4.0 Beta(2010-11-23)
-New: .Net Framework 4.0 should be needed (untested)
-New: Completely new WPF based Window that can be skinned by your needs if you are able to write in XAML
-Enhancement: Auto reconnect on token error. If it fails 2 times in a row an error is thrown

v0.3.9 Beta(2010-10-21)
-Fix: Wrong sorted playlists fixed
-Fix: Possible crash on loading playlists.

v0.3.8 Beta(2010-10-21)
-Enhancement: Auto check for updates on startup
-Feature: Download your playlists from grooveshark(tm).com :)

v0.3.7 Beta(2010-10-12)
-Enhancement: Select All etc.
-Feature: Batch Search & Add.
-Feature: Custom Icon via "customIcon.ico"

v0.3.6 Beta(2010-09-16)
-Enhancement: Experimental reconnect dialog on invalid token
-Enhancement: Reconnect Button

v0.3.5 Beta(2010-09-07)
-Enhancement: misterious "privacy" ;)
-Fix: New revision

v0.3.4 Beta(2010-07-10)
-Enhancement: Better error handling (especially on wrong incoming data)
-New: Uncheck all checked search results after adding them to the download list (Can be disabled in the settings)
-Fix: Filename handling now allows directories again.

v0.3.3 Beta(2010-07-06)
-Enhancement: Better error handling
-Feature: Check by click on entry
-Feature: Immediately download abortion
-New: Nice icon
-Fix: Config.xml and missing administration rights
-Fix: Real use of repaired filenames

v0.3.2 Beta(2010-06-26)
-New: Settings dialog, including selection of the download directory and the song renaming patterns
-Feature: Popular song search
-Feature: Delete songs of the download list with a click
-Enhancement: Better error handling and Debug log
-Fix: Enter key to start search

v0.3.1 Beta(2010-06-23)
-Quickfix: Crash on any search...

v0.3.1 Alpha(2010-06-23)
-Enhancement: New revision, country fix included ;)
-Fix: Crashes on illegal file characters in track names
-Fix: Language specific characters fixed (letters with circumflexes, points, umlauts etc.)

v0.3 Alpha(2010-05-09)
-Enhancement: New API and new form.

v0.2.3 Beta(2010-04-15)
-Enhancement: GrooveFix.xml for easy fix for token and client problems.
-Fix: New clientRevision on grooveshark(tm).com
-Fix: New staticRandomizer on grooveshark(tm).com

v0.2.2 Beta(2010-03-24)
-Fix: I fixed another revision change :)
-Feature: SciLor's Update Checker included ;)

v0.2.1 Beta(2010-02-23)
-Fix: Big change adjusted, working but it is very dirty ;)

v0.2 Beta(2010-01-31)
-Fix: I fixed another revision change :)
-Fix: I fixed a token change :)

v0.2 Alpha (2009-12-11)
-Fix: New Grooveshark Client Revision

v0.1 Alpha (2009-11-15)
-Initial Release


---------------LINKS-------------------------
My Website: http://www.scilor.com/
SciLor's grooveshark(tm).com Downloader Website: http://www.scilor.com/grooveshark-downloader.html
Donation: http://www.scilor.com/donate.html
-