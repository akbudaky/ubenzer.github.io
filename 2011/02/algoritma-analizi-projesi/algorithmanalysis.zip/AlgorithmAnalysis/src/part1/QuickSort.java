package part1;

public class QuickSort {

    private long runTime = 0;
    private static long count = 0;
    private long samples = 0;
    private int[] sortedArray;

    public void execute(int[] unsortedArray, long samples) {        
        this.samples = samples;
        long startTime = System.nanoTime();
        for (int i = 0; i < samples; i++) {
            sortedArray = unsortedArray.clone();
            quickSort(sortedArray, 0, sortedArray.length - 1);
        }
        long estimatedTime = System.nanoTime() - startTime;
        this.runTime = estimatedTime;
    }

    public long getRunningTime() {
        return runTime / samples;
    }

    public static void quickSort(int A[], int p, int r) {
        int q;
        if (p < r) {
            q = partition(A, p, r);
            quickSort(A, p, q - 1);
            quickSort(A, q + 1, r);
        }
    }

    public static int partition(int A[], int p, int r) {
        int tmp;
        int x = A[r];
        int i = p - 1;

        for (int j = p; j <= r - 1; j++) {
            if (A[j] <= x) { // key comparison burası.
                i++;
                tmp = A[i];
                A[i] = A[j];
                A[j] = tmp;
            }
            count++; // key comparison'ı da burada sayıyor. 
        }
        tmp = A[i + 1];
        A[i + 1] = A[r];
        A[r] = tmp;
        return i + 1;
    }

    public long getNumberOfKeyComparasions() {
        return count / samples;
    }

    public long getNumberOfSamples() {
        return this.samples;
    }

    public int[] getSortedArray() {
        return this.sortedArray;
    }
}
