package part2;

public class Item {
    public String item;
    public int weight;
    public int value;

    public Item(String item, int weight, int value) {
        this.item = item;
        this.weight = weight;
        this.value = value;
    }
}
