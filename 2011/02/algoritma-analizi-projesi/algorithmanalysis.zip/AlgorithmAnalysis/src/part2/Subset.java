package part2;

import java.util.ArrayList;

public class Subset {

    ArrayList<Item> items = new ArrayList<Item>();
    int weight = 0;
    int value = 0;

    public int getWeight() {
        return weight;
    }

    public int getValue() {
        return value;
    }

    public void addItem(Item item, boolean toBeginning) {
        if(toBeginning) {
            items.add(0, item);
        } else {
            items.add(item);
        }
        weight += item.weight;
        value += item.value;
    }
    public void addItem(Item item) {
        this.addItem(item, false);
    }

    @Override
    public String toString() {
        String dondurulecek = "";
        for(Item i : items) {
            dondurulecek += i.item + ", ";
        }
        return dondurulecek + "Weight: " + this.getWeight() + ", Value: " + this.getValue();
    }
}
