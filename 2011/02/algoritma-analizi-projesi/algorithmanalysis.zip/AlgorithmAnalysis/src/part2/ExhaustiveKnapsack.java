package part2;

public class ExhaustiveKnapsack {
    private boolean writeLog = false;
    private String logString = "";
    private long runningTime = 0;

    public void execute(Item[] items, int capacity) {
        this.execute(items, capacity, 1);
    }
    public void execute(Item[] items, int capacity,long samples) {
        writeLog = true;
        exhaustiveKnapsack(items, capacity);
        writeLog = false;        
        long startTime = System.nanoTime();
        for (int i=0; i < samples; i++) {
            exhaustiveKnapsack(items, capacity);
        }
        long estimatedTime = System.nanoTime() - startTime;
        log("Total running time " + estimatedTime + " nanoseconds.",true);
        log("Mean running time is " + estimatedTime / samples + " nanoseconds.",true);
        runningTime = estimatedTime / samples;
        log(samples + " samples.",true);
        log("--------------------------");
        log("");
    }
    public long getRunningTime() {
        return runningTime;        
    }
    private void log(String in, boolean override) {
         if(writeLog ||override) {
             logString += in + "\n";
         }
    }
    private void log(String in) {
        this.log(in, false);
    }
    public String getLog() {
        return this.logString;
    }
    private void exhaustiveKnapsack(Item[] items, int capacity) {
        Subset bestSubset = null;
        int toplamSonuc = (int) java.lang.Math.pow(2,items.length);
        for (int i = 0; i < toplamSonuc; i++) {
            String mask = Integer.toBinaryString(i);
            mask = reverseIt(mask);
            Subset ss = new Subset();
            for (int j = 0; j < mask.length(); j++) {
                if (mask.charAt(j) == '1') {
                    ss.addItem(items[j]);
                }
            }
            log("Subset #" + i + ": " + ss);
            if (bestSubset == null || (ss.weight <= capacity && ss.value > bestSubset.value)) {
                bestSubset = ss;
            }
        }
        log("--------------------------");
        log("RESULT: " + bestSubset);
    }

    private String reverseIt(String source) {
        int i, len = source.length();
        StringBuilder dest = new StringBuilder(len);

        for (i = (len - 1); i >= 0; i--)
            dest.append(source.charAt(i));
        return dest.toString();
  }
}
