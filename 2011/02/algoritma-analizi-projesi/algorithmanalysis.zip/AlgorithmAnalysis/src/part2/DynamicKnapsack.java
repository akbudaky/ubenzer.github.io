package part2;

public class DynamicKnapsack {
    private boolean writeLog = false;
    private String logString = "";
    private long runningTime = 0;

    public void execute(Item[] items, int capacity) {
        this.execute(items, capacity, 1);
    }    
    public void execute(Item[] items, int capacity, long samples) {
        writeLog = true;
        dynamicKnapsack(items, capacity);
        writeLog = false;
        long startTime = System.nanoTime();
        for (int i=0; i < samples; i++) {
            dynamicKnapsack(items, capacity);
        }
        long estimatedTime = System.nanoTime() - startTime;
        log("Total running time " + estimatedTime + " nanoseconds.",true);
        log("Mean running time is " + estimatedTime / samples + " nanoseconds.",true);
        runningTime = estimatedTime / samples;
        log(samples + " samples.",true);
        log("--------------------------");
        log("");
    }
    public long getRunningTime() {
        return runningTime;
    }
    private void log(String in, boolean override, boolean addNewLine) {
        if(writeLog ||override) {
             logString += in + (addNewLine ? "\n" : "");
        }
    }
    private void log(String in, boolean override) {
        this.log(in, override, true);
    }
    private void log(String in) {
        this.log(in, false, true);
    }
    public String getLog() {
        return this.logString;
    }
    private void dynamicKnapsack(Item[] items, int capacity) {
        int[][] V = new int[items.length + 1][capacity + 1];

        for(int j = 1; j < V[0].length;j++) {
            for (int i = 1; i < V.length; i++) {
                if(j-items[i-1].weight < 0) {
                    V[i][j] = V[i-1][j];
                } else {
                    if(V[i-1][j] > items[i-1].value + V[i-1][j-items[i-1].weight] ) {
                        V[i][j] = V[i-1][j];
                    } else {
                        V[i][j] = items[i-1].value + V[i-1][j-items[i-1].weight];
                    }                    
                }
            }
        }

        Subset sonuc = new Subset();
        int item = V.length-1;
        int weight = V[0].length-1;
        while(item > 0) {
            while(item > 0 && V[item][weight] == V[item-1][weight] ) {
                item--;
            }
            if(item == 0) break;
            sonuc.addItem(items[item-1],true);
            weight -= items[item-1].weight;
            item--;
        }

        for(int j = 0; j < V[0].length;j++) {
            for (int i = 0; i < V.length; i++) {
                java.text.DecimalFormat nft = new java.text.DecimalFormat("000");
                nft.setDecimalSeparatorAlwaysShown(false);
                log(nft.format(V[i][j]) + "\t",false,false);

            }
            log("");
        }
        log("--------------------------");
        log("RESULT: " + sonuc);
    }
}
