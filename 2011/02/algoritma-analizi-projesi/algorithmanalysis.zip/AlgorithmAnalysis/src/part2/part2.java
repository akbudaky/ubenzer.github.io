package part2;

import java.util.ArrayList;
import java.util.Random;
import util.MyReader;
import util.MyWriter;

public class part2 {
    static private String logString = "";


    public static void execute(String inputFile, String outputFile, long COUNT) {
        MyReader parser = new MyReader(inputFile);
        int itemCount;
        int capacity = 0;
        Item[] items = null;
        try {
            capacity = parser.getCapacity();
            itemCount = parser.getItemCount();
            items = parser.getItems(itemCount);
        } catch (Exception ex) {
            System.out.println("Reading file error: " + ex.getMessage());
            System.exit(-1);
        }

        System.out.println("Running EXHAUSTIVE algorithm...");
        System.out.println();
        ExhaustiveKnapsack e = new ExhaustiveKnapsack();
        e.execute(items,capacity,COUNT);
        System.out.println(e.getLog());

        System.out.println("Running DYNAMIC algorithm...");
        System.out.println();
        
        DynamicKnapsack d = new DynamicKnapsack();
        d.execute(items,capacity,COUNT);
        System.out.println(d.getLog());

        MyWriter write = new MyWriter(outputFile, "UTF-8");
        try {
            write.write(e.getLog());
            write.write(d.getLog());
        } catch (Exception ex) {
            System.out.println("Writing file error: " + ex.getMessage());
            System.exit(-2);
        }

        System.out.println("Completed. :)");
    }

    private static void doTests(int minItem, int maxItem, int minCapacity, int maxCapacity, long COUNT) {
        Random randomGenerator = new Random();

        log("From " + minItem + " to " + maxItem + " Item." );
        log("From " + minCapacity + " to " + maxCapacity + " Capacity." );
        log("Sample count: " + COUNT);

        for (int i = minCapacity; i <= maxCapacity; i++) {

            ArrayList<Item[]> generated = new ArrayList<Item[]>();
            for (int j = minItem; j <= maxItem; j++) {
                Item[] items = new Item[j];
                for (int k=0; k<j;k++) {
                    items[k] = new Item("Item #" + k+1, randomGenerator.nextInt(99)+1,randomGenerator.nextInt(99)+1);
                }
                generated.add(items);
            }

            log("EXHAUSTIVE - CAPACITY: " + i + " ITEM: " + minItem + " to " + maxItem);
            for (int j = minItem; j <= maxItem; j++) {
                Item[] items = generated.get(j-minItem);

                ExhaustiveKnapsack e = new ExhaustiveKnapsack();
                e.execute(items,i,COUNT);
                log(e.getRunningTime() + "");
            }
  
            log("DYNAMIC - CAPACITY: " + i + " ITEM: " + minItem + " to " + maxItem);
            for (int j = minItem; j <= maxItem; j++) {
                Item[] items = generated.get(j-minItem);

                DynamicKnapsack d = new DynamicKnapsack();
                d.execute(items,i,COUNT);
                log(d.getRunningTime() + "");
            }
        }

        log("The end!");
    }
    private static void log(String in) {
        logString += in + "\n";
        System.out.println(in);
    }
    public static void benchmark(String outputFile, long sampleCount, int fromItem, int toItem, int fromCapacity, int toCapacity) {
        MyWriter write = new MyWriter(outputFile, "UTF-8");
        
        doTests(fromItem,toItem,fromCapacity,toCapacity,sampleCount);
        try {
            write.write(logString);
        } catch (Exception ex) {
            System.out.println("Writing file error: " + ex.getMessage());
            System.exit(-1);
        }
    }
}