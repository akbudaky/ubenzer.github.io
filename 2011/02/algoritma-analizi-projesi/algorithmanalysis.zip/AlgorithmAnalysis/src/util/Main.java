package util;
import part1.part1;
import part2.part2;

public class Main {
    /**
     *
     * @params: p1 inputFileName outputFileName [sampleCount]
     * @params: p2 inputFileName outputFileName [sampleCount]
     * @params: p1benchmark outputFileName sampleCount fromItem toItem stepSize
     * @params: p2benchmark outputFileName sampleCount fromItem toItem fromCapacity toCapactiy
     */
    public static void main(String... aArgs) {

        writeHello();
        
        long sampleCount = 1000;
        if(aArgs.length < 3) {
            System.out.println("Missing parameter!");
            System.exit(-1);
        }
        if((aArgs[0].equalsIgnoreCase("p1") || aArgs[0].equalsIgnoreCase("p2")) && aArgs.length > 4) {
            System.out.println("Too many parameters!");
            System.exit(-1);
        } else if ((aArgs[0].equalsIgnoreCase("p1benchmark")) && aArgs.length > 6 ) {
            System.out.println("Too many parameters!");
            System.exit(-1);
        } else if ((aArgs[0].equalsIgnoreCase("p2benchmark")) && aArgs.length > 7 ) {
            System.out.println("Too many parameters!");
            System.exit(-1);
        }

        if((aArgs[0].equalsIgnoreCase("p1") || aArgs[0].equalsIgnoreCase("p2")) && aArgs.length > 3) {
            try {
                sampleCount = Integer.parseInt(aArgs[3]);
                if(sampleCount < 1) throw new Exception("Sample count is too low.");
            } catch (Exception e) {
                System.out.println("Some parameters are not valid: " + e.getMessage());
                System.exit(-1);
            }
        }
        
        if(aArgs[0].equalsIgnoreCase("p1")) {
            part1.execute(aArgs[1],aArgs[2],sampleCount);
        } else if(aArgs[0].equalsIgnoreCase("p2")) {
           part2.execute(aArgs[1],aArgs[2],sampleCount);
        } else if(aArgs[0].equalsIgnoreCase("p1benchmark")) {
            int fromItem=0, toItem=0, stepSize=1;
            try {
                sampleCount = Integer.parseInt(aArgs[2]);
                fromItem = Integer.parseInt(aArgs[3]);
                toItem = Integer.parseInt(aArgs[4]);
                stepSize = Integer.parseInt(aArgs[5]);
                if(stepSize < 1) throw new Exception("Step size is not valid.");
                if(fromItem < 0 || toItem < 0 || fromItem > toItem) throw new Exception("From/to items are not valid.");
            } catch (Exception e) {
                System.out.println("Some parameters are not valid: " + e.getMessage());
                System.exit(-1);
            }
            part1.benchmark(aArgs[1],sampleCount,fromItem,toItem,stepSize);

        } else if(aArgs[0].equalsIgnoreCase("p2benchmark")) {
            int fromItem=0, toItem=0, fromCapacity=1, toCapacity=10;
            try {
                sampleCount = Long.parseLong(aArgs[2]);
                fromItem = Integer.parseInt(aArgs[3]);
                toItem = Integer.parseInt(aArgs[4]);
                fromCapacity = Integer.parseInt(aArgs[5]);
                toCapacity = Integer.parseInt(aArgs[6]);
                if(fromCapacity < 0 || toCapacity < 0 || fromCapacity > toCapacity) throw new Exception("From/to capacities are not valid.");
                if(fromItem < 0 || toItem < 0 || fromItem > toItem) throw new Exception("From/to items are not valid.");
            } catch (Exception e) {
                System.out.println("Some parameters are not valid: " + e.getMessage());
                System.exit(-1);
            }
            part2.benchmark(aArgs[1],sampleCount,fromItem,toItem,fromCapacity,toCapacity);
        } else {
            System.out.println("First parameter is wrong.");
            System.exit(-1);
        }
        System.exit(0);
    }
    public static void writeHello() {
        System.out.println();
        System.out.println("ALGORITHM ANALYSIS PROJECT");
        System.out.println("--------------------------");
        System.out.println("05-06-7670 Umut BENZER http://www.ubenzer.com/");
        System.out.println("05-07-8496 Ozlem GURSES");
        System.out.println("05-07-8569 Savas YILDIZ");
        System.out.println("--------------------------");
        System.out.println();
    }
}
