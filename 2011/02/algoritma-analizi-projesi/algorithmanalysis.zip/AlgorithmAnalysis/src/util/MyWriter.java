package util;

import java.io.*;

public final class MyWriter {
  /** Constructor. */
  public MyWriter(String aFileName, String aEncoding){
    fEncoding = aEncoding;
    fFileName = aFileName;
  }

  /** Write fixed content to the given file. */
  public void write(String text) throws IOException  {
    OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(fFileName), fEncoding);
    try {
      out.write(text);
    }
    finally {
      out.close();
    }
  }

  private final String fFileName;
  private final String fEncoding;

}
