package util;

import java.io.*;
import java.util.Scanner;
import part2.Item;

public class MyReader {
    /**
    Constructor.
    @param aFileName full name of an existing, readable file.
    */
    public MyReader(String aFileName){
        fFile = new File(aFileName);
    }
    private final File fFile;

    public int getCapacity() throws Exception {
        Scanner scanner = new Scanner(new FileReader(fFile));
        String value = null;
        try {
            if (scanner.hasNextLine()) {
                Scanner ilksatir = new Scanner(scanner.nextLine());
                ilksatir.useDelimiter("=");
                if (ilksatir.hasNext()) {
                    ilksatir.next();
                    value = ilksatir.next();
                    //System.out.println("capacity is " + value.trim());
                }
                else {
                    throw new Exception("Capacity cannot be read.");
                }
            } else {
                throw new Exception("Line count is too low.");
            }
        } finally {
          scanner.close();
        }
        int dondurulecek = 0;
        try {
            dondurulecek = Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            throw e;
        }
        return dondurulecek;
    }

    public Item[] getItems(int boyut) throws Exception {
        
        Scanner scanner = new Scanner(new FileReader(fFile));
        Item[] dondurulecek = new Item[boyut];
     
        try {
            if (scanner.hasNextLine()) {
                scanner.nextLine();
                scanner.nextLine();
            } else {
                throw new Exception("Line count is less than two.");
            }
            int sayac = 0;
            while(scanner.hasNextLine()) {
                String item;
                String weight;
                String value;

                Scanner satir = new Scanner(scanner.nextLine());
                satir.useDelimiter("\t");
                if (satir.hasNext()) {
                    item = satir.next();
                    weight = satir.next();
                    value = satir.next();
                    //System.out.println("Item #" + item.trim() + "\t W: " + weight.trim() + "\t V:" + value.trim());
                }
                else {
                    throw new Exception("One of the item lines is corrputed.");
                }

                try {
                    dondurulecek[sayac] = new Item(item, Integer.parseInt(weight.trim()), Integer.parseInt(value.trim()));
                    sayac++;
                } catch (Exception e) {
                    throw e;
                }                
            }
        } finally {
          scanner.close();
        }
        return dondurulecek;
    }

    public int getItemCount() throws Exception {
        Scanner scanner = new Scanner(new FileReader(fFile));
        int sayac = 0;
        try {
            if (scanner.hasNextLine()) {
                scanner.nextLine();
                scanner.nextLine();
            } else {
                throw new Exception("Line count is less than two.");
            }
            while(scanner.hasNextLine()) {
                sayac++;
                scanner.nextLine();
            }
        } finally {
          scanner.close();
        }
        return sayac;
    }
    public int[] getArrayBound(int size) throws Exception {
        Scanner scanner = new Scanner(new FileReader(fFile));
        Scanner satir = new Scanner(scanner.nextLine());
        int[] dondur = new int[size];
        int i=0;
        satir.useDelimiter(" ");
        try {
            if(satir.hasNext()) {
                dondur[i++]=Integer.parseInt(satir.next());
            }
            while(satir.hasNext()){
                dondur[i++]=Integer.parseInt(satir.next());
            }
        } finally {
          scanner.close();
        }
        return dondur;
    }

    public int getSize() throws Exception{
        int size=0;
        Scanner scanner = new Scanner(new FileReader(fFile));
        scanner.useDelimiter(" ");
        try {
            while(scanner.hasNext()) {
                size++;
                scanner.next();
            }
        } finally {
          scanner.close();
        }
        return size;
    }
}
