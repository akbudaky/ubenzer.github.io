import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;

public final class Main {

  private final static Set<Integer[]> possibleActions = new HashSet<Integer[]>();
  /* Aynı adımlarda dönüp durmamak için, gidilen adımların listesi */
  private final static Set<Integer[]> traversedStates = new HashSet<Integer[]>();
  /* Missionaries, Cannibals, Ship on the left side. */
  private final static Integer[] startingArray = { 3, 3, 1 };
  private final static Integer[] solutionArray = { 0, 0, 0 };
  /* BFS için çok basit bir kuyruk */
  private final static Queue<Object[]> queue = new LinkedBlockingQueue<Object[]>();
  static {
    possibleActions.add(new Integer[] { 2, 0, 1 });
    possibleActions.add(new Integer[] { 1, 0, 1 });
    possibleActions.add(new Integer[] { 1, 1, 1 });
    possibleActions.add(new Integer[] { 0, 1, 1 });
    possibleActions.add(new Integer[] { 0, 2, 1 });
  }

  @SuppressWarnings("unchecked")
  public static void main(String[] args) {
    /* Başlangıç durumunu BFS'e atıp işlemi başlatalım. */
    queue.add(new Object[] { startingArray, new ArrayList<Integer[]>() });

    while (!queue.isEmpty()) {
      Object[] next = queue.poll();
      cannibalisticBFS((Integer[]) next[0], (List<Integer[]>) next[1]);
    }
    System.out.print("Çözümsüz...");
  }

  /**
   * İki arrayin elemanlarını kontrol ederek eşitliğini bulan, büyük ihtimalle
   * JAVA'da zaten olan, ama benim nedense bulamadığım basit fonksiyon.
   * @param array1
   * @param array2
   * @return
   */
  private static boolean arrayEquals(Integer[] array1, Integer[] array2) {
    if(array1 == null || array2 == null) {
      return false;
    }
    if(array1.length != array2.length) {
      return false;
    }
    for(int i=0;i<array1.length;i++) {
      if((array1[i] == null || array2[i] == null) && !(array1[i] == null && array2[i] == null)) {
        return false;
      }
      if(array1[i] != array2[i]) {
        return false;
      }
    }
    return true;
  }
  private static void cannibalisticBFS(Integer[] theArray, List<Integer[]> moveHistory) {
    /* Zaten göz önüne aldığımız statei bir daha göz önüne almayalım. */
    for(Integer[] state: traversedStates) {
      if(arrayEquals(state, theArray)) {
        return;
      }
    }      
    traversedStates.add(theArray);
    List<Integer[]> newMoveHistory = new ArrayList<Integer[]>();
    newMoveHistory.addAll(moveHistory);
    newMoveHistory.add(theArray);

    if (arrayEquals(solutionArray,theArray)) {
      System.out.println("Çözüm bulundu. Adım sayısı: " + moveHistory.size());
      System.out.println("---------------");
      System.out.println("Ada 0\t\t\tAda 1");
      System.out.println("Misy\tYamyam\tGemi\tMisy\tYamyam\tGemi");
      for (Integer[] step : newMoveHistory) {
        System.out.println(step[0] + "\t" + step[1] + "\t" + step[2] + "\t" + (startingArray[0] - step[0]) + "\t" + (startingArray[1] - step[1]) + "\t" + (startingArray[2] - step[2]) + "\t");
      }
      System.exit(0);
    }
    
    int gidisYonu = (theArray[2] == 1) ? +1 : -1;
    for (Integer[] action : possibleActions) {
      Integer[] theForArray = theArray.clone();
      /* generate a possible move */
      for (int i = 0; i < action.length; i++) {
        theForArray[i] -= action[i] * gidisYonu;
      }

      /* is it feasible ? */
      if (theForArray[0] >= theForArray[1] && theForArray[1] >= 0 && theForArray[2] >= 0 && theForArray[0] <= startingArray[0] && theForArray[2] <= startingArray[2]) {
        queue.add(new Object[] { theForArray, newMoveHistory });
      }
    }
  }
}
