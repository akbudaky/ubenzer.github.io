package knapsack;

import java.util.Random;

import genetics.Generation;
import genetics.GeneticsConfiguration;
import genetics.GeneticsConfiguration.CandinateFitnessType;
import util.MyReader;


public class Main {

  public static String buffer = "";
  public static String buffer2 = "";
  
  public static void main(String[] args) {
    String inputFile = "input.txt";
    if(args.length > 1) {
      inputFile = args[1];
    }
    
    MyReader parser = new MyReader(inputFile);
    int itemCount;
    int capacity = 0;
    Item[] items = null;
    
    try {
        capacity = parser.getCapacity();
        itemCount = parser.getItemCount();
        items = parser.getItems(itemCount);
    } catch (Exception ex) {
        System.out.println("Reading file error.");
        ex.printStackTrace();
        System.exit(-1);
    }
    
    long timeFirst, timeSecond;
    
    timeFirst = System.currentTimeMillis();
    knapsackWithOnePointCrossover(capacity, items);
    timeSecond = System.currentTimeMillis();
    System.out.println("100 generations of single point crossover with 32 chrosomes took " + (timeSecond - timeFirst) + " miliseconds to compute.");
    
    System.out.println("-----------------------------------------------------");
    
    timeFirst = System.currentTimeMillis();
    knapsackWithOneAndThenOtherCrossover(capacity, items);
    timeSecond = System.currentTimeMillis();
    System.out.println("100 generations of one and than other with 32 chrosomes crossover took " + (timeSecond - timeFirst) + " miliseconds to compute.");
    
  
    System.out.println("-----------------------------------------------------");
    
    timeFirst = System.currentTimeMillis();
    knapsackWithSmartCrossover(capacity, items);
    timeSecond = System.currentTimeMillis();
    System.out.println("100 generations of intellegent crossover with 32 chrosomes crossover took " + (timeSecond - timeFirst) + " miliseconds to compute.");
   
    System.out.println("-----------------------------------------------------");
    
    timeFirst = System.currentTimeMillis();
    knapsackWithTwoPointCrossover(capacity, items);
    timeSecond = System.currentTimeMillis();
    System.out.println("100 generations of two point crossover with 32 chrosomes crossover took " + (timeSecond - timeFirst) + " miliseconds to compute.");
  
    }

  private static void knapsackWithTwoPointCrossover(int capacity, Item[] items) {
    GeneticsConfiguration conf = new GeneticsConfiguration(32, 200, CandinateFitnessType.MORE_IS_BETTER, new KnapsackTwoPointCrossoverCandinateFunction (), 1, false, 0.05, 2, new KnapsackMutationFunction());
    Generation.createGenerations(generateRandomFirstChrosomes(capacity, items, conf), conf);     
  }

  private static void knapsackWithSmartCrossover(int capacity, Item[] items) {
    GeneticsConfiguration conf = new GeneticsConfiguration(32, 200, CandinateFitnessType.MORE_IS_BETTER, new KnapsackIntelligentCrossoverCandinateFunction(), 1, false, 0.05, 2, new KnapsackMutationFunction());
    Generation.createGenerations(generateRandomFirstChrosomes(capacity, items, conf), conf); 
  }

  private static void knapsackWithOneAndThenOtherCrossover(int capacity, Item[] items) {
    GeneticsConfiguration conf = new GeneticsConfiguration(32, 200, CandinateFitnessType.MORE_IS_BETTER, new KnapsackOneAndOtherCrossoverCandinateFunction(), 1, false, 0.05, 2, new KnapsackMutationFunction());
    Generation.createGenerations(generateRandomFirstChrosomes(capacity, items, conf), conf);
  }

  protected static void knapsackWithOnePointCrossover(int capacity, Item[] items) {
    GeneticsConfiguration conf = new GeneticsConfiguration(32, 200, CandinateFitnessType.MORE_IS_BETTER, new KnapsackSinglePointCrossoverCandinateFunction(), 1, false, 0.05, 2, new KnapsackMutationFunction());
    Generation.createGenerations(generateRandomFirstChrosomes(capacity, items, conf), conf);
  }

  protected static Generation generateRandomFirstChrosomes(int capacity, Item[] items, GeneticsConfiguration conf) {
    KnapsackChrosome[] chrosomes;
    Generation firstGen;
    chrosomes = new KnapsackChrosome[conf.getChrosomeCount()];
    for(int i=0;i<conf.getChrosomeCount();i++) {
      Item[] chrosomeGene = new Item[items.length];
      for(int ii=0;ii<items.length;ii++) {
        Random r = new Random();
        
        Item itt = items[ii];
        chrosomeGene[ii] = itt.clone();
        chrosomeGene[ii].setSelected(r.nextBoolean());
      }
      
      chrosomes[i] = new KnapsackChrosome(chrosomeGene, conf, capacity);      
    }
    firstGen = new Generation(conf, chrosomes);
    return firstGen;
  }
}
