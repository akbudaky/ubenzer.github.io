package knapsack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.ArrayUtils;

import genetics.Generation;
import genetics.GeneticsConfiguration.CandinateFitnessType;
import genetics.interfaces.CrossoverFunctionInterface;

public class KnapsackOneAndOtherCrossoverCandinateFunction implements CrossoverFunctionInterface {

  @Override
  public Generation generate(Generation currentGeneration) {
       
    Arrays.sort(currentGeneration.getChrosomes());

    if(currentGeneration.getConf().getCandinateFitnessType() == CandinateFitnessType.MORE_IS_BETTER) {
      ArrayUtils.reverse(currentGeneration.getChrosomes());
    }    
    KnapsackChrosome[] newGenerationChrosomes = new KnapsackChrosome[currentGeneration.getChrosomes().length];
    
    // elitsm
    for(int i=0;i<currentGeneration.getConf().getDirectlyInheriedChrosomeCount();i++) {
      newGenerationChrosomes[i] = currentGeneration.getChrosomes()[i];      
    }
    
    for (int a = currentGeneration.getConf().getDirectlyInheriedChrosomeCount(); a < currentGeneration.getChrosomes().length; a++) {
      List<KnapsackChrosome> rankSelectible = new ArrayList<KnapsackChrosome>();
      for (int i = 0; i < currentGeneration.getChrosomes().length; i++) {
        for (int ii = i; ii < currentGeneration.getChrosomes().length; ii++) {
          rankSelectible.add(currentGeneration.getChrosomes()[i]);
        }
      }
      
      Random r = new Random();
      KnapsackChrosome leftCh = rankSelectible.get(r.nextInt(rankSelectible.size()));
      while (rankSelectible.remove(leftCh)) {
      }
      KnapsackChrosome rightCh = rankSelectible.get(r.nextInt(rankSelectible.size()));
      Item[] combinedChrosome = new Item[leftCh.getGenes().length];
      
      for (int i = 0; i < leftCh.getGenes().length; i++) {
        if (i%2 == 0) {
          combinedChrosome[i] = leftCh.getGenes()[i].clone();
        } else {
          combinedChrosome[i] = rightCh.getGenes()[i].clone();
        }
      }
      newGenerationChrosomes[a] = new KnapsackChrosome(combinedChrosome, currentGeneration.getConf(), ((KnapsackChrosome) (currentGeneration.getChrosomes()[0])).getBagLimit());
    }
    return new Generation(currentGeneration.getConf(), newGenerationChrosomes);
  }
}
