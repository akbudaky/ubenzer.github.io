package knapsack;

import java.util.Arrays;
import java.util.Random;

import org.apache.commons.lang3.ArrayUtils;

import genetics.Generation;
import genetics.GeneticsConfiguration.CandinateFitnessType;
import genetics.interfaces.MutationFunctionInterface;

public class KnapsackMutationFunction implements MutationFunctionInterface {
 
  @Override
  public Generation generate(Generation currentGeneration) {
    KnapsackChrosome[] mutatedChrosomes = new KnapsackChrosome[currentGeneration.getChrosomes().length];
    
    Arrays.sort(currentGeneration.getChrosomes());

    if(currentGeneration.getConf().getCandinateFitnessType() == CandinateFitnessType.MORE_IS_BETTER) {
      ArrayUtils.reverse(currentGeneration.getChrosomes());
    }
    
    for(int i=0; i<currentGeneration.getChrosomes().length;i++) {
      Item[] newGenes = new Item[currentGeneration.getChrosomes()[0].getGenes().length];
      
      int mutatedGeneCount = 0;
      for(int currentGene=0;currentGene<currentGeneration.getChrosomes()[0].genes.length;currentGene++) {
        newGenes[currentGene] = currentGeneration.getChrosomes()[i].genes[currentGene].clone();
    
        if(
            (
                !(!currentGeneration.getConf().isAllowMutationsInDirectlyInheritedChrosomes() && i < currentGeneration.getConf().getDirectlyInheriedChrosomeCount()) 
                || 
                currentGeneration.getConf().isAllowMutationsInDirectlyInheritedChrosomes()                
            ) && mutatedGeneCount < currentGeneration.getConf().getMaxMutatedGeneCountInAChrosome()) {        
          
          // hadi mutasyon yapalim.
          Random r = new Random();            
            if(r.nextDouble() < currentGeneration.getConf().getMutationProbobality()) {
              mutatedGeneCount++;            
              newGenes[currentGene].setSelected(!newGenes[currentGene].isSelected());            
            }     
        }
      }
      mutatedChrosomes[i] = new KnapsackChrosome(newGenes, currentGeneration.getConf(), ((KnapsackChrosome) (currentGeneration.getChrosomes()[0])).getBagLimit());
    }    
    return new Generation(currentGeneration.getConf(), mutatedChrosomes);
  }
}
