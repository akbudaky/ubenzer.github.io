package knapsack;

import genetics.GeneticsConfiguration;

public class KnapsackChrosome implements Comparable<KnapsackChrosome>{
  protected GeneticsConfiguration conf;
  protected Item[] genes;
  protected double bagLimit = 0;
  
  public KnapsackChrosome(Item[] genes, GeneticsConfiguration conf, double bagLimit) {
    this.conf = conf;
    this.genes = genes;
    this.bagLimit = bagLimit;
  }
  
  public Item[] getGenes() {
    return genes;
  }
  public void setGenes(Item[] genes) {
    this.genes = genes;
  }
  public int compareTo (KnapsackChrosome c) {
    return c.getChrosomeFitness() > this.getChrosomeFitness() ? -1 : c.getChrosomeFitness() < this.getChrosomeFitness() ? 1: 0;    
  }

  public double getBagLimit() {
    return this.bagLimit;
  }

  public double getChrosomeFitness() {
    
    double value = 0;
    double weight = 0;
    for(Item g: this.genes) {
      if(g.isSelected()) {
        value += g.getValue();
        weight += g.getWeight();
      }
    }
    
    if(weight > bagLimit) return 0;
    return value;
  }

  public String toString() {
    return String.valueOf(this.getChrosomeFitness());
  }
  
}
