package knapsack;

public class Item implements Cloneable { 
    private String item;
    private int weight;
    private int value;
    
    private boolean isSelected = false;

    public Item(String item, int weight, int value) {
      this(item, weight, value, false);
    }
    private Item(String item, int weight, int value, boolean isSelected) {
      this.item = item;
      this.weight = weight;
      this.value = value;
      this.isSelected = isSelected;
    }
    
    public String getItem() {
      return this.item;
    }

    public int getWeight() {
      return this.weight;
    }

    public int getValue() {
      return this.value;
    }
    

    public boolean isSelected() {
      return this.isSelected;
    }

    public void setSelected(boolean isSelected) {
      this.isSelected = isSelected;
    }

    public Item clone()  {
      return new Item(this.item, this.weight, this.value, this.isSelected);
    }

    public String toString() {
      return this.item + "\nWeight: " + this.weight + "\nValue: " + this.value + "\nSelected? " + this.isSelected;
    }
}
