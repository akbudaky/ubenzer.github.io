package genetics;

import genetics.interfaces.CrossoverFunctionInterface;
import genetics.interfaces.MutationFunctionInterface;

public class GeneticsConfiguration {
  public static enum CandinateFitnessType {
  MORE_IS_BETTER, LESS_IS_BETTER
  };

  private int chrosomeCount = 32; /* Bir nesildeki kromozom sayisi */
  private int generationCount = 100; /* Algoritma kac nesil boyunca isletilecek? */
  private CandinateFitnessType candinateFitnessType; /* Fitness için: az mi iyidir, cok mu? */
  private CrossoverFunctionInterface generateCandinatesFunction; /* Crossover algoritmasi referansi */
  private int directlyInheriedChrosomeCount = 1; /* Crossoversiz gecirilecek kromozom sayisi */
  private boolean allowMutationsInDirectlyInheritedChrosomes = false; /* CO'siz gecirilen kromozomlarda mutasyon yapilacak mi? */
  private double mutationProbobalityPerGene = 0.1; /* Gen basina mutasyon olasiligi */
  private int maxMutatedGeneCountInAChrosome = 2; /* Bir kromozomda en fazla kac gende mutasyon olabilir? */
  private MutationFunctionInterface mutationFunction; /* Mutasyon fonksiyouna referans */

  public GeneticsConfiguration(int chrosomeCount, int generationCount, CandinateFitnessType candinateFitnessType, CrossoverFunctionInterface generateCandinatesFunction,
      int directlyInheriedGeneCount, boolean allowMutationsInDirectlyInheritedGenes, double mutationProbobality, int maxMutatedGeneCountInAChrosome,
      MutationFunctionInterface mutationFunction) {
    super();
    this.chrosomeCount = chrosomeCount;
    this.generationCount = generationCount;
    this.candinateFitnessType = candinateFitnessType;
    this.generateCandinatesFunction = generateCandinatesFunction;
    this.directlyInheriedChrosomeCount = directlyInheriedGeneCount;
    this.allowMutationsInDirectlyInheritedChrosomes = allowMutationsInDirectlyInheritedGenes;
    this.mutationProbobalityPerGene = mutationProbobality;
    this.mutationFunction = mutationFunction;
    this.maxMutatedGeneCountInAChrosome = maxMutatedGeneCountInAChrosome;
  }

  public GeneticsConfiguration(CrossoverFunctionInterface generateCandinatesFunction, MutationFunctionInterface mutationFunction) {
    super();
    this.generateCandinatesFunction = generateCandinatesFunction;
    this.mutationFunction = mutationFunction;
  }

  public int getMaxMutatedGeneCountInAChrosome() {
    return this.maxMutatedGeneCountInAChrosome;
  }

  public int getChrosomeCount() {
    return this.chrosomeCount;
  }

  public int getGenerationCount() {
    return this.generationCount;
  }

  public CandinateFitnessType getCandinateFitnessType() {
    return this.candinateFitnessType;
  }

  public CrossoverFunctionInterface getGenerateCandinatesFunction() {
    return this.generateCandinatesFunction;
  }

  public int getDirectlyInheriedChrosomeCount() {
    return this.directlyInheriedChrosomeCount;
  }

  public boolean isAllowMutationsInDirectlyInheritedChrosomes() {
    return this.allowMutationsInDirectlyInheritedChrosomes;
  }

  public double getMutationProbobality() {
    return this.mutationProbobalityPerGene;
  }

  public MutationFunctionInterface getMutationFunction() {
    return this.mutationFunction;
  }

}
