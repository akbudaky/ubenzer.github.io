package genetics;

import genetics.GeneticsConfiguration.CandinateFitnessType;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import knapsack.KnapsackChrosome;
import knapsack.Main;

import org.apache.commons.lang3.ArrayUtils;

public class Generation {
  private GeneticsConfiguration conf;
  private KnapsackChrosome[] chrosomes;

  public Generation(GeneticsConfiguration conf, KnapsackChrosome[] chrosomes) {
    this.conf = conf;
    this.chrosomes = chrosomes;
  }

  public GeneticsConfiguration getConf() {
    return this.conf;
  }

  public KnapsackChrosome[] getChrosomes() {
    return this.chrosomes;
  }

  public static void createGenerations(Generation firstGen, GeneticsConfiguration conf) {

    Map<Integer, Double> abuzittin = new HashMap<Integer, Double>();
    for(int ii=0;ii<1000;ii++) {
      Generation currentGen = firstGen;
      
      Arrays.sort(currentGen.getChrosomes());
  
      if(currentGen.getConf().getCandinateFitnessType() == CandinateFitnessType.MORE_IS_BETTER) {
        ArrayUtils.reverse(currentGen.getChrosomes());
      }    
         
      //System.out.println(currentGen.getChrosomes()[0].getChrosomeFitness());
//      System.out.println("Generation #INIT" + " : " + currentGen.getChrosomes()[0].getChrosomeFitness());
      boolean bulundu = false;
      for (int i = 0; i < conf.getGenerationCount(); i++) {
        currentGen = conf.getGenerateCandinatesFunction().generate(currentGen);
        currentGen = conf.getMutationFunction().generate(currentGen);
        // System.out.print("Generation #" + i + " : " );
        // for(int ii=0;ii<currentGen.getChrosomes().length;ii++) {
        // System.out.print("[" +
        // currentGen.getChrosomes()[ii].getChrosomeFitness() + "] ");
        // }
        // System.out.print("\n");
        //System.out.println("Generation #" + i + " : " + currentGen.getChrosomes()[0].getChrosomeFitness());
        //System.out.println(currentGen.getChrosomes()[0].getChrosomeFitness());
        abuzittin.put(i, abuzittin.get(i) == null ? currentGen.getChrosomes()[0].getChrosomeFitness() : abuzittin.get(i) + currentGen.getChrosomes()[0].getChrosomeFitness());
        if(!bulundu && currentGen.getChrosomes()[0].getChrosomeFitness() == 115) {
          Main.buffer += "\n" + i;
          bulundu = true;
        }
      }
      
      Arrays.sort(currentGen.getChrosomes());
      ArrayUtils.reverse(currentGen.getChrosomes());  
      //System.out.println(currentGen.getChrosomes()[0].getChrosomeFitness());
    }
    
    
    for (int i = 0; i < conf.getGenerationCount(); i++) { 
      System.out.println(abuzittin.get(i) / 1000);
    }
    System.out.println("///----");
    System.out.println(Main.buffer);
    Main.buffer = "";
  }

}
