package genetics.interfaces;

import genetics.Generation;

public interface MutationFunctionInterface {

  public Generation generate(Generation currentGeneration);
}
