package genetics.interfaces;

import genetics.Generation;

public interface CrossoverFunctionInterface {
 
  public Generation generate(Generation currentGeneration);
  
}
