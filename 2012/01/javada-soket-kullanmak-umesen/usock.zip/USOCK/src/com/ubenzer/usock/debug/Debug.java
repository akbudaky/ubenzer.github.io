package com.ubenzer.usock.debug;

/**
 * Hata ayıklamakta ve bilgi almakta kullanılmak amacıyla
 * kritik bigilerin kendisine gönderildiği sınıftır.
 * 
 * @author UB
 */
public class Debug {

   /**
    * Gelen bilgiyi ekrana yazar ve bir satır aşağı iner.
    * 
    * @param Önemli bilgi
    */
   public static void log(String string) {
      log(string,true);
   }
   /**
    * Gelen bilgiyi ekrana yazar.
    *
    * @param Önemli bilgi
    * @param true ise satır atlar, false ise atlamaz.
    */
   public static void log(String string, boolean satirAtla) {
      if(satirAtla) {
         System.out.println(string);
      } else {
         System.out.print(string);
      }
   }
}
