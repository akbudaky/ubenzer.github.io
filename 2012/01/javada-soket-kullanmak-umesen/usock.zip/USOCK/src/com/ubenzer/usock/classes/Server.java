package com.ubenzer.usock.classes;

import com.ubenzer.usock.debug.Debug;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Gelen istekleri dinlemek ve gelen istekleri anlayıp
 * bunların hepsini ayrı birer threadda alarak işlemekle
 * mükellef bir sınıftır.
 * 
 * @author UB
 */
public class Server implements Runnable {
   private USock us;
   private int port = 40;
   private ServerSocket serverSocket = null;

   /**
    * Sunucu sınıf. Gelen istekleri dinler.
    *
    * @param Dinlencek port numarası
    * @param Bağlı olduğu altyapı nesnesi
    * @throws Port dinlenemiyor, çünkü başka uygulama dinliyor
    */
   protected Server(int portToBeListened, USock us) throws IOException {
      this.port = portToBeListened;
      this.us = us;
      serverSocket = new ServerSocket(port);
   }

   /**
    * Gelen istekleri dinleme threadi. Uygulama gelen istekleri dinlerken
    * aynı zamanda arayüz gösterme, başka dosyalar alma ve dosya gönderme
    * gibi şeyler de yapacağından dinleme işlemi süreç olarak çalışır.
    *
    * Burada dinleyen soket bir istek geldiği zaman verinin aktarılmasını
    * ve alındıktan sonra anlaşılıp işlenmesini yürütmek üzere yeni bir süreç
    * yaratıp anında dinlemeye devam eder.
    *
    * Böylece hiçbir zaman gelen veriler kaçırılmaz.
    */
   public void run() {
      /* Gelen istekleri dinleyelim. */
      Debug.log("THREAD " + Thread.currentThread().getName() + " // Başladı.");

      /* Gelen istekleri ihmal etmeksizin dinleyelim. */
      while (true) {
         Debug.log("THREAD " + Thread.currentThread().getName() + " // " + this.port + " numaralı port gelen istekler"
              + " için dinleniyor...");
          /* Gelen isteği kabul et. */
         Socket clientSocket;
         try {
            clientSocket = serverSocket.accept();
            System.out.println("THREAD " + Thread.currentThread().getName() + " // " +
                    clientSocket.getInetAddress() +  " adresinden gelecek veri var. Almak için thread yaratılıyor...");
            IncomingMessageProcessor mp = new IncomingMessageProcessor(clientSocket,us);
            new Thread(mp,"INCOMING MESSAGE PROCESSOR " + mp.hashCode()).start();
         } catch (IOException ex) {
            Debug.log("THREAD " + Thread.currentThread().getName() + " // " +
                    "IOException yedik: " + ex.getMessage());
         }
      }      
   }
}
