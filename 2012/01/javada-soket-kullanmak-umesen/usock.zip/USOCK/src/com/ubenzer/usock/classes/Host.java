package com.ubenzer.usock.classes;


import com.ubenzer.usock.interfaces.IHost;
import java.io.Serializable;

/**
 * Kendisine veri yollanebilecek bir HOST.
 * 
 * @author UB
 */
public class Host implements IHost {
   private String hostName;
   private String hostAddr;
   private int hostPort;

   /**
    * Kendisine veri yollanabilecek bir Host yaratır.
    *
    * @param Host adı, tamamen görsel amaçlı
    * @param Host adresi (IP)
    * @param Hostun dinlemekte olduğu port (varsayılan 40'tır.)
    */
   public Host(String hostName, String hostAddr, int port) {
      this.hostAddr = hostAddr;
      this.hostName = hostName;
      this.hostPort = port;
   }
   /**
    * Kendisine veri yollanabilecek bir Host yaratır.
    * 
    * @param Host adresi (IP)
    * @param Hostun dinlemekte olduğu port (varsayılan 40'tır.)
    */
   public Host(String hostAddr, int port) {
      this("",hostAddr,port);
   }
   /**
    * Host adını döndürür.
    * @return Hostun adı
    */
   public String getHostName() {
      return this.hostName;
   }
   /**
    * Hostun dinlediği port numarasını döndürür.
    *
    * @return Hostun portu
    */
   public int getHostPort() {
      return this.hostPort;
   }
   /**
    * Hostun ağdaki adresini döndürür.
    *
    * @return Hostun adresi
    */
   public String getHostAddr() {
      return this.hostAddr;
   }

   /**
    * Hosta bir mesaj yollar. Bu mesaj Serializable olduktan sonra
    * her şey olabilir. Doğru bir şekilde Serialize edildikten sonra
    * ister String, ister 300MB'lık divX yollanabilir.
    * 
    * @param Yollanan veri
    */
   public void sendMessage(Serializable msg) {      
      System.out.println(hostAddr +  " adresine mesaj yollamak için thread yaratılıyor...");
      OutgoingMessageProcessor mp = new OutgoingMessageProcessor(this,msg);
      new Thread(mp,"OUTGOING MESSAGE PROCESSOR " + mp.hashCode()).start();
   }
  
   @Override
   public String toString() {
      if (!this.hostName.equals("")) {
         return this.hostName;
      } else {
         return "Host " + this.hostAddr + ":" + this.hostPort;
      }
   }
   @Override
   public boolean equals(Object o) {
      if(o.getClass() != this.getClass()) return false;
      IHost h;
      try {
         h = (IHost) o;
      } catch (Exception e) {
         return false;
      }
      if(h.getHostAddr().equals(this.hostAddr) && h.getHostPort() == this.hostPort) {
         return true;
      }
      return false;
   }
   @Override
   public int hashCode() {
      int hash = 3;
      hash = 17 * hash + (this.hostAddr != null ? this.hostAddr.hashCode() : 0);
      hash = 17 * hash + this.hostPort;
      return hash;
   }
}