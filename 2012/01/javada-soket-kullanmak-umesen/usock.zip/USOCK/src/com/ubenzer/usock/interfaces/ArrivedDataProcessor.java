package com.ubenzer.usock.interfaces;

/**
 * Gelen verileri işleyecek KULLANICI sınıfı mutlaka bu
 * arayüzü implement etmelidir.
 *
 * Zaten implement etmesi çok karışık bir şey de değildir. :)
 *
 * @author UB
 */
public interface ArrivedDataProcessor {

   /**
    * Gelen veriyi işler.
    * 
    * @param Nesne halinde gelen veri
    * @param Yollayanın adresi
    */
   public void processArrivedData(Object dataReceived,String sender);

}
