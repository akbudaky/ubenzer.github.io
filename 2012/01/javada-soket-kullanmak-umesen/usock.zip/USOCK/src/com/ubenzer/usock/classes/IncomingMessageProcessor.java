package com.ubenzer.usock.classes;

import com.ubenzer.usock.debug.Debug;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

/**
 * Gelen isteklerin kabul edilip, verinin aktarılmasından sorumlu sınıftır. Veriler
 * bir defa aktarıldıktan sonr, ne olduklarının algılanıp gerekenlerin yapılması
 * bu sürecin sorumluluğu altında yer almamaktadır.
 *
 * @author UB
 */
public class IncomingMessageProcessor implements Runnable {
   private Socket cs;
   private USock us;

   /**
    * Verinin aktarılması için gerekli olan bu süreç çalışmadan önce
    * constructor ile yapılandırılmalıdır.
    *
    * @param Verinin geleceği soket
    * @param İşlemin bağlı olduğu USock nesnesi
    */
   protected IncomingMessageProcessor(Socket clientSocket, USock us) {
      this.cs = clientSocket;
      this.us = us;
   }

   /**
    * Verinin uzak sunucudan aktarılması bu kısımda yapılır. Gelen verinin ne olduğunu
    * anlamak ve gerekeni yapmak bu sürecin işi değildir.
    *
    * Gelen veri tamamen alındıktan sonra algılanması ve gerekenin yapılması için
    * bununla ilgili bir süreç yaratılır.
    */
   public void run() {      
      Debug.log("THREAD " + Thread.currentThread().getName() + " // " + "Başladı.");
      try {
         /* Gelen veriyi al */
         ObjectInputStream in = new ObjectInputStream(cs.getInputStream());
         /* Gelen veri Serializable bir obje olduğu için alttaki satır çalışır. */
         Object o = (Object) in.readObject();
         in.close();

         /* Gelen veriyi işleyecek sınıf bu bilginin nereden geldiğine ihtiyaç duyabilir. */
         String incomingAddr = cs.getInetAddress().getHostAddress();

         /* Gelen veriyi işleyecek süreç yaratılır. Aslında bu süreçte de bu işlem yapılabilirdi,
          ancak hem parça parça yazmanın kolay olması, hem de gelecekte birden fazla sürecin gelen
          veriyi aynı anda işleyebilme gereksinimi gçz önüne alınarak bunlar ayrı threadlere ayrıldı.
          */
         IncomingMessagePasser IMP = new IncomingMessagePasser(us.getDefaultADP(),o,incomingAddr);
         new Thread(IMP,"INCOMING MESSAGE PASSER " + IMP.hashCode()).start();
     
      } catch (IOException ex) {
         Debug.log("THREAD " + Thread.currentThread().getName() + " // " + "IOException yedik: " + ex.getMessage());
      } catch (ClassNotFoundException ex) {
         Debug.log("THREAD " + Thread.currentThread().getName() + " // " + "ClassNotFoundException yedik: "
                 + ex.getMessage());
      }
      Debug.log("THREAD " + Thread.currentThread().getName() + " // " + "Bitti.");
   }
}
