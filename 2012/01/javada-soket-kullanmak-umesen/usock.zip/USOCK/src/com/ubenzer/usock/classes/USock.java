package com.ubenzer.usock.classes;

import com.ubenzer.usock.debug.Debug;
import com.ubenzer.usock.interfaces.ArrivedDataProcessor;
import com.ubenzer.usock.interfaces.IHost;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Kullanıcının kendi uygulamasında USock alt yapısını
 * kullanmak için ilk başvuracağı ana classtır.
 *
 * Aynı proje birden çok USock nesnesini aynı anda kullanabilir (ama
 * buna gerek yoktur.)
 *
 * USock, çok rahat bir şekilde yeni veri tipleri yollamayı sağlar,
 * bu konuda tek sınır JAVA'nın kendisidir. :)
 * 
 * @author UB
 */
public class USock {
   private Server server = null;
   private Thread serverThread = null;
   private ArrayList<IHost> hostList = new ArrayList<IHost>();
   private ArrivedDataProcessor ADP;

   /**
    * Yeni bir USock iletişim altyapısı yaratılır. Bu yapı iki yönlüdür.
    * Her USock nesnesi, gelen istekleri alabilmek adına bir port dinleme ihtiyacı
    * duyar. ArrivedDataProcessor ise, bu USock nesnesine uzaktan gelen isteklerin
    * hangi kullanıcı sınıfına aktarılacağını belirtir.
    *
    * KULLANICI: USock altyapısını kullanan program.
    * USOCK: Bizim altyapımız.
    *
    * @param Gelen istekler için dinlenecek olan port numarası
    * @param Gelen verilerin hangi kullanıcı classına devredileceği
    * @throws Hatalı verileri sevmeyiz.
    */
   public USock(int portToBeListened, ArrivedDataProcessor ADP) throws Exception {
      if(portToBeListened < 0) throw new Exception("Port 0'dan küçük olamaz.");
      if(portToBeListened > 65535) throw new Exception("Port 65535'ten büyük olamaz.");

      this.ADP = ADP;
      
      this.startServer(portToBeListened);
   }

   /**
    * USock altyapısının kendisine ulaşan mesajları
    * işlemesi adına geçireceği kullanıcı nesnesinin referansını
    * döndürür.
    *
    * @return Kullanıcı Nesnesi
    */
   public ArrivedDataProcessor getDefaultADP() {
      return this.ADP;
   }
   /**
    * USock altyapısı, gelen istekleri dinleme hazırlıkları yapar. Buna port dinlemek
    * dahildir.
    *
    * @param Dinlenecek Port
    * @throws Port başka uygulamada, bu yüzden dinlenemiyor hatası
    */
   private void startServer(int portToBeListened) throws IOException {
      Debug.log("Gelen isteklerin dinlenmesi için port " + portToBeListened + " açılıyor...");
      try {
         server = new Server(portToBeListened, this);
      } catch (IOException iOException) {
         Debug.log("Port dinlemeye çalışırken IO Exception oluştu.");
         throw iOException;
      }
      Debug.log("Port açılma işlemi tamamlandı, şimdi gelen istekleri dinleyecek bir thread başlatılıyoré.");
      serverThread = new Thread(server,"Server Thread " + server.hashCode());
      serverThread.start();
   }

   /**
    * USock altyapısı, daha sonra hızlıca erişmek için Host'ları kendi bünyesine
    * kaydetmeye izin verir. "Host" uzaktaki bir bilgisayarın adı, dinlediği port numarası
    * ve adresidir.
    *
    * Böylece kullanıcı programı bir defa Host nesnesi yaratıp bunu bizim sistemimize register
    * edince, bu Hosta ait adres ve port gibi bilgileri ayrıca tutmasına gerek kalmayacak,
    * bunlar tamamıyla USOCK tarafından yönetilecektir.
    *
    * Bu fonksiyon USock bünyesine kayıtlı hostlar arasında adres ve port bilgilerine göre
    * arama yapar, bu bilgilere sahip host daha önce kaydedilmişse bu nesneyi geri döndürür.
    *
    * Eğer bilgileri verilen host kayıtlı değilse geriye null döner.
    *
    * @param Aranan hostun adresi
    * @param Aranan hostun dinlediği port
    * @return IHost bulunan host veya null
    */
   public IHost searchHost(String hostAddr, int port) {
      for(IHost h: hostList) {
         if(h.getHostAddr().equalsIgnoreCase(hostAddr) && h.getHostPort() == port) {
            return h;
         }
      }
      return null;
   }
   /**
    * USock altyapısına daha sonra hızlıca erişmek için yeni bir host kaydet.
    * 
    * @param Hostun adı (tamamen görsel amaçlı)
    * @param Hostun adresi (IP)
    * @param Hostun portu (Uzak makine hangi portu dinliyor?)
    * @return Oluşturulan ve register edilen IHost nesnesi.
    */
   public IHost registerHost(String hostName, String hostAddress, int port) {
      IHost host = new Host(hostName,hostAddress,port);
      for(IHost h:hostList) {
         if(h.equals(host)) return h;
      }
      hostList.add(host);
      return host;
   }
   /**
    * USock altyapısına daha sonra hızlıca erişmek için yeni bir host kaydet.
    * 
    * @param Hostun adresi (IP)
    * @param Hostun portu (Uzak makine hangi portu dinliyor?)
    * @return Oluşturulan ve register edilen IHost nesnesi.
    */
   public IHost registerHost(String hostAddress, int port) {
      IHost host = new Host(hostAddress,port);
      for(IHost h:hostList) {
         if(h.equals(host)) return h;
      }
      hostList.add(host);
      return host;
   }
   /**
    * USock altyapısından, daha önce register edilmiş bir hostu siler.
    *
    * @param Silinecek olan host
    * @return Silidiyse true, zaten sisteme kayıtlı değilse false
    */
   public boolean unregisterHost(IHost hostToBeDeleted) {
      return hostList.remove(hostToBeDeleted);
   }
}