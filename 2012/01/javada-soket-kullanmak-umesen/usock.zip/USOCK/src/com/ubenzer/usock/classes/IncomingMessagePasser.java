package com.ubenzer.usock.classes;

import com.ubenzer.usock.debug.Debug;
import com.ubenzer.usock.interfaces.ArrivedDataProcessor;

/**
 * Başarı ile bizim bilgisayarımıza gelmiş olan
 * bir verinin ne olduğunun anlaşılması ve bu veriyi
 * işleyecek olan KULLANICI sınıfına geçirecek olan threaddır.
 * 
 * Bu sınıf bir threaddır çünkü:
 * 
 * Veriyi alan kullanıcı sınıfı bu veriyle çok vakit geçirebilir, deyim yerindeyse
 * turşusunu kurabilir. Bu yüzden gelen verilerin paralel işlenmesini sağlamak
 * adına bunlar threadlere işletilir.
 *
 * @author UB
 */
public class IncomingMessagePasser implements Runnable {
   private ArrivedDataProcessor ADP;
   private Object msg;
   private String sender;

   /**
    * İşleyecek olan sınıf, gelen veri gibi bilgiler thread çalıştırılmadan
    * önce kendisine yüklenmelidir.
    * 
    * @param ArrivedDataProcessor arayüzünü implement eden, gelen verilerin
    * yollanacağı KULLANICI sınıfı.
    * @param Nesne halinde gelen mesaj
    * @param Göndericinin adresi
    */
   protected IncomingMessagePasser(ArrivedDataProcessor ADP, Object msg, String sender) {
      this.ADP = ADP;
      this.msg = msg;
      this.sender = sender;
   }
   /**
    * Veriyi alıp işleyecek KULLANICI sınıfı çağrılır.
    */
   public void run() {
      Debug.log("THREAD " + Thread.currentThread().getName() + " // " + "Başladı.");
      ADP.processArrivedData(msg,sender);
      Debug.log("THREAD " + Thread.currentThread().getName() + " // " + "Bitti.");
   }
}
