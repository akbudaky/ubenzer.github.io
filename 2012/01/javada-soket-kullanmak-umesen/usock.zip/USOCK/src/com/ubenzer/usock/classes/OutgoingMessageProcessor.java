package com.ubenzer.usock.classes;

import com.ubenzer.usock.debug.Debug;
import com.ubenzer.usock.interfaces.IHost;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Uzaktaki bilgisayara dosya gönderilmesini sağlayan threaddır.
 * Her gönderilecek dosya kendi sürecinde gönderilir. Böylece dosya
 * gönderilemesinin diğer hiçbir işi aksatmaması hedeflenmektedir.
 * 
 * @author UB
 */
public class OutgoingMessageProcessor implements Runnable {
   private IHost to;
   private Serializable msg;

   /**
    * Thread çalıştırılmadan önce bu constructor vasıtasıyla yapılandırılır.
    *
    * @param Verinin gönderileceği adres
    * @param Veri. Veri, JAVA Serializable interfaceini implement eden tüm
    * sınıflar olabilir. Hiçbir kısıtımız yok. ;)
    */
   protected OutgoingMessageProcessor(IHost to, Serializable msg) {
      this.msg = msg;
      this.to = to;
   }

   /**
    * Gönderilecek veriyi yollamayı sağlayan süreçtir.
    * Her yollanan veri kendi süreci ile gider.
    */
   public void run() {
      Debug.log("THREAD " + Thread.currentThread().getName() + " // " + "Başladı.");
      Socket socket = null;
      try {
         socket = new Socket(to.getHostAddr(), to.getHostPort());
         ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
         Debug.log("THREAD " + Thread.currentThread().getName() + " // " + "Veri yollanıyor...");
         oos.writeObject(msg);
         socket.close();
         Debug.log("THREAD " + Thread.currentThread().getName() + " // " + "Veri yollandı. :)");
      } catch (UnknownHostException e) {
         Debug.log("THREAD " + Thread.currentThread().getName() + " // " + 
                 "UnknownHostException yedik. Host: " + to.getHostAddr() + " -- " + to.getHostName() + " -- "
                 + e.getMessage());
      } catch  (IOException e) {
         Debug.log("THREAD " + Thread.currentThread().getName() + " // " + "IOException yedik: " + e.getMessage());
      } catch (Exception e) {
         Debug.log("THREAD " + Thread.currentThread().getName() + " // " + "Exception yedik: " + e.getMessage());
      }
      Debug.log("THREAD " + Thread.currentThread().getName() + " // " + "Bitti.");
   }

}
