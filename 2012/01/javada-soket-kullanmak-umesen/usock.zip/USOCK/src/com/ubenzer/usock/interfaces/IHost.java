package com.ubenzer.usock.interfaces;

import java.io.Serializable;

/**
 * USock'a bağlımlı kalmadan Host yaratabilmek için bir arayüz.
 * USock aracılığı ile veri gönderilecek tüm makinelerin nesneleri
 * mutlaka IHost'u implement etmelidir.
 * 
 * @author UB
 */
public interface IHost {

   /**
    * Hostun adını döndürür.
    * @return hostAdı
    */
   public String getHostAddr();

   /**
    * Hostun adresini döndürür.
    * @return hostAdresi
    */
   public String getHostName();

   /**
    * Hostla bağlantı kurulan port numarasını döndürür.
    *
    * @return portNo
    */
   public int getHostPort();

   /**
    * Hosta bir mesaj yollar.
    *
    * @param Herhangi bir Serializable sınıf.
    */
   public void sendMessage(Serializable msg);

}
