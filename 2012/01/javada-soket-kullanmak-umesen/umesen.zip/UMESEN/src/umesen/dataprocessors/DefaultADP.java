package umesen.dataprocessors;

import java.io.FileNotFoundException;
import java.io.IOException;
import umesen.datapackages.StringDataPackage;
import com.ubenzer.usock.interfaces.ArrivedDataProcessor;
import java.io.File;
import java.io.FileOutputStream;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import umesen.UMESENApp;
import umesen.datapackages.FileDataPackage;

/**
 * Uzak makineden gelen tüm verileri ArrivedDataProcessorlara
 * gönderilir.
 *
 * Bu KULLANICI uygulaması yapılandırmasına göre gelen verileri bu
 * sınır almaktadır. Bir sınıf ArriedDataProcessor arayüzünü
 * implement ettiği sürece gelen verileri isteyen tüm sınıflar
 * process edebilir.
 * 
 * @author UB
 */
public class DefaultADP implements ArrivedDataProcessor {
   DefaultListModel writeList;

   /**
    * Gelen verilerin ekranda yazdırılıacağı nesneyi parametre olarak alır.
    * USock ile bir alakası olmayıp tamamen KULLANICI uygulaması ile alakalıdır.
    *
    * @param Ekranda verilerin yazılacağı nesne
    */
   public DefaultADP(DefaultListModel writeList) {
      this.writeList = writeList;
   }
   /**
    * Bu kısım ArrivedDataProcessor implementasyonudur.
    *
    * Gelen nesnenin türü incelenir ve gerekenler yapılır.
    *
    * @param Uzak makineden gelen veri
    * @param Uzak makinenin adresi
    */
   public void processArrivedData(Object dataReceived, String sender) {
      System.out.println("THREAD " + Thread.currentThread().getName() + " // " + "Gelen nesnenin türü: " + dataReceived.getClass().toString());
      if(dataReceived instanceof String) {
         writeList.addElement(sender + " // " + (String)dataReceived);
      } else if (dataReceived instanceof StringDataPackage) {
         writeList.addElement(sender + " // " + ((StringDataPackage)dataReceived).getSender() + " // " + ((StringDataPackage)dataReceived).getString());
      } else if (dataReceived instanceof FileDataPackage) {
         FileDataPackage f = (FileDataPackage)dataReceived;

         writeList.addElement(sender + " // " + f.getSender() + " isimli kullanıcı dosya gönderdi: " + f.getFilename());
         
         /* 
          * Dosyanın kaydedileceği yeri soruyoruz ve kullanıcının istediği yere
          * dosyayı yazıyoruz.
          */
         JFileChooser fc = new JFileChooser();

         fc.showSaveDialog(UMESENApp.getApplication().getMainFrame());
         File selFile = fc.getSelectedFile();
         if (selFile == null) {
            writeList.addElement(sender + " // " + f.getSender() + " isimli kullanıcı dosya kaydetme iptal edildi.");
            return;
         }

         FileOutputStream fos;
         try {
            fos = new FileOutputStream(selFile);
            fos.write(f.getFile());
            fos.close();
         } catch (FileNotFoundException ex) {
            System.out.println("THREAD " + Thread.currentThread().getName() + " // " + "FileNotFoundException yedik: " +
                    ex.getMessage());
         } catch (IOException ex) {
            System.out.println("THREAD " + Thread.currentThread().getName() + " // " + "IOException yedik: " +
                    ex.getMessage());
         }         
      } else {
         writeList.addElement(sender + " // DefaultADP'nin anlamadığı bir paket geldi. Ignore ettim.");
      }
   }

}
