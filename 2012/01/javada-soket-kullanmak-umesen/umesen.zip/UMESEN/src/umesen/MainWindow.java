package umesen;

import umesen.dataprocessors.DefaultADP;
import java.io.FileNotFoundException;
import umesen.datapackages.StringDataPackage;
import com.ubenzer.usock.classes.USock;
import com.ubenzer.usock.interfaces.ArrivedDataProcessor;
import com.ubenzer.usock.interfaces.IHost;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import javax.swing.DefaultListModel;
import org.jdesktop.application.Action;
import org.jdesktop.application.SingleFrameApplication;
import org.jdesktop.application.FrameView;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import umesen.datapackages.FileDataPackage;

/**
 * Verilerin kullanıcıdan alınarak iletildiği ve gelen
 * verilerin UI'de gösterildiği ana formdur.
 * 
 * @author UB
 */
public class MainWindow extends FrameView {

   public USock usock; // bağlantı kütüphanemiz
   int port = 0; //bağlantı kurulacak port
   String nickname = ""; // nickname
   DefaultListModel hostListModel = new DefaultListModel(); // listeleri tutmak için gerekli modeller
   DefaultListModel mesajListModel = new DefaultListModel();

   public MainWindow(SingleFrameApplication app) {
      super(app);
      initComponents();
      getFrame().setResizable(false); // Bu satırı bulmak samimi söylüyorum 3 saatimi aldı!
      
      startServer(); /* Dinlemeye başlama hazırlıkları */
   }

   private void startServer() {
      /* Port ve Takma isim alınmak üzere form işlemleri yapılır. */
      port = -1;
      if (portSelectionBox == null) {
         JFrame mainFrame = UMESENApp.getApplication().getMainFrame();
         portSelectionBox = new PortAndNickSelectionBox(mainFrame, this);
         portSelectionBox.setLocationRelativeTo(mainFrame);
      }
      UMESENApp.getApplication().show(portSelectionBox);

      if(port == -1) System.exit(0);

      try {
         /* Bu satır aracılığı ile iletişim alt yapımızı başlatıyoruz. */
         usock = new USock(port, (ArrivedDataProcessor) (new DefaultADP(this.mesajListModel)));
      } catch (Exception ex) {
         /* Eğer port zaten kullanımda ise Exception atacaktır. O zaman yeniden port soruyoruz. */
         startServer();
      }

      /* Kolaylık olması amacı ile kendimizi listeye ekleyelim. */
      // Bu adım mecburi değildir.
      IHost h = usock.registerHost("Kendiniz","127.0.0.1",port);
      if(!hostListModel.contains(h)) {
         hostListModel.addElement(h);
      }
   }
   public void setPort(int port) {
      this.port = port;
   }

   @Action
   public void showAboutBox() {
     if (aboutBox == null) {
         JFrame mainFrame = UMESENApp.getApplication().getMainFrame();
         aboutBox = new AboutBox(mainFrame);
         aboutBox.setLocationRelativeTo(mainFrame);
     }
     UMESENApp.getApplication().show(aboutBox);
   }

    @SuppressWarnings("unchecked")
   // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
   private void initComponents() {

      mainPanel = new javax.swing.JPanel();
      jSafString = new javax.swing.JButton();
      jScrollPane1 = new javax.swing.JScrollPane();
      jHostList = new javax.swing.JList();
      jLabel1 = new javax.swing.JLabel();
      jHostIP = new javax.swing.JTextField();
      jLabel3 = new javax.swing.JLabel();
      jHostPort = new javax.swing.JTextField();
      jHostEkle = new javax.swing.JButton();
      jLabel2 = new javax.swing.JLabel();
      jScrollPane2 = new javax.swing.JScrollPane();
      jList2 = new javax.swing.JList();
      jLabel4 = new javax.swing.JLabel();
      jText = new javax.swing.JTextField();
      jStringDP = new javax.swing.JButton();
      jDosyaYolla = new javax.swing.JButton();
      menuBar = new javax.swing.JMenuBar();
      javax.swing.JMenu fileMenu = new javax.swing.JMenu();
      javax.swing.JMenuItem exitMenuItem = new javax.swing.JMenuItem();
      javax.swing.JMenu helpMenu = new javax.swing.JMenu();
      javax.swing.JMenuItem aboutMenuItem = new javax.swing.JMenuItem();
      jDialog1 = new javax.swing.JDialog();
      jDialog2 = new javax.swing.JDialog();
      jDialog3 = new javax.swing.JDialog();

      mainPanel.setMaximumSize(new java.awt.Dimension(1024, 768));
      mainPanel.setMinimumSize(new java.awt.Dimension(640, 480));
      mainPanel.setName("mainPanel"); // NOI18N
      mainPanel.setPreferredSize(new java.awt.Dimension(640, 480));

      org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(umesen.UMESENApp.class).getContext().getResourceMap(MainWindow.class);
      jSafString.setText(resourceMap.getString("jSafString.text")); // NOI18N
      jSafString.setName("jSafString"); // NOI18N
      jSafString.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(java.awt.event.ActionEvent evt) {
            jSafStringActionPerformed(evt);
         }
      });

      jScrollPane1.setName("jScrollPane1"); // NOI18N

      jHostList.setModel(hostListModel);
      jHostList.setName("jHostList"); // NOI18N
      jScrollPane1.setViewportView(jHostList);

      jLabel1.setText(resourceMap.getString("jLabel1.text")); // NOI18N
      jLabel1.setName("jLabel1"); // NOI18N

      jHostIP.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
      jHostIP.setText(resourceMap.getString("jHostIP.text")); // NOI18N
      jHostIP.setName("jHostIP"); // NOI18N

      jLabel3.setText(resourceMap.getString("jLabel3.text")); // NOI18N
      jLabel3.setName("jLabel3"); // NOI18N

      jHostPort.setHorizontalAlignment(javax.swing.JTextField.CENTER);
      jHostPort.setText(resourceMap.getString("jHostPort.text")); // NOI18N
      jHostPort.setName("jHostPort"); // NOI18N

      jHostEkle.setText(resourceMap.getString("jHostEkle.text")); // NOI18N
      jHostEkle.setName("jHostEkle"); // NOI18N
      jHostEkle.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(java.awt.event.ActionEvent evt) {
            jHostEkleActionPerformed(evt);
         }
      });

      jLabel2.setText(resourceMap.getString("jLabel2.text")); // NOI18N
      jLabel2.setName("jLabel2"); // NOI18N

      jScrollPane2.setName("jScrollPane2"); // NOI18N

      jList2.setModel(mesajListModel);
      jList2.setName("jList2"); // NOI18N
      jScrollPane2.setViewportView(jList2);

      jLabel4.setText(resourceMap.getString("jLabel4.text")); // NOI18N
      jLabel4.setName("jLabel4"); // NOI18N

      jText.setText(resourceMap.getString("jText.text")); // NOI18N
      jText.setName("jText"); // NOI18N

      jStringDP.setText(resourceMap.getString("jStringDP.text")); // NOI18N
      jStringDP.setName("jStringDP"); // NOI18N
      jStringDP.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(java.awt.event.ActionEvent evt) {
            jStringDPActionPerformed(evt);
         }
      });

      jDosyaYolla.setText(resourceMap.getString("jDosyaYolla.text")); // NOI18N
      jDosyaYolla.setName("jDosyaYolla"); // NOI18N
      jDosyaYolla.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(java.awt.event.ActionEvent evt) {
            jDosyaYollaActionPerformed(evt);
         }
      });

      javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
      mainPanel.setLayout(mainPanelLayout);
      mainPanelLayout.setHorizontalGroup(
         mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGroup(mainPanelLayout.createSequentialGroup()
            .addContainerGap()
            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)
               .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainPanelLayout.createSequentialGroup()
                  .addComponent(jHostIP, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                  .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                  .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(jHostPort, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                  .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(jHostEkle, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
               .addComponent(jLabel1))
            .addGap(10, 10, 10)
            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addGroup(mainPanelLayout.createSequentialGroup()
                  .addGap(10, 10, 10)
                  .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                     .addComponent(jLabel4)
                     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel2)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 364, Short.MAX_VALUE)
                        .addComponent(jText))))
               .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainPanelLayout.createSequentialGroup()
                  .addComponent(jSafString, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                  .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                  .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                     .addComponent(jDosyaYolla, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                     .addComponent(jStringDP, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE))))
            .addContainerGap())
      );
      mainPanelLayout.setVerticalGroup(
         mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGroup(mainPanelLayout.createSequentialGroup()
            .addContainerGap()
            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
               .addComponent(jLabel1)
               .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addGroup(mainPanelLayout.createSequentialGroup()
                  .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                  .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(jLabel4)
                  .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(jText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                  .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                  .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                     .addComponent(jStringDP)
                     .addComponent(jSafString))
                  .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(jDosyaYolla))
               .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 391, Short.MAX_VALUE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
               .addComponent(jHostEkle, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
               .addComponent(jHostIP, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
               .addComponent(jHostPort, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
               .addComponent(jLabel3))
            .addContainerGap())
      );

      menuBar.setName("menuBar"); // NOI18N

      fileMenu.setText(resourceMap.getString("fileMenu.text")); // NOI18N
      fileMenu.setName("fileMenu"); // NOI18N

      javax.swing.ActionMap actionMap = org.jdesktop.application.Application.getInstance(umesen.UMESENApp.class).getContext().getActionMap(MainWindow.class, this);
      exitMenuItem.setAction(actionMap.get("quit")); // NOI18N
      exitMenuItem.setText(resourceMap.getString("exitMenuItem.text")); // NOI18N
      exitMenuItem.setName("exitMenuItem"); // NOI18N
      fileMenu.add(exitMenuItem);

      menuBar.add(fileMenu);

      helpMenu.setText(resourceMap.getString("helpMenu.text")); // NOI18N
      helpMenu.setName("helpMenu"); // NOI18N

      aboutMenuItem.setAction(actionMap.get("showAboutBox")); // NOI18N
      aboutMenuItem.setText(resourceMap.getString("aboutMenuItem.text")); // NOI18N
      aboutMenuItem.setName("aboutMenuItem"); // NOI18N
      helpMenu.add(aboutMenuItem);

      menuBar.add(helpMenu);

      jDialog1.setName("jDialog1"); // NOI18N

      javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
      jDialog1.getContentPane().setLayout(jDialog1Layout);
      jDialog1Layout.setHorizontalGroup(
         jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGap(0, 400, Short.MAX_VALUE)
      );
      jDialog1Layout.setVerticalGroup(
         jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGap(0, 300, Short.MAX_VALUE)
      );

      jDialog2.setName("jDialog2"); // NOI18N

      javax.swing.GroupLayout jDialog2Layout = new javax.swing.GroupLayout(jDialog2.getContentPane());
      jDialog2.getContentPane().setLayout(jDialog2Layout);
      jDialog2Layout.setHorizontalGroup(
         jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGap(0, 400, Short.MAX_VALUE)
      );
      jDialog2Layout.setVerticalGroup(
         jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGap(0, 300, Short.MAX_VALUE)
      );

      jDialog3.setName("jDialog3"); // NOI18N

      javax.swing.GroupLayout jDialog3Layout = new javax.swing.GroupLayout(jDialog3.getContentPane());
      jDialog3.getContentPane().setLayout(jDialog3Layout);
      jDialog3Layout.setHorizontalGroup(
         jDialog3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGap(0, 400, Short.MAX_VALUE)
      );
      jDialog3Layout.setVerticalGroup(
         jDialog3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGap(0, 300, Short.MAX_VALUE)
      );

      setComponent(mainPanel);
      setMenuBar(menuBar);
   }// </editor-fold>//GEN-END:initComponents

    /**
     * Bu buton String tipinde bir veriyi listede seçili tüm hostlara yollar.
     * Burada gösterilmek istenen Serializeable olan tüm JAVA Classlarının doğrudan
     * kullanılabileceği, kullanıcının yeni sınıf bile yazmaya ihtiayaç duymayacağıdır.
     * 
     * @param JAVA ile ilgili bir şeyler
     */
    private void jSafStringActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSafStringActionPerformed

      // Seçili hostların listesini alalım.
      int[] selectedIx = jHostList.getSelectedIndices();

      // Bu hostlara teker teker gönderilecek veriyi yollayalım.
      /* Gönderme işlemi threaded olduğu için bir diğeri için
       * ilkini bekleme söz konusu değildir. (adamlar yapmış)
       */
      for (int i=0; i<selectedIx.length; i++) {
          IHost sel = (IHost) jHostList.getModel().getElementAt(selectedIx[i]);
          sel.sendMessage(jText.getText());      
      }      
    }//GEN-LAST:event_jSafStringActionPerformed

    /**
     * Sisteme ve listeye yeni bir Host ekler.
     *
     * @param JAVA ile ilgili bir şeyler
     */
    private void jHostEkleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jHostEkleActionPerformed
       String portS = jHostPort.getText();
       int portGelen = 0;
       try {
          portGelen = Integer.parseInt(portS);
       } catch (NumberFormatException numberFormatException) {
          System.out.println("Port sayı değil.");
       }
       IHost h = usock.registerHost(jHostIP.getText(), portGelen);
       if(!hostListModel.contains(h)) {
         hostListModel.addElement(h);
       }
    }//GEN-LAST:event_jHostEkleActionPerformed

     /**
     * Bu buton StringDataPackage tipinde bir veriyi listede seçili tüm hostlara yollar.
     * Burada gösterilmek istenen Serializeable olduktan sonra kullanıcının kendi
     * veri yapısını kolaylıkla oluşturabileceğidir.
     *
     * @param JAVA ile ilgili bir şeyler
     */
    private void jStringDPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jStringDPActionPerformed
      // Seçili hostların listesini alalım.
      int[] selectedIx = jHostList.getSelectedIndices();

      // Bu hostlara teker teker gönderilecek veriyi yollayalım.
      /* Gönderme işlemi threaded olduğu için bir diğeri için
       * ilkini bekleme söz konusu değildir. (adamlar yapmış)
       */
      for (int i=0; i<selectedIx.length; i++) {
          IHost sel = (IHost) jHostList.getModel().getElementAt(selectedIx[i]);
          sel.sendMessage(new StringDataPackage(jText.getText(),this.nickname));
      }
    }//GEN-LAST:event_jStringDPActionPerformed

    /**
     * Bu buton FileDataPackage tipinde bir veriyi listede seçili tüm hostlara yollar.
     * Burada gösterilmek istenen dosyaların dahi kolaylıkla gönderilebileceğidir.
     *
     * Program göndermeden önce dosyayı okumakta ve bunu byte dizisi olarak belleğe alıp
     * nesneye yazmaktadır. (haliyle)
     * 
     * @param JAVA ile ilgili bir şeyler
     */
    private void jDosyaYollaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDosyaYollaActionPerformed

      JFileChooser fc = new JFileChooser();

      // Dosya açma dialogunu göster
      fc.showOpenDialog(UMESENApp.getApplication().getMainFrame());
      File selFile = fc.getSelectedFile();
      if (selFile == null) return; // Cancel

      // Seçili hostların listesini alalım.
      int[] selectedIx = jHostList.getSelectedIndices();

      // Bu hostlara teker teker gönderilecek veriyi yollayalım.
      /* Gönderme işlemi threaded olduğu için bir diğeri için
       * ilkini bekleme söz konusu değildir. (adamlar yapmış)
       */
      for (int i=0; i<selectedIx.length; i++) {
         IHost sel = (IHost) jHostList.getModel().getElementAt(selectedIx[i]);

         byte [] fileByte  = new byte [(int)selFile.length()];
         /* Dosyayı okuyoruz */
         FileInputStream fis;
         try {
            fis = new FileInputStream(selFile);
            fis.read(fileByte,0,fileByte.length);
            FileDataPackage fp = new FileDataPackage(selFile.getName(), fileByte, this.nickname);
            sel.sendMessage(fp);
         } catch (FileNotFoundException ex) {
            System.out.println("FileNotFoundException yedik: " + ex.getMessage());
         }  catch (IOException ex) {
            System.out.println("IOException yedik: " + ex.getMessage());
         }
      }
    }//GEN-LAST:event_jDosyaYollaActionPerformed

   // Variables declaration - do not modify//GEN-BEGIN:variables
   private javax.swing.JDialog jDialog1;
   private javax.swing.JDialog jDialog2;
   private javax.swing.JDialog jDialog3;
   private javax.swing.JButton jDosyaYolla;
   private javax.swing.JButton jHostEkle;
   private javax.swing.JTextField jHostIP;
   private javax.swing.JList jHostList;
   private javax.swing.JTextField jHostPort;
   private javax.swing.JLabel jLabel1;
   private javax.swing.JLabel jLabel2;
   private javax.swing.JLabel jLabel3;
   private javax.swing.JLabel jLabel4;
   private javax.swing.JList jList2;
   private javax.swing.JButton jSafString;
   private javax.swing.JScrollPane jScrollPane1;
   private javax.swing.JScrollPane jScrollPane2;
   private javax.swing.JButton jStringDP;
   private javax.swing.JTextField jText;
   private javax.swing.JPanel mainPanel;
   private javax.swing.JMenuBar menuBar;
   // End of variables declaration//GEN-END:variables

    private JDialog aboutBox;
    private JDialog portSelectionBox;
}
