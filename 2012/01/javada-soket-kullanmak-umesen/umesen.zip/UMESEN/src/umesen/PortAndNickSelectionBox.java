package umesen;

/**
 * Program başlamadan önce bağlantı kurulacak portu ve
 * kullanıcı bilgilerini alan formdur.
 *
 * @author UB
 */
public class PortAndNickSelectionBox extends javax.swing.JDialog {
   private MainWindow u;

   public PortAndNickSelectionBox(java.awt.Frame parent, MainWindow u) {
      super(parent,true);
      this.u = u;
      u.setPort(-1);
      initComponents();
    }

    @SuppressWarnings("unchecked")
   // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
   private void initComponents() {

      jOK = new javax.swing.JButton();
      jLabel1 = new javax.swing.JLabel();
      jPortNumber = new javax.swing.JTextField();
      jLabel2 = new javax.swing.JLabel();
      jComp = new javax.swing.JTextField();

      setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
      org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(umesen.UMESENApp.class).getContext().getResourceMap(PortAndNickSelectionBox.class);
      setTitle(resourceMap.getString("Form.title")); // NOI18N
      setName("Form"); // NOI18N
      setResizable(false);

      jOK.setText(resourceMap.getString("jOK.text")); // NOI18N
      jOK.setName("jOK"); // NOI18N
      jOK.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(java.awt.event.ActionEvent evt) {
            jOKActionPerformed(evt);
         }
      });

      jLabel1.setText(resourceMap.getString("jLabel1.text")); // NOI18N
      jLabel1.setName("jLabel1"); // NOI18N

      jPortNumber.setHorizontalAlignment(javax.swing.JTextField.LEFT);
      jPortNumber.setText(resourceMap.getString("jPortNumber.text")); // NOI18N
      jPortNumber.setName("jPortNumber"); // NOI18N

      jLabel2.setText(resourceMap.getString("jLabel2.text")); // NOI18N
      jLabel2.setName("jLabel2"); // NOI18N

      jComp.setHorizontalAlignment(javax.swing.JTextField.LEFT);
      jComp.setText(resourceMap.getString("jComp.text")); // NOI18N
      jComp.setName("jComp"); // NOI18N

      javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
      getContentPane().setLayout(layout);
      layout.setHorizontalGroup(
         layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGroup(layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addGroup(layout.createSequentialGroup()
                  .addGap(10, 10, 10)
                  .addComponent(jLabel2)
                  .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(jComp, javax.swing.GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE))
               .addGroup(layout.createSequentialGroup()
                  .addComponent(jLabel1)
                  .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                  .addComponent(jPortNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
               .addComponent(jOK, javax.swing.GroupLayout.Alignment.TRAILING))
            .addContainerGap())
      );
      layout.setVerticalGroup(
         layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGroup(layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
               .addComponent(jLabel1)
               .addComponent(jPortNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
               .addComponent(jLabel2)
               .addComponent(jComp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(jOK)
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
      );

      pack();
   }// </editor-fold>//GEN-END:initComponents

    private void jOKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jOKActionPerformed
       try {
          String pS = jPortNumber.getText();
          int p = Integer.parseInt(pS);
          u.setPort(p);
          u.nickname = jComp.getText();
          dispose();
       } catch (NumberFormatException numberFormatException) {
       }
    }//GEN-LAST:event_jOKActionPerformed

   // Variables declaration - do not modify//GEN-BEGIN:variables
   private javax.swing.JTextField jComp;
   private javax.swing.JLabel jLabel1;
   private javax.swing.JLabel jLabel2;
   private javax.swing.JButton jOK;
   private javax.swing.JTextField jPortNumber;
   // End of variables declaration//GEN-END:variables

}
