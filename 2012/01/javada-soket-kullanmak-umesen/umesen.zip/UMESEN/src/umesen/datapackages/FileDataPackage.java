package umesen.datapackages;

import java.io.Serializable;

/**
 * İçinde bir bayt dizisi ve gönderen kişinin "nickname" bilgisini tutan
 * KULLANICI programı içerisinde yer alan örnek bir veri paketidir.
 *
 * Bu byte dizisinin bir dosya olması öngörülmektedir.
 * 
 * @author UB
 */
public class FileDataPackage implements Serializable {
   private String filename;
   private String sender;
   private byte[] file;

   public FileDataPackage (String filename, byte[] file, String sender) {
      this.file = file;
      this.filename = filename;
      this.sender = sender;
   }
   public String getSender() {
      return sender;
   }
   public String getFilename() {
      return filename;
   }
   public byte[] getFile() {
      return file;
   }  

}
