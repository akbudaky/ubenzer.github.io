package umesen.datapackages;

import java.io.Serializable;

/**
 * İçinde metin ve metinin gönderen kişinin "nickname" bilgisini tutan
 * KULLANICI programı içerisinde yer alan örnek bir veri paketidir.
 *
 * @author UB
 */
public class StringDataPackage implements Serializable {
   private String metin;
   private String nickname;

   public StringDataPackage (String s, String nickname) {
      this.metin = s;
      this.nickname = nickname;
   }

   public String getString() {
      return metin;
   }

   public String getSender() {
      return nickname;
   }
}