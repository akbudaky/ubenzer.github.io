package umesen;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import org.jdesktop.application.Application;
import org.jdesktop.application.SingleFrameApplication;

/**
 * KULLANICI tarafının çalışan sınıfıdır.
 * Main burada bulunmaktadır.
 *
 * @author UB
 */
public class UMESENApp extends SingleFrameApplication {

   @Override protected void startup() {
      show(new MainWindow(this));
   }
   @Override
   protected void configureWindow(java.awt.Window root) {

    root.addWindowListener(new WindowAdapter() {

        @Override
        public void windowClosing(WindowEvent e) {
            System.exit(0);
        }

    });
   }

    public static UMESENApp getApplication() {
        return Application.getInstance(UMESENApp.class);
    }

    public static void main(String[] args) {
        launch(UMESENApp.class, args);
    }
}