package jobs;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.google.gson.JsonArray;
import com.jamonapi.utils.Logger;

import exceptions.FBGraphAPIException;
import exceptions.FacebookException;

import models.Friend;
import models.User;
import play.Play;
import play.jobs.Every;
import play.jobs.Job;
import play.libs.WS;
import util.FBGraphAPI;
import util.FBHelper;

/**
 * Kullanıcıların arkadaş listesini eskiden veritabanında
 * tututğumuz ile karşılaştıralım.
 * 
 * Eğer fark görürsek kullanıcıyı uyarmak için app notification
 * yollayalım.
 * 
 * @author UB
 */
@Every("1h")
public class CheckFriendship extends Job {

	private String userID = null;
	
	public CheckFriendship() {
		super();
	}
	
	public CheckFriendship(String userToBeCheckedID) {
		super();
		this.userID = userToBeCheckedID;
	}
	
	public void doJob() {
		
		play.Logger.info("checkFrinedship başladı.");
		
		List<User> kullanicilar = null;
		
		/* Bu token alma olayını acaba her request için yapmak zorunlu mu? Dokümantasyonda
		 * bulamadım. Gelen token ne kadar süre geçerli ki?
		 * TODO Araştır
		 */
		String token = null;
		try {
			token = FBHelper.getClientCredentialAccessToken();
		} catch (FacebookException e) {
			e.printStackTrace();
			return;
		}
		 
		if(this.userID == null) {
			
		 kullanicilar = User.findAll();
		 
		} else {
			
			kullanicilar = new ArrayList<User>();
			User bizimUser = User.find("byUserId", this.userID).first();
			if(bizimUser == null) {
				play.Logger.info("Single user arkadaş listelenmesi, kullanıcı hatalı:" + this.userID, 
						this.userID);
				return;
			}
			kullanicilar.add(bizimUser);
		}
    
		 for(User u : kullanicilar) {
			
			List<Friend> newFriendList = null;
			try {
				newFriendList = FBGraphAPI.getUserFriends(u.userID, u.accessToken);
			} catch (FBGraphAPIException e) {
			  e.printStackTrace();
			  continue;
			}
			
			//Cache.set("atla", "a");
			
			/* Foreach ile gezersek ekleme/silme olduğunda itarete ayvayı yiyor */
			play.Logger.info("Eski arkadaş sayısı: " + u.friendList.size(), u.friendList);
			play.Logger.info("Yeni arkadaş sayısı: " + newFriendList.size(), newFriendList);
			
			for(int i=0; i<newFriendList.size();i++) {

				Friend f = newFriendList.get(i);
				if(!u.friendList.contains(f)) {
					try {
						play.Logger.info("Arkadaş listenize yeni eklenen kullanıcı: " + f.name); 
            FBGraphAPI.addApplicationRequest(u.userID, token,
            		"Arkadaş listenize yeni eklenen kullanıcı: " + f.name, f.name);
            f.save();
						u.addAddAFriend(f);
          } catch (Exception e) {
            e.printStackTrace();
          }
				}
			}
				
			
			for(int i=0; i<u.friendList.size(); i++) {
				
				Friend f = u.friendList.get(i);
				if(!newFriendList.contains(f)) {
					try {
						play.Logger.info("Arkadaş listenizden çıkan kullanıcı: " + f.name); 
	          FBGraphAPI.addApplicationRequest(u.userID, token,
	          		f.name + "sizi sildi veya profilini kapattı", f.name);
	          u.deleteAFriend(f);
          } catch (FBGraphAPIException e) {
	          e.printStackTrace();
          }						
				}
			}
		}
	}
}
