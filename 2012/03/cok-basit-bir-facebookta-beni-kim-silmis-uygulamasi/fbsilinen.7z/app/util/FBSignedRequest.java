package util;

/**
 * Bu sınıf facebooktan gelen json verisini
 * kolayca okuyabilmek için kullandığımız bir
 * sınıftır. Başka da bir işe yaramaz.
 * 
 * @author UB
 *
 */
public class FBSignedRequest {
	public FBUser getUser() {
		return user;
	}
	public String getAlgorithm() {
		return algorithm;
	}
	public Integer getIssued_at() {
		return issued_at;
	}
	public String getUser_id() {
		return user_id;
	}
	public String getOauth_token() {
		return oauth_token;
	}
	public Integer getExpires() {
		return expires;
	}
	public String getApp_data() {
		return app_data;
	}
	public FBPage getPage() {
		return page;
	}
	public Integer getProfile_id() {
		return profile_id;
	}
	class FBUser {
		private String country;
		public String getCountry() {
			return country;
		}
		public String getLocale() {
			return locale;
		}
		public FBAge getAge() {
			return age;
		}
		private String locale;
		class FBAge {
			private Integer min;
			public Integer getMin() {
				return min;
			}
			public Integer getMax() {
				return max;
			}
			private Integer max;
		}
		FBAge age;
	}
	private FBUser user;
	private String algorithm;
	private Integer issued_at;
	private String user_id;
	private String oauth_token;
	private Integer expires;
	private String app_data;
	class FBPage {
		private String id;
		public String getId() {
			return id;
		}
		public boolean isLiked() {
			return liked;
		}
		public boolean isAdmin() {
			return admin;
		}
		private boolean liked;
		private boolean admin;
		
		
	}
	private FBPage page;
	private Integer profile_id;
}
