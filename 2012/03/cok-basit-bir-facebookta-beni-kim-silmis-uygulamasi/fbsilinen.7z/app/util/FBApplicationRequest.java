package util;

import java.util.Date;

public class FBApplicationRequest {

	private String id;
	
	class Application {
		private String name;
		private String id;
		public String getName() {
    	return name;
    }
		public String getId() {
    	return id;
    }
	}
	
	private Application application;
	
	class ToFrom {
		private String name;
		private String id;
		public String getName() {
    	return name;
    }
		public String getId() {
    	return id;
    }
	}
	
	public String getId() {
  	return id;
  }
	public Application getApplication() {
  	return application;
  }
	public ToFrom getTo() {
  	return to;
  }
	public ToFrom getFrom() {
  	return from;
  }
	public String getData() {
  	return data;
  }
	public String getMessage() {
  	return message;
  }
	public Date getCreated_time() {
  	return created_time;
  }
	private ToFrom to;
	private ToFrom from;
	private String data;
	private String message;
	private Date created_time;
	
	
}
