package util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import models.Friend;
import models.User;
import play.libs.WS;
import play.libs.WS.HttpResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import exceptions.FBGraphAPIException;

/**
 * Bu sınıfta graph api çağrımlarına dair
 * metotlar bulunur. Bunlar işleri kolaylaştırmak
 * için temel graphapinin üstüne yazılmıştır.
 * 
 * @author UB
 */
public class FBGraphAPI extends FBGraphAPICore {
	
	public static List<Friend> getUserFriends(String ID, String accessToken) 
		throws FBGraphAPIException {
		
		List<Friend> newFriendList = new ArrayList<Friend>();
		JsonArray friendListJSON = null;
	  friendListJSON = FBGraphAPI.GET(ID, "friends", accessToken);
    
		for (int i=0; i<friendListJSON.size(); i++) {
			
			//if(Cache.get("atla") == "a" && i == 5) continue;
			
			Friend eklenecek = new Friend(
					friendListJSON.get(i).getAsJsonObject().get("id").getAsString(),
					friendListJSON.get(i).getAsJsonObject().get("name").getAsString());
				
			newFriendList.add(eklenecek);	
		}
		return newFriendList;
	}
	
	public static String addApplicationRequest(String toUserID, String accessToken, 
			String message, String data) throws FBGraphAPIException {
	
		
		Map<String,String> params = new HashMap<String, String>();
		params.put("data", data);
		params.put("message", message);
		
		return FBGraphAPICore.POST(toUserID, "apprequests", accessToken, params);	
	}
	
	public static List<FBApplicationRequest> getApplicationRequests(String ID, String accessToken) 
		throws FBGraphAPIException {
		
		JsonArray appRequestJSON = FBGraphAPI.GET(ID, "apprequests", accessToken);
		List<FBApplicationRequest> dondurulecek = new ArrayList<FBApplicationRequest>();
		
		for(JsonElement j: appRequestJSON) {
			
			Gson gson = new GsonBuilder().setPrettyPrinting().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
			FBApplicationRequest appRequest = gson.fromJson(j, FBApplicationRequest.class);
			
			dondurulecek.add(appRequest);
			
		}
		
		return dondurulecek;
	}
	
	public static void deleteApplicationRequest(FBApplicationRequest reqToDelete, 
			String accessToken) throws FBGraphAPIException {
		
		FBGraphAPI.DELETE(reqToDelete.getId(), accessToken);
		
	}
	
}
