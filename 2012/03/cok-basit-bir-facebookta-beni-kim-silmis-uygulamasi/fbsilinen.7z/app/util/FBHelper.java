package util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.util.Arrays;
import java.util.StringTokenizer;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import play.Logger;
import play.Play;
import play.libs.Codec;
import play.libs.WS;
import play.libs.WS.HttpResponse;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonSyntaxException;

import exceptions.FBGraphAPIException;
import exceptions.FBSignedRequestException;
import exceptions.FacebookException;

/**
 * Bu sınıf Facebook'a bağlanırken sıkça kullandığımız
 * metotları koyduğumuz statik metotlar içeren
 * bir utiliy sınıfıdır.
 * 
 * @author UB
 *
 */
public class FBHelper {

	public static FBSignedRequest parseSignedRequest(String signed_request) 
		throws FBSignedRequestException, RuntimeException {
		
		StringTokenizer st = new StringTokenizer(signed_request,".");
		if(st.countTokens() != 2) {
			Logger.error("Gelen requestte . ile ayrıştırılan veri sayısı " +
					st.countTokens() + " beklenen 2'ydi.");
			throw new FBSignedRequestException("Gelen requestte . ile ayrıştırılan veri sayısı " +
					st.countTokens() + " beklenen 2'ydi.");
		}
		
		/* Facebooktan gelen saf veriler */
		String encodedSignature = st.nextToken();
		String payload = st.nextToken();
		
		/* Gelen verinin JSON'a decode edilmesi */
		Codec decoder = new Codec();
		String jsonedPayload = new String(decoder.decodeBASE64(payload));
		byte[] decodedSignature = decoder.decodeBASE64(encodedSignature);
		
		/* JSON'un java sınıfına dönüştürülmesi */
		Gson gson = new Gson();
		FBSignedRequest fbSignedRequest = gson.fromJson(jsonedPayload, FBSignedRequest.class);
		
		/* Veri validasyonu */
		if(!fbSignedRequest.getAlgorithm().equalsIgnoreCase("HMAC-SHA256")) {
			Logger.error("Gelen veri imzalama algoritması bilinmiyor, HMAC-SHA256 bekleniyordu.");
			throw new FBSignedRequestException("Gelen veri imzalama algoritması bilinmiyor, HMAC-SHA256 bekleniyordu.");
		}
		
		try {
			SecretKeySpec secretKeySpec = 
				new SecretKeySpec(Play.configuration.getProperty("facebook.appSecret").getBytes(), "HMACSHA256");
			Mac mac = Mac.getInstance("HMACSHA256");
			mac.init(secretKeySpec);
			byte[] mysig = mac.doFinal(payload.getBytes());
			if (!Arrays.equals(mysig, decodedSignature)) {
				Logger.error("Gelen signed_request datası Facebook tarafından imzalanmamış.");
				throw new FBSignedRequestException("Gelen signed_request datası Facebook tarafından imzalanmamış.");
			}
		} catch (InvalidKeyException e) {
			Logger.error("Hatalı key.");
			throw new FBSignedRequestException("Hatalı key: " + e);			
		} catch (Exception e) {
			Logger.error("Generic errör: " + e);
			throw new FBSignedRequestException("Generic errör: " + e);
		} 
		
		return fbSignedRequest;
  }

	/**
	 * Kullanıcının uygulmaya gerekli izinleri verip vermediği kontrol edilir.
	 * 
	 * @param fbSignedRequest
	 * @return
	 */
	public static boolean isUserGrantedApplicationPermissions(
			FBSignedRequest fbSignedRequest) {
		/** TODO Şimdilik sadece basic yetki var mı buna bakıyoruz. İleride verilen yetkileri
		 * tek tek kontrol etmemiz gerekebilir. 
		 */
		return fbSignedRequest.getUser_id() != null;
  }

	public static String requestApplicationPermissions() {
		return requestAppicationPermissions(Play.configuration.getProperty("facebook.canvasPage"));
  }

	public static String requestAppicationPermissions(String redirectTO) {
		
		/* Kullanıcı henüz uygulamaya izin vermemiş, izin alalım. */
		
		/** TODO İleride izinleri de parametrik alabiliriz. */
		String authUrl;
		try {
			authUrl = "http://www.facebook.com/dialog/oauth?client_id=" + 
				Play.configuration.getProperty("facebook.appID") + "&scope=offline_access&redirect_uri=" + 
				URLEncoder.encode(redirectTO,"UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return "";
		}			
		return "<script>top.location.href='" + authUrl + "'</script>";
	  
  }

	public static String getClientCredentialAccessToken() throws FacebookException {			 
		
		String tokenUrl = "https://graph.facebook.com/oauth/access_token?" +
		  "client_id=" + Play.configuration.getProperty("facebook.appID") +
		  "&client_secret=" + Play.configuration.getProperty("facebook.appSecret") +
		  "&grant_type=client_credentials";
		
		/* Bu tokenı böyle ayırmadan doğrudan geçirirsem WS invalid karakter hatası veriyor,
		 *  = sorun çıkarıyor */
		HttpResponse response = WS.url(tokenUrl).get();
		
		if(response.getStatus() != 200) {
			throw new FacebookException("getClientCredentialAccessToken yetki hatası, dönüş değeri: " 
					+ response.getStatus() + "\n " + response.getString());
		}
		
		String token = response.getString();
		StringTokenizer st = new StringTokenizer(token,"=");
		if(st.countTokens() != 2) {
			throw new FacebookException("getClientCredentialAccessToken token hatalı: " 
					+ token);
		}
		st.nextToken();
		token = st.nextToken();
	
		return token;
	}
	
	
}
