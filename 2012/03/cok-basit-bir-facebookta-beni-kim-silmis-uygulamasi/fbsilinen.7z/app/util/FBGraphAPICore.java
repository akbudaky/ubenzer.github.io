package util;

import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;

import models.User;
import play.libs.F.Promise;
import play.libs.WS;
import play.libs.WS.HttpResponse;
import play.libs.WS.WSRequest;

import com.google.gson.JsonArray;
import com.jamonapi.utils.Logger;

import exceptions.FBGraphAPIException;

/**
 * Bu kısım Facebook'ta dokümante edilmiş temel
 * graph apilerini içermektedir.
 * 
 * @author UB
 *
 */

/* TODO: Tüm requestlerin Future ve/veya Promise gibi şeylerle
 * Asenkron yapılıp threadin sleep yapılması.
 */
public class FBGraphAPICore {

	public static JsonArray GET (String ID, String ConnectionType, String accessToken) 
		throws FBGraphAPIException  {
		
		HttpResponse response = WS.url("https://graph.facebook.com/" + WS.encode(ID) 
				+ (ConnectionType != null ? "/" + WS.encode(ConnectionType) : "") + "?access_token=" 
				+ WS.encode(accessToken)).get();
			
		/* Request sıkıntılı mı ? */
		if(response.getStatus() != 200) {
			throw new FBGraphAPIException(response);
		}
		
		JsonArray JSON = null; 
		try {
	  	JSON = response.getJson().getAsJsonObject().getAsJsonArray("data");
	  } catch (Exception e) {
	  	throw new FBGraphAPIException(response, "JSON data array is not reachable");
	  }
	  
	  return JSON;
	}
	
	
	public static String POST(String ID, String ConnectionType, String accessToken
			, Map<String,String> params) throws FBGraphAPIException {
	
		String appRequestUrl = "https://graph.facebook.com/" +
   	WS.encode(ID) + (ConnectionType != null ? "/" + ConnectionType : "") + 
   	"?access_token=" +  WS.encode(accessToken);
	
		HttpResponse response = WS.url(appRequestUrl).setParameters(params).post();
		
		if(response.getStatus() != 200) {
			throw new FBGraphAPIException(response);
		}
		
		return response.getString();

	}
	
	
	public static void DELETE(String ID, String accessToken) throws FBGraphAPIException {
		
		String appRequestUrl = "https://graph.facebook.com/" +
   	WS.encode(ID) + "?access_token=" +  WS.encode(accessToken) + "&method=delete";
	
		/* .delete çalışmıyor? */
		HttpResponse response = WS.url(appRequestUrl).get();
		
		if(response.getStatus() != 200) {
			Logger.log(response);
			throw new FBGraphAPIException(response);
		}
		
		return;
	}
	
}
