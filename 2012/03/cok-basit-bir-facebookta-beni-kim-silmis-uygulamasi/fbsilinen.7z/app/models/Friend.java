package models;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

import com.google.gson.annotations.Expose;

import play.data.validation.Required;
import play.db.jpa.Model;

@Entity
public class Friend extends Model {
	
	@Required
	public String name;
	
	@Required
	public String userID;
	
	public Friend(String ID, String name) {
		super();
		this.name = name;
		this.userID = ID;
	}

	/* gerçi facebooktaki ID'yi direk primary key yapsam sanırım bu kadar kasmama gerek yoktu ama neyse... */
	public boolean equals(Object o) {
		if(!(o instanceof Friend)) return false;
		return this.userID.equals(((Friend)o).userID);
		
	}
}