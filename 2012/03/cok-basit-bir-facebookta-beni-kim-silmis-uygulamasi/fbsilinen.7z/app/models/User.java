package models;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.*;
import play.data.validation.*;
import play.db.jpa.Model;

@Entity
public class User extends Model {
	
	@Required
	public String name;
	
	@Required
	public String userID;
	
	@Required
	public String accessToken;
	
	@OneToMany (cascade=CascadeType.REMOVE,fetch=FetchType.EAGER)
	public List<Friend> friendList;
	
	public User(String userID, String name, String accessToken) {
		this.userID = userID;
		this.name = name;
		this.accessToken = accessToken;
		this.friendList = new ArrayList<Friend>();
	}
	
	public void addAddAFriend(String friendName, String friendID) {
		Friend f = new Friend(friendID, friendName);
		f.save();
		friendList.add(f);
		this.save();
	}
	
	public void addAddAFriend(Friend f) {
		friendList.add(f);
		this.save();	  
	}
	
	public void deleteAFriend(Friend f) {
		this.friendList.remove(f);
		this.save();
		f.delete(); /* Bağlantıyı sildik ama friend entitisi hiçbir yere bağlı olmadan kalmasın öyle. */
	}
	
	public void deleteAFriend(String friendID) {
		Friend f = Friend.find("byUserId", friendID).first();
		if(f != null) {
			this.friendList.remove(f);
			this.save();
			f.delete();
		}
	}
	
	public void deleteUser() {
		this.delete();
	}

	/**
	 * Verilen kullanıcının sistemimizde kayıtlı ise
	 * nesne olarak döndürülür, yoksa
	 * null döndürülür
	 * 
	 * @param userID
	 */
	public static User getUser (String userID) {
		return User.find("byUserId", userID).first();
	}

	
}