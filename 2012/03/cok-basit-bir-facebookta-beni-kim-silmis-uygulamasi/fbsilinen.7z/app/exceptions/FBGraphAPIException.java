package exceptions;

import java.util.List;

import models.Friend;
import play.libs.WS;
import play.libs.WS.HttpResponse;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

public class FBGraphAPIException extends FacebookException {

	private HttpResponse httpResponse;
	public HttpResponse getHttpResponse() {
  	return httpResponse;
  }
	
	public FBGraphAPIException(HttpResponse httpResponse) {
		this(httpResponse, "FBGraphAPI Request Exception: " + httpResponse.getStatus());
	}
	
	public FBGraphAPIException(HttpResponse httpResponse, String message) {
		super(message);
		this.httpResponse = httpResponse;	 	
	}
	
	public JsonArray getJsonResponse() {		
		JsonArray sonuc = null;
		try {
	    sonuc = httpResponse.getJson().getAsJsonObject().getAsJsonArray("error");
    } catch (Exception e) {
    }
		return sonuc;
	}
	
}
