package exceptions;

public class FBSignedRequestException extends FacebookException {

	public FBSignedRequestException(String message) {
	  super(message);
  }

}
