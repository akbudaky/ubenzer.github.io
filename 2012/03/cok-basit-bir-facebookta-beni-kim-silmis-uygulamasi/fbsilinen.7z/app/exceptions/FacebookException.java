package exceptions;

public class FacebookException extends Exception {

	public FacebookException(String message) {
	  super(message);
  }

}
