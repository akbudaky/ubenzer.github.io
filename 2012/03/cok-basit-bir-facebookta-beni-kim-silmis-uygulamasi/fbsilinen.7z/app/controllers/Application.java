package controllers;

import play.*;
import play.data.validation.*;
import play.mvc.*;
import play.mvc.Scope.*;
import play.cache.*;
import play.cache.Cache;
import play.libs.Codec;
import play.libs.WS;
import util.FBApplicationRequest;
import util.FBGraphAPI;
import util.FBHelper;
import util.FBSignedRequest;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.util.*;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import jobs.CheckFriendship;

import org.apache.commons.codec.binary.Base64;

import com.google.gson.*;

import exceptions.FBGraphAPIException;
import exceptions.FBSignedRequestException;
import exceptions.FacebookException;
import flexjson.JSONSerializer;

import models.*;

/* TODO Play sürümünü güncelle */
public class Application extends Controller {

	public static void facebookInPost(String error_reason, String error, 
			String error_description, @Required String signed_request) {
		
		play.Logger.info("facebookInPost başladı");
		
		if(error_reason != null || error != null) {
			renderText("Hata aldık: " + error_description);
		}
		
		if(signed_request == null) renderText("Sadece facebook lütfen.");
		
		FBSignedRequest fbSignedRequest = null;
    try {
	    fbSignedRequest = FBHelper.parseSignedRequest(signed_request);
    } catch (FBSignedRequestException e) {
    	/* E tabi productionda bu hataları böyle kabak gibi
    	 * kullanıcıya sunmayacağız, süper tasarımlı ultra komik
    	 * bir 500 Internal Server Erör sayfamız olacak.
    	 */
	    e.printStackTrace();
    	renderText("Hata aldık: " + e);
    } catch (RuntimeException e) {
    	e.printStackTrace();
    	renderText("Run time exception yedik: " + e);	    
    }
    
    if(!FBHelper.isUserGrantedApplicationPermissions(fbSignedRequest)) {
    	String script = FBHelper.requestApplicationPermissions();
    	renderTemplate("Application/redirect.html",script);    	
    }
		
		String cikti  = "";

		/* Uygulamayı kullanan kullanıcının veritabanındaki kaydına bakalım,
		 * eğer kullanıcı yeniyse kullanıcıyı vt'a kaydedelim.
		 */
		User currentUser = User.getUser(fbSignedRequest.getUser_id());
		if (currentUser == null) {
			/* TODO */
			currentUser = new User(fbSignedRequest.getUser_id(), "KULLANICI ADI TODO",
					fbSignedRequest.getOauth_token());
		
			/* Arkadaş listesini ilkleyelim. */
			List<Friend> newFriendList = null;
	    try {
	    	newFriendList = FBGraphAPI.getUserFriends("me", currentUser.accessToken);
	    	
				for(int i=0; i<newFriendList.size();i++) {
					Friend f = newFriendList.get(i);
					f.save();
				}
	    } catch (FBGraphAPIException e) {
	    	e.printStackTrace();
	    	renderText("FBGraphAPI Exception: " + e);	 
	    }
	    
	    currentUser.friendList = newFriendList;
	    currentUser.save();
	    
	    cikti = "Merhaba. Uygulamayı kullanmaya başladınız. Bundan soraki arkadaş ekleme/çıkma durumları" +
	    		" size bildirilecek. Bundan öncesini maalesef bilemiyoruz." +
	    		" Normalde biz uygulama olarak yeni arkadaşlarınızı ve sizi silen arkadaşlarınızı her 1 saate bir" + 
	    		" kontrol ediyoruz. Ama bir saat bile bekleyemeyecek kadar sabırsızsanız, o zaman 'Beklemek istemiyorum, şimdi hemen güncelle'" +
	    		" linkini kullanarak sabırsızlığınızı giderebilirsiniz.";
	    
	    render(cikti, signed_request);

		}
		
		/* Bu if'in içine acaba hiç girecek mi? Sonuçta access offline permissionunu istedik */
		if (!currentUser.accessToken.equalsIgnoreCase(fbSignedRequest.getOauth_token())) { 
			currentUser.accessToken = fbSignedRequest.getOauth_token();
		}	
		
		List<FBApplicationRequest> appReqs = null;
		String accessToken;
    try {
	    accessToken = FBHelper.getClientCredentialAccessToken();
	    appReqs = FBGraphAPI.getApplicationRequests(currentUser.userID, accessToken);
   
	    for(FBApplicationRequest req : appReqs) {
	    	FBGraphAPI.deleteApplicationRequest(req, accessToken);
	    }
	 
	    if(appReqs.size() > 0) {
	    	cikti = "Arkadaş listesinde aşağıdaki değişiklikler oldu:";	
	    } else {
		    cikti = "Uygulamayı kullandığın için sağol. Değişiklik olunca burada göreceksin.";
	    }

	    
    } catch (Exception e) {  
	    e.printStackTrace();
	    renderText("Geçici hata: " + e);
    }
    
    render(cikti, appReqs, signed_request);
	}

	
	public static void updateNow(@Required String signed_request) {
		
		FBSignedRequest fbSignedRequest = null;
    try {
	    fbSignedRequest = FBHelper.parseSignedRequest(signed_request);
    } catch (FBSignedRequestException e) {
	    e.printStackTrace();
    	renderText("Hata aldık: " + e);
    } catch (RuntimeException e) {
    	e.printStackTrace();
    	renderText("Run time exception yedik: " + e);	    
    }
    
    if(!FBHelper.isUserGrantedApplicationPermissions(fbSignedRequest)) {
    	facebookInPost(null,null,null,signed_request);
    }
    
    new CheckFriendship(fbSignedRequest.getUser_id()).now();
    
    flash.success("İsteğiniz alındı. Kısa bir süre sonra arkadaş listenizdeki" + 
    		" değişiklikler hesaplanmş olacak. Değişiklikleri 'uygulama bildirimi' olarak alacaksın." +
    		" Bu yüzden daha fazla bu sayfada beklemene gerek yok, Interet'in tadını çıkar. ;)");
    facebookInPost(null,null,null,signed_request);
		
	}
}