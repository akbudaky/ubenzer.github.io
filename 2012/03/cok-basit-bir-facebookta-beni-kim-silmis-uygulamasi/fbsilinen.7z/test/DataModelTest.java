import org.junit.*;
import java.util.*;
import play.test.*;
import models.*;


public class DataModelTest extends UnitTest {

	@Before
	public void setup() {
		Fixtures.deleteDatabase();
		User aUser = new User("123456","UMUT","mesela");
		aUser.save();
	}
	
	@Test
	public void UseraFriendKaydetmeVeOkuma() {
		User aUser = User.find("byUserId", "123456").first();
		assertNotNull(aUser);
		
		assertEquals(aUser.friendList.size(), 0);
		
		aUser.addAddAFriend("namık", "123456");
		
		assertEquals(aUser.friendList.size(), 1);
		
		aUser = User.find("byUserId", "123456").first();
		assertNotNull(aUser);
		assertEquals(aUser.friendList.size(), 1);
	}
	
	@Test
	public void FriendSilmeUserPersistanceVeIntegrityKontrolu() {
		User aUser = User.find("byUserId", "123456").first();
		aUser.addAddAFriend("birinci", "1");
		aUser.addAddAFriend("ikinci", "2");
		
		assertEquals(aUser.friendList.size(), 2);
		
		Friend silinecek = aUser.friendList.get(0);
		
		/* Nesne referansı ile silelim */
		aUser.deleteAFriend(silinecek);
		
		/* Friend listeden kalkmış mı? */
		assertEquals(aUser.friendList.size(), 1);
		/* Friend cidden silinmiş mi? */
		assertEquals(Friend.findAll().size(), 1);

		/* ID ile silelim */
		aUser.deleteAFriend("2");
		
		/* Friend listeden kalkmış mı? */
		assertEquals(aUser.friendList.size(), 0);
		/* Friend cidden silinmiş mi? */
		assertEquals(Friend.findAll().size(), 0);
	}
	
	@Test
	public void UserSilmeFriendPersistanceKontrolu() {
		User aUser = User.find("byUserId", "123456").first();
		aUser.addAddAFriend("birinci", "1");
		aUser.addAddAFriend("ikinci", "2"); 
		/* Aslında bu arkadaş ekleme olayını bir metotla yapsak iyi olabilir. */
		
		assertEquals(Friend.findAll().size(), 2);
		assertEquals(User.findAll().size(), 1);
		
		aUser.deleteUser();
		
		assertEquals(Friend.findAll().size(), 0);
		assertEquals(User.findAll().size(), 0);
		
	}
}
