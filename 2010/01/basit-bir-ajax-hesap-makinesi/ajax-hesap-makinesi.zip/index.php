<?php 
	/* AJAX 101 - http://www.ubenzer.com/ */
	header("Content-Type: text/html; charset=utf-8"); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="tr-TR">
<head profile="http://gmpg.org/xfn/1">
	<!-- EgeBK PHP Kursu Örnek Kaynak Kodları -->
	<title>AJAX Hesap Makinesi</title>
	<!-- jQuery Kütüphanesini Ekleyelim. Dikkat edin bu bir JavaScript kütüphanesi ve istemci tarafında çalışmak
	üzere tarayıcıya gönderiliyor. Yani kodlar halka açık. -->
	<script type="text/javascript" src="jquery.js"></script>
	
	<!-- jQuery kütüphanesini kullanarak işlem yapacağımız kod parçaları. JacaScript dosyalarının
	eklenme sırası önemlidir. -->
	<script type="text/javascript" src="bizimkodlar.js"></script>
	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta http-equiv="author" content="Umut Benzer" />
</head>
<body>
<form action="hesap.php" id="makine" method="post"><!-- FORM ID'SİNE DİKKAT EDİNİZ -->
	1. Değer: <input type="text" name="deger1" /><br />
	2. Değer: <input type="text" name="deger2" /><br />
	<select name="islem">
		<option>Topla</option>
		<option>Cikar</option>
		<option>Carp</option>
		<option>Bol</option>
	</select>
	<input type="submit" value="AJAX'la Hesapla" />
</form>
<div id="sonuc">Sonuç burada görünecek.<br /></div><!-- DİV İD'SİNE DİKKAT EDİNİZ. -->
</body>