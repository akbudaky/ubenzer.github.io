$(document).ready(function() { 
/* Buranın içindeki kodlar, sayfa yüklenmesi tamamlanınca çalışacak. Genel geçer olarak,
jQuery kodları bu blok içine yazılır. */
	var sayac = 0; /* Değişken tanımlama. */
	
	/* Bir "event". makine id'li form submit olunca aşağıdaki kod parçası çalışır. Daha ayrıntılı bilgi için
	jQuery dokümantasyonundan selector ve events konularına bakınız.*/
	$("#makine").submit(function() {
	
		$.ajax({ /* jQuery kütüphanesinin sunduğu cross-browser ajax metodu */
			type: "POST", /* http veri aktarım metodu */
			url: "hesap.php", /* isteğin yapılacağı adres */
			cache: false, /* sorgu tarayıcı önbelleğine alınabilir mi? */
			data: $(this).serialize(), 
			/* gönderilecek veri. this.serialize ile, submit edilen formun içindeki tüm bilgiler gönderilmektedir. */
			dataType: "json", /* dönüş için beklenen veri tipi */
			error: function(request) { /* isteğin yapılamaması sonucu gerçekleşecek kod parçası */
				alert("Hata oluştu."); /* ekrana mesaj kutusu çıkartır. */
			},
			success: function(request) { /* isteğin başarılı olması sonucu gerçekleşecek kod parçası */
				if(!request.hatali) {
					sayac++;
					$('#sonuc').append(sayac + " numaralı islemin sonucu: " + request.sonuc + "<br />"); 
					/* json ile gelen verilere dizi elemanıymış gibi erişilebilir.  */
				} else {
					alert("Sonuc hatalı. Gelen mesaj: " + request.hata);
				}
			}		
		});
		return false; /* varsayılan submit olayının olmasını (formun normal yöntemlerle gönderilmesini) engeller. */
		/* AJAX ASENKRONDUR. KOD PARÇASININ BU SATIRINA GELMESİ İÇİN AJAX SORGUSUNUN BİTMESİ
		GEREKMEMEKTEDİR. */
	});	
});