<?php
// echo var_dump($_REQUEST);
header("Content-Type: application/json; charset=utf-8");

if (!(isset($_REQUEST['islem']) && 
		($_REQUEST['islem'] == "Topla" || $_REQUEST['islem'] == "Cikar" || 
		 $_REQUEST['islem'] == "Carp" || $_REQUEST['islem'] == "Bol"))) {
	hataVer(); /* Hata mesajı yaz ve çık */
}
$islem = $_REQUEST['islem']; /* Bu noktadan sonra $islem'e güvenilir. */
 
/* Birinci sayı atanmış ve sayısal bir değer mi? */
if (!(isset($_REQUEST['deger1']) && is_numeric($_REQUEST['deger1']))) {
	hataVer(); /* Hata mesajı yaz ve çık */
}
$deger1 = $_REQUEST['deger1'];
 
/* İkinci sayı atanmış ve sayısal bir değer mi? */
if (!(isset($_REQUEST['deger2']) && is_numeric($_REQUEST['deger2']))) {
	hataVer(); /* Hata mesajı yaz ve çık */
}
$deger2 = $_REQUEST['deger2'];
 
if($islem == "Topla") {
	$sonuc = $deger1 + $deger2;
} elseif ($islem == "Carp") {
	$sonuc = $deger1  * $deger2;
} elseif ($islem == "Cikar") {
	$sonuc =  $deger1 - $deger2;
} else {
	if($deger2 == 0) {
		hataVer("Sıfıra bölüyorsunuz.");
	}
	$sonuc =  $deger1  / $deger2;
}

echo json_encode(array("sonuc" => $sonuc, "hatali" => false));
/* json_encode fonksiyonunun içindeki array'in key'lerine ve bizimkod.js dosyasına
(istemci tarafta) kullanılan json verisine erişilirken kullanılan key'lere dikkat edin. */

function hataVer($mesaj = null) {
	if (is_null($mesaj)) $mesaj = "Hatali bir veri var! Siz kimi kandiriyorsunuz?";
	die(json_encode(array("hata" => $mesaj,"hatali" => true)));

	/* Die, bir mesaj vererek programın çalışmasını durdurur. */
}
