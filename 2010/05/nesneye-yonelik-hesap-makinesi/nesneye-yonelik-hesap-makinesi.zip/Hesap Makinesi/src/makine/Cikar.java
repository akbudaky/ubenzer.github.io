package makine;

public class Cikar extends Makine {

    public int hesapla() {
        return super.sayi1 - super.sayi2;
    }

}
