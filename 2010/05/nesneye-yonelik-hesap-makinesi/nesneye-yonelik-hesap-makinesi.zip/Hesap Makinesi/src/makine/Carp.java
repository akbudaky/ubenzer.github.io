package makine;

public class Carp extends Makine {

    public int hesapla() {
        return super.sayi1 * super.sayi2;
    }

}
