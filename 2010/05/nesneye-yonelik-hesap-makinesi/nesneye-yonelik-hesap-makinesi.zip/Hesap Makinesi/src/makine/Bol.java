package makine;

public class Bol extends Makine {

    public int hesapla() {
        if(super.sayi2 != 0) {
            return super.sayi1 / super.sayi2;
        }
        return 0;
    }

}