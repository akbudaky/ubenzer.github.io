package makine;

public abstract class Makine {
    
   protected int  sayi1 = 0;
   protected int  sayi2 = 0;

   /* TÜM ALT SINIFLAR İÇİN ORTAK İŞLEYİŞE SAHİP METOTLAR BURADA YAZILIYOR. */
   public void setSayi1(int sayi1) {
        this.sayi1 = sayi1;
   }

   public void setSayi2(int sayi2) {
        this.sayi2 = sayi2;
   }

   /* AYNI İŞLEVE SAHİP AMA İŞLEYİŞİ FARKLI METOTLAR, ALT SINIFLARDA YAZILMAK ÜZERE, TANIMLANIYOR KODLANMIYOR */
   public abstract int hesapla();
   /* Abstract (soyut) bir metot, bu metodun alt sınıflarda implement edilmesini zorunlu kılar. */
    
}
