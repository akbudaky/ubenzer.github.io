package makine;

public class Topla extends Makine {

    public int hesapla() {
        return super.sayi1 + super.sayi2;
    }
}
